#Requires AutoHotkey v2.0
#SingleInstance Force

; Projektpfad als Arbeitsverzeichnis für temporäre Dateien,
; unabhängig davon, von wo aus das Script gestartet wurde.
SetWorkingDir A_ScriptDir

#Include "Gemeinsam.ahk"
#Include "Tab_Netzwerkkarten.ahk"
#Include "Tab_Oeffentliche_IP.ahk"
#Include "Tab_Erreichbarkeit.ahk"
#Include "Tab_Tools.ahk"
#Include "Tab_Notizen.ahk"
#Include "Tab_About.ahk"

; Hauptdatei: GUI-Aufbau, Tab-Steuerung, Ereignisverknüpfungen und Startablauf.
; Haupt-GUI mit Tabs erstellt
MeineGui := Gui(, "Netzwerk Tools " version)
ApplyLightAppTheme(MeineGui, 11)

SB := MeineGui.Add("StatusBar", , "Starttext der Leiste (kann leer gelassen werden).")
SB.SetText(" Netzwerkkarten - Profile -> Doppelklick lädt Profil")
TraySetIcon "Shell32.dll", 19

; Tab-Control hinzufügen
TabControl := MeineGui.Add("Tab3", "w460 h425", ["Netzwerkkarten", "ext. IP", "Erreichbarkeit", "Netzwerk", "Windows", "Notizen", "About"])
TabControl.SetFont("s8", "Segoe UI")


; ===== TAB 1: Netzwerkkarten Konfiguration =====
TabControl.UseTab(1)

; Titel und Profile
lblTitel := MeineGui.Add("Text", "x20 y65 w290 h30", "Verfügbare Netzwerkkarten")
lblTitel.SetFont(fontMediumB, sa)
NetzwerkDDL := MeineGui.Add("DropDownList", "x20 y100 w200 vNetzwerkKarte Choose1")
lblProfil := MeineGui.Add("Text", "x320 y65 w130 h30", "Profile")
lblProfil.SetFont(fontMediumB, sa)

; Textbox und Inputbox für die Details
lblNetzwerkConfig := MeineGui.Add("Text", "x20 y140 w280 h30", "Netzwerkkarten Konfiguration")
lblNetzwerkConfig.SetFont(fontMediumB, sa)

chbDHCP := MeineGui.Add("Checkbox", "x50 y175 w125 h24", "DHCP aktiviert")
chbDHCP.SetFont("s10", "Segoe UI")

txtVLAN := MeineGui.Add("Text", "x175 y175 w60 h20", "VLAN-ID:")
txtIP := MeineGui.Add("Text", "x20 y210 w115 h20 Right", "IP-Adresse")
txtSubnetz := MeineGui.Add("Text", "x20 y245 w115 h20 Right", "Subnetzmaske")
txtGateway := MeineGui.Add("Text", "x20 y280 w115 h20 Right", "Gateway")
txtDNS := MeineGui.Add("Text", "x20 y313 w115 h20 Right", "DNS-Server")

txtIP.SetFont(fontBigSmall, sa)
txtSubnetz.SetFont(fontBigSmall, sa)
txtGateway.SetFont(fontBigSmall, sa)
txtDNS.SetFont(fontBigSmall, sa)

frmVLAN := MeineGui.Add("Edit", "x240 y170 w60 h30 Center Number Multi -VScroll -Wrap", "")
frmIP := MeineGui.Add("Edit", "x150 y205 w150 h30 Disabled Multi -VScroll -Wrap", "")
frmSubnetz := MeineGui.Add("Edit", "x150 y240 w150 h30 Disabled Multi -VScroll -Wrap", "")
frmGateway := MeineGui.Add("Edit", "x150 y275 w150 h30 Disabled Multi -VScroll -Wrap", "")
frmDNS := MeineGui.Add("Edit", "x150 y310 w150 h30 Disabled Multi -VScroll -Wrap", "")

frmVLAN.SetFont(fontMedium, sa)
frmIP.SetFont(fontMedium, sa)
frmSubnetz.SetFont(fontMedium, sa)
frmGateway.SetFont(fontMedium, sa)
frmDNS.SetFont(fontMedium, sa)

; Buttons für Tab 1
AktualisierenBtn := MeineGui.Add("Button", "x230 y100 w70 h25", "Reload")
ÜbernehmenBtn := MeineGui.Add("Button", "x70 y355 w200 h50", "Übernehmen")
ÜbernehmenBtn.SetFont(fontBigB, sa)

; Profile Section
ProfilList := MeineGui.Add("Listbox", "x320 y100 w140 h255")
ProfilList.SetFont(fontBigSmallB, sa)
ProfilListInfo := MeineGui.Add("Text", "x320 y385 w140 h30", "💡 Rechtsklick auf einen Eintrag öffnet das Menü")
ProfilListInfo.SetFont(fontExtraSmall, sa)

; ProfilBtnSave := MeineGui.Add("Button", "x320 y355 w130 h25 Disabled", "Speichern")
; ProfilBtnSaveAs := MeineGui.Add("Button", "x320 y385 w130 h25", "Speichern unter")
; ProfilBtn3 := MeineGui.Add("Button", "x320 y385 w60 h22", "Vlan 0")
; ProfilBtn4 := MeineGui.Add("Button", "x390 y385 w60 h22", "Vlan R")

; ===== TAB 2: Öffentliche IP =====
TabControl.UseTab(2)

; IP-Anzeige und Aktualisieren-Button
EditExterneIP := MeineGui.Add("Edit", "x65 y65 w150 h30 Center Multi -VScroll -Wrap", "")
EditExterneIP.SetFont(fontBigB, sa)
btnÖffentlicheIP := MeineGui.Add("Button", "x280 y65 w120 h30", "Aktualisieren")
btnÖffentlicheIP.SetFont(fontSmall, sa)

; Geolocation Tabelle
gbGeolocation := MeineGui.Add("GroupBox", "x35 y125 w410 h240", "Geolocation Daten")

; Tabelle mit Beschriftungen und Werten
; Erste Spalte: Beschriftungen
MeineGui.Add("Text", "x45 y175 w80 h30", "Land:").SetFont(fontMediumB, sa)
MeineGui.Add("Text", "x45 y210 w80 h30", "Region:").SetFont(fontMediumB, sa)
MeineGui.Add("Text", "x45 y245 w80 h30", "PLZ:").SetFont(fontMediumB, sa)
MeineGui.Add("Text", "x45 y280 w80 h30", "Stadt:").SetFont(fontMediumB, sa)
MeineGui.Add("Text", "x45 y315 w80 h30", "ISP:").SetFont(fontMediumB, sa)

; Zweite Spalte: Werte (Edit-Felder, die nur zur Anzeige dienen)
EditLand := MeineGui.Add("Edit", "x130 y175 w300 h30 Multi -VScroll -Wrap", "")
EditLand.SetFont(fontMediumB, sa)
EditLand.Enabled := false  ; Read-only

EditRegion := MeineGui.Add("Edit", "x130 y210 w300 h30 Multi -VScroll -Wrap", "")
EditRegion.SetFont(fontMediumB, sa)
EditRegion.Enabled := false  ; Read-only

EditPLZ := MeineGui.Add("Edit", "x130 y245 w300 h30 Multi -VScroll -Wrap", "")
EditPLZ.SetFont(fontMediumB, sa)
EditPLZ.Enabled := false  ; Read-only

EditStadt := MeineGui.Add("Edit", "x130 y280 w300 h30 Multi -VScroll -Wrap", "")
EditStadt.SetFont(fontMediumB, sa)
EditStadt.Enabled := false  ; Read-only

EditISP := MeineGui.Add("Edit", "x130 y315 w300 h30 Multi -VScroll -Wrap", "")
EditISP.SetFont(fontMediumB, sa)
EditISP.Enabled := false  ; Read-only

; ===== TAB 3: Ping/Tracert/tnc =====
TabControl.UseTab(3)

; Erreichbarkeit Section
gbErreichbarkeit := MeineGui.Add("GroupBox", "x20 y65 w430 h180", "Erreichbarkeit")
DropDownIP := MeineGui.Add("DropDownList", "x50 y95 w370 r16 Center")
DropDownIP.SetFont(fontMedium, sa)

for ziel in pingZiele {
    v := ziel[1] "  (" ziel[2] ")"
    DropDownIP.Add([v])
}

DropDownIP.Value := 1

EditZiel := MeineGui.Add("Edit", "x50 y145 w330 h30 Multi -VScroll -Wrap")
EditZiel.SetFont(fontMediumB, sa)
EditZiel.Value := pingZiele[1][1]

BtnInsertZiel := MeineGui.Add("Button", "x390 y145 w30 h30", "📋")
BtnInsertZiel.OnEvent("Click", BtnInsertZielClick)

pingbutton := MeineGui.Add("Button", "x50 y195 w180 h36", "Ping")
pingbutton.SetFont(fontMediumB, sa)

tracertButton := MeineGui.Add("Button", "x240 y195 w180 h36", "Tracert")
tracertButton.SetFont(fontMediumB, sa)


tncGB := MeineGui.Add("GroupBox", "x20 y255 w430 h80", "TestNet-Connection")

tncButton := MeineGui.Add("Button", "x50 y280 w180 h36", "tnc")
tncButton.SetFont(fontMediumB, sa)

tncPortLabel := MeineGui.Add("Text", "x260 y285 w50 h30", "Port:")
tncPortLabel.SetFont(fontMediumB, sa)

tncPortEdit := MeineGui.Add("Edit", "x320 y285 w60 h30 Multi -VScroll -Wrap", "443")
tncPortEdit.SetFont(fontMediumB, sa)

; Aktuelle Netzwerkinfo
gbAktuell := MeineGui.Add("GroupBox", "x20 y355 w430 h60", "Aktuelle Netzwerkkarte")

lblAktuelleKarte := MeineGui.Add("Text", "x30 y383 w250 h20", "Keine Netzwerkkarte ausgewählt")
lblAktuelleKarte.SetFont(fontSmallB, sa)
lblAktuelleIP := MeineGui.Add("Text", "x260 y383 w150 h20", "IP: -")

; ===== TAB 4: Netzwerkfunktionen =====
TabControl.UseTab(4)

MeineGui.Add("GroupBox", "x20 y65 w430 h345", "Netzwerkfunktionen")

btn1 := MeineGui.Add("Button", "x35 y90 w185 h30", "Browser-Internet-Speedtest")
btn1.SetFont(fontSmall, sa)

btn2 := MeineGui.Add("Button", "x35 y134 w185 h30", "Port erreichbar")
btn2.SetFont(fontSmall, sa)

btn3 := MeineGui.Add("Button", "x35 y178 w185 h30", "IP Scanner")
btn3.SetFont(fontSmall, sa)

btn4 := MeineGui.Add("Button", "x35 y222 w185 h30", "Port Scanner")
btn4.SetFont(fontSmall, sa)

btn5 := MeineGui.Add("Button", "x35 y266 w185 h30", "DNS-Abfrage (ANY)")
btn5.SetFont(fontSmall, sa)

btn6 := MeineGui.Add("Button", "x35 y310 w185 h30", "Verbindungsmonitor")
btn6.SetFont(fontSmall, sa)

btn7 := MeineGui.Add("Button", "x35 y354 w185 h30", "DNS NAPTR-SRV-Abfrage")
btn7.SetFont(fontSmall, sa)

btn14 := MeineGui.Add("Button", "x245 y90 w190 h30", "Subnetz-Rechner")
btn14.SetFont(fontSmall, sa)

btn15 := MeineGui.Add("Button", "x245 y134 w190 h30", "Passwort-Generator")
btn15.SetFont(fontSmall, sa)

btn20 := MeineGui.Add("Button", "x245 y178 w190 h30", "FRITZ!Box Firmware")
btn20.SetFont(fontSmall, sa)
btn21 := MeineGui.Add("Button", "x245 y222 w190 h30", "LANCOM Firmware")
btn21.SetFont(fontSmall, sa)
platzhalterNetzwerk3 := MeineGui.Add("Button", "x245 y266 w190 h30", "")
platzhalterNetzwerk3.Enabled := false
platzhalterNetzwerk4 := MeineGui.Add("Button", "x245 y310 w190 h30", "")
platzhalterNetzwerk4.Enabled := false
platzhalterNetzwerk5 := MeineGui.Add("Button", "x245 y354 w190 h30", "")
platzhalterNetzwerk5.Enabled := false


; ===== TAB 5: Windows-Verknüpfungen =====
TabControl.UseTab(5)
MeineGui.Add("GroupBox", "x20 y65 w430 h345", "Windows-Funktionen")

btn8 := MeineGui.Add("Button", "x35 y90 w185 h30", "Netzwerk und Internet")
btn8.SetFont(fontSmall, sa)

btn9 := MeineGui.Add("Button", "x35 y134 w185 h30", "Taskmanager")
btn9.SetFont(fontSmall, sa)

btn10 := MeineGui.Add("Button", "x35 y178 w185 h30", "Dienste")
btn10.SetFont(fontSmall, sa)

btn11 := MeineGui.Add("Button", "x35 y222 w185 h30", "Geräte-Manager")
btn11.SetFont(fontSmall, sa)

btn12 := MeineGui.Add("Button", "x35 y266 w185 h30", "Firewall")
btn12.SetFont(fontSmall, sa)

btn13 := MeineGui.Add("Button", "x245 y90 w190 h30", "Netzwerkverbindungen")
btn13.SetFont(fontSmall, sa)

btn16 := MeineGui.Add("Button", "x245 y134 w190 h30", "Ereignisanzeige")
btn16.SetFont(fontSmall, sa)

btn17 := MeineGui.Add("Button", "x245 y178 w190 h30", "Systeminformationen")
btn17.SetFont(fontSmall, sa)

btn18 := MeineGui.Add("Button", "x245 y222 w190 h30", "Ressourcenmonitor")
btn18.SetFont(fontSmall, sa)

btn19 := MeineGui.Add("Button", "x245 y266 w190 h30", "Datenträgerverwaltung")
btn19.SetFont(fontSmall, sa)

; ===== TAB 6: Notiz =====
TabControl.UseTab(6)
notizFeld := MeineGui.Add("Edit", "x20 y65 w430 h300",)
btnSaveNotiz := MeineGui.Add("Button", "x20 y380", "Speichern")
infoSavedNotiz := MeineGui.Add("Text", "x120 y385 w200", "")


; ===== TAB 7: About =====
TabControl.UseTab(7)
; Info Section
gbInfo := MeineGui.Add("GroupBox", "x20 y65 w430 h320", "Informationen")
MeineGui.Add("Text", "x35 y95 w400 h20", "Netzwerktools " version)
MeineGui.Add("Text", "x35 y+25 w400 h20", "")
MeineGui.Add("Text", "x35 y+25 w400 h20", "Erstellt von mir")
MeineGui.Add("Text", "x35 y+15 w400 h20", "-")
MeineGui.Add("Link", "x35 y+15 w400 h20", '-')
;MeineGui.Add("Text", "x35 y170 w400 h20", "Verwendete Technologien: AutoHotkey v2")
; ===== ALLGEMEINE ELEMENTE (außerhalb der Tabs) =====
TabControl.UseTab()  ; Zurück zur Haupt-GUI

; Event-Handler
AktualisierenBtn.OnEvent("Click", NetzwerkKartenAktualisieren)
NetzwerkDDL.OnEvent("Change", NetzwerkKarteGewaehlt)
chbDHCP.OnEvent("Click", DhcpGewaehlt)
ÜbernehmenBtn.OnEvent("Click", ÜbernehmenBtnGeklickt)
; ProfilBtnSave.OnEvent("Click", SpeichereProfil)
; ProfilBtnSaveAs.OnEvent("Click", SpeichernUnterProfil)
; ProfilBtn3.OnEvent("Click", (*) => SetVlanId(0))
; ProfilBtn4.OnEvent("Click", (*) => SetVlanId(Random(2, 4094)))
ProfilList.OnEvent("Change", ProfilListGeklickt)
ProfilList.OnEvent("ContextMenu", ProfilListRechtsGeklickt)
ProfilList.OnEvent("DoubleClick", ProfilListDoppelGeklickt)
btnÖffentlicheIP.OnEvent("Click", GetÖffentlicheIP)
btn1.OnEvent("Click", (*) => buttonKlick(1))
btn2.OnEvent("Click", (*) => buttonKlick(2))
btn3.OnEvent("Click", (*) => buttonKlick(3))
btn4.OnEvent("Click", (*) => buttonKlick(4))
btn5.OnEvent("Click", (*) => buttonKlick(5))
btn6.OnEvent("Click", (*) => buttonKlick(6))
btn7.OnEvent("Click", (*) => buttonKlick(7))
btn8.OnEvent("Click", (*) => buttonKlick(8))
btn9.OnEvent("Click", (*) => buttonKlick(9))
btn10.OnEvent("Click", (*) => buttonKlick(10))
btn11.OnEvent("Click", (*) => buttonKlick(11))
btn12.OnEvent("Click", (*) => buttonKlick(12))
btn13.OnEvent("Click", (*) => buttonKlick(13))
btn14.OnEvent("Click", (*) => buttonKlick(14))
btn15.OnEvent("Click", (*) => buttonKlick(15))
btn16.OnEvent("Click", (*) => buttonKlick(16))
btn17.OnEvent("Click", (*) => buttonKlick(17))
btn18.OnEvent("Click", (*) => buttonKlick(18))
btn19.OnEvent("Click", (*) => buttonKlick(19))
btn20.OnEvent("Click", (*) => buttonKlick(20))
btn21.OnEvent("Click", (*) => buttonKlick(21))
pingbutton.OnEvent("Click", pingButtonFunktion)
tracertButton.OnEvent("Click", tracertButtonFunktion)
DropDownIP.OnEvent("Change", DropDownIPChanged)
tncButton.OnEvent("Click", tncButtonFunktion)
txtSubnetz.OnEvent("Click", InsertSubnet)
txtIP.OnEvent("DoubleClick", (*) => CopyWert(frmIP.Value))
txtGateway.OnEvent("DoubleClick", (*) => CopyWert(frmGateway.Value))
txtDNS.OnEvent("DoubleClick", (*) => CopyWert(frmDNS.Value))
txtSubnetz.OnEvent("Click", InsertSubnet)
btnSaveNotiz.OnEvent("Click", saveNotiz)
; Event-Handler für Tab-Änderungen
TabControl.OnEvent("Change", TabChanged)
; Funktion, die aufgerufen wird, wenn der Tab gewechselt wird
TabChanged(Ctrl, Info) {
    global SB
    if (Ctrl.Value = 1)
        BringeNetzwerkKopfzeilenNachVorn()
    switch (Ctrl.Text) {

        case "Netzwerkkarten":
            SB.SetText(" Netzwerkkarten - Subnetzmaske per Klick auf Label einfügen")

        case "ext. IP":
            ;GetÖffentlicheIP()
            SB.SetText(" Öffentliche IP")
            Send("{TAB}")

        case "Erreichbarkeit":
            SB.SetText(" Ping/Tracert/Test-NetConnection")
            Send("{TAB}")

        case "Netzwerk":
            SB.SetText(" Netzwerkdiagnose und Netzwerk-Tools")

        case "Windows":
            SB.SetText(" Windows-Funktionen und Systemprogramme")

        case "Notizen":
            SB.SetText(" Notizen zum Kopieren und Einfügen")

        case "About":
            SB.SetText(" Info zum Programm und dem Author")

        default:

    }
}
; Nur lokale Notizen laden; Adapter und Profile folgen nach Anzeige der GUI.
löscheLeereZeilen()
loadNotiz()

; GUI anzeigen
MeineGui.Show("Center")
; MeineGui.Show("w480 h415 Center")
for control in [frmVLAN, frmIP, frmSubnetz, frmGateway, frmDNS, EditExterneIP, EditLand, EditRegion, EditPLZ, EditStadt, EditISP, EditZiel, tncPortEdit]
    CenterModernEdit(control, 20)
MeineGui.Move(1000, 100)
BringeNetzwerkKopfzeilenNachVorn()
SetTimer(NetzwerkKartenAktualisieren, -100)

BringeNetzwerkKopfzeilenNachVorn() {
    global lblTitel, lblProfil
    for ctrl in [lblTitel, lblProfil] {
        DllCall("SetWindowPos", "Ptr", ctrl.Hwnd, "Ptr", 0, "Int", 0, "Int", 0, "Int", 0, "Int", 0, "UInt", 0x13)
        DllCall("RedrawWindow", "Ptr", ctrl.Hwnd, "Ptr", 0, "Ptr", 0, "UInt", 0x85)
    }
}


; ===== FUNKTIONEN =====

; Hotkeys und Schließen der Haupt-GUI
F5:: NetzwerkKartenAktualisieren()
Esc:: ExitApp
MeineGui.OnEvent("Close", (*) => ExitApp())