﻿; Profil-, Notiz- und Netzwerkkarten-Daten liegen im Benutzerzweig der Registry.
ReadAppData() {
    try {
        return RegRead("HKEY_CURRENT_USER\Software\IP-App", "Data", "")
    } catch {
        return ""
    }
}
WriteAppData(data) {
    RegWrite(data, "REG_SZ", "HKEY_CURRENT_USER\Software\IP-App", "Data")
}
GetAppDataLines() {
    lines := []
    for line in StrSplit(ReadAppData(), "`n", "`r") {
        if (line != "")
            lines.Push(line)
    }
    return lines
}
SaveAppDataLines(lines) {
    data := ""
    for index, line in lines
        data .= (index > 1 ? "`r`n" : "") line
    WriteAppData(data)
}
ProfileRecord(name) {
    global chbDHCP, frmIP, frmSubnetz, frmGateway, frmDNS, frmVLAN
    return "Profil;" name ";" chbDHCP.Value ";" frmIP.Value ";" frmSubnetz.Value ";" frmGateway.Value ";" frmDNS.Value ";" frmVLAN.Value
}
DefaultAppData() {
    return Join([
        "letzteNetzwerkKarte;Ethernet",
        "Profil;DHCP;1;;;;;0",
        "Profil;192.168.178.42;0;192.168.178.42;255.255.255.0;192.168.178.1;192.168.178.1;0",
        "Profil;192.168.0.10;0;192.168.0.10;255.255.255.0;192.168.0.1;192.168.0.1;0",
        "Profil;192.168.1.10;0;192.168.1.10;255.255.255.0;192.168.1.1;192.168.1.1;0",
        "Profil;192.168.2.10;0;192.168.2.10;255.255.255.0;192.168.2.1;192.168.2.1;0",
        "Profil;192.168.3.10;0;192.168.3.10;255.255.255.0;192.168.3.1;192.168.3.1;0",
        "Profil;192.168.4.10;0;192.168.4.10;255.255.255.0;192.168.4.1;192.168.4.1;0",
        "Profil;192.168.5.10;0;192.168.5.10;255.255.255.0;192.168.5.1;192.168.5.1;0",
        "Profil;192.168.6.10;0;192.168.6.10;255.255.255.0;192.168.6.1;192.168.6.1;0",
        "Profil;192.168.7.10;0;192.168.7.10;255.255.255.0;192.168.7.1;192.168.7.1;0",
        "Profil;192.168.8.10;0;192.168.8.10;255.255.255.0;192.168.8.1;192.168.8.1;0",
        "Profil;192.168.9.10;0;192.168.9.10;255.255.255.0;192.168.9.1;192.168.9.1;0",
        "Profil;192.168.10.10;0;192.168.10.10;255.255.255.0;192.168.10.1;192.168.10.1;0",
        "Notiz;Notiz;https://192.168.2.1"
    ], "`r`n")
}

; Logik für den Reiter „Netzwerkkarten“.
global NetzwerkQueryJob := 0
global NetzwerkQueryGeneration := 0
global suppressNetzwerkDDLChange := false

VlanGetter(adapterName := "Ethernet") {
    ; Temporäre Datei für Ergebnis
    tempFile := "vlan_result.txt"

    ; PowerShell-Befehl
    psCommand := "Get-NetAdapterAdvancedProperty -Name '" adapterName "' -DisplayName 'Vlan*' | Select-Object -ExpandProperty DisplayValue | Out-File -FilePath '" tempFile "' -Encoding UTF8"

    ; PowerShell ausführen
    RunWait("PowerShell -Command " psCommand, , "Hide")

    ; Ergebnis aus Datei lesen
    if FileExist(tempFile) {
        result := FileRead(tempFile)
        FileDelete(tempFile)
        return Trim(result)
    }

    return "Nicht gefunden"
}
VlanSetter(adapterName := "Ethernet", vlanID := 0) {
    ; Temporäre Datei für Ergebnis
    tempFile := "vlan_result.txt"
    ; if (!IsInteger(vlanID)) {
    ;     vlanID := +vlanID
    ; }
    ; if (vlanID < 0 || vlanID > 4094) {
    ;     MsgBox("VLAN ID darf nur zwischen 1 und 4094 liegen")
    ;     return
    ; }

    ; PowerShell-Befehl
    ; löschen VLAN: Reset-NetAdapterAdvancedProperty -Name "Ethernet" -DisplayName "VLAN ID"
    ; setzen Vlan : Set-NetAdapterAdvancedProperty -Name "Ethernet" -DisplayName "VLAN ID" -DisplayValue "42"
    if vlanID = 0 {
        psCommand := "Reset-NetAdapterAdvancedProperty -Name '" adapterName "' -DisplayName 'VLAN ID' | Out-File -FilePath '" tempFile "' -Encoding UTF8"
    } else {
        ;MsgBox("SETVLAN PS")
        psCommand := "Set-NetAdapterAdvancedProperty -Name '" adapterName "' -DisplayName 'VLAN ID' -DisplayValue '" vlanID "' | Out-File -FilePath '" tempFile "' -Encoding UTF8"
        A_Clipboard := psCommand
    }

    ; PowerShell ausführen
    RunWait("PowerShell -Command " psCommand, , "Hide")

    ; Ergebnis aus Datei lesen
    if FileExist(tempFile) {
        result := FileRead(tempFile)
        FileDelete(tempFile)
        return Trim(result)
    }

    return "Nicht gefunden"
}
SetVlanId(id) {
    global frmVLAN, NetzwerkDDL
    ; v := VlanSetter(NetzwerkDDL.text, id)

    VlanSetter(NetzwerkDDL.text, id)
    Sleep(500)
    NetzwerkKartenAktualisieren()
    ;MsgBox("VLAN auf '" id "' gesetzt.")
}
GetVlanId() {
    global NetzwerkDDL, frmVLAN
    adapterName := StrReplace(NetzwerkDDL.Text, "'", "''")
    psCommand := "Get-NetAdapterAdvancedProperty -Name '" adapterName "' -DisplayName 'Vlan*' -ErrorAction SilentlyContinue | Select-Object -ExpandProperty DisplayValue"
    command := "powershell.exe -NoProfile -NonInteractive -Command " Chr(34) psCommand Chr(34)
    try {
        NetzwerkStartAsyncAbfrage("VLAN", command, NetzwerkDDL.Text)
    } catch {
        frmVLAN.Value := "0"
    }
}

showNetzwerkInfo() {
    global NetzwerkDDL, frmIP, frmSubnetz, frmGateway, frmDNS, chbDHCP, pingZiele, frmGateway
    infoDHCP := "DHCP: " (chbDHCP.Value ? "Ja" : "Nein")

    infoNetzwerk := "-" NetzwerkDDL.Text "-" "`s`s`s`s" infoDHCP
    infoIP := "IP:" "`s`s`s`s`s`s`s`s`s`s`s`s`s`s`s`s`s`s" frmIP.Value
    infoSubnetz := "Subnetzmaske: " frmSubnetz.Value
    infoGateway := "Gateway: " "`s`s`s`s`s`s" frmGateway.Value
    infoDNS := "DNS-Server: " "`s`s" frmDNS.Value

    ss := [infoNetzwerk, infoIP, infoSubnetz, infoGateway, infoDNS, infoDHCP]
    ;MsgBox(Join(ss, " "))
    A_IconTip := infoNetzwerk "`n" infoIP "`n" infoGateway "`n" infoDNS
    ; A_IconTip := Join(ss, "`n")

}
letzteNetzwerkKarte(aktion) {
    global NetzwerkDDL
    lines := GetAppDataLines()

    if (aktion = "lesen") {
        gespeicherteKarte := ""
        for line in lines {
            teile := StrSplit(line, ";")
            if (teile.Length >= 2 && teile[1] = "letzteNetzwerkKarte") {
                gespeicherteKarte := teile[2]
                break
            }
        }
        for Eintrag in ControlGetItems(NetzwerkDDL) {
            if (Eintrag = gespeicherteKarte) {
                NetzwerkDDL.Text := Eintrag
                return Eintrag
            }
        }
        return ""
    }

    if (aktion = "schreiben") {
        found := false
        for index, line in lines {
            teile := StrSplit(line, ";")
            if (teile[1] = "letzteNetzwerkKarte") {
                lines[index] := "letzteNetzwerkKarte;" NetzwerkDDL.Text
                found := true
                break
            }
        }
        if (!found)
            lines.InsertAt(1, "letzteNetzwerkKarte;" NetzwerkDDL.Text)
        SaveAppDataLines(lines)
    }
}

ÖffneNetzwerkEinstellungen(*) {
    Run "ms-settings:network"
}
ProfilListDoppelGeklickt(*) {
    global ProfilList
    LadeProfil(ProfilList.Text)
}
ProfilListGeklickt(item, *) {
    global ProfilList
    ; Speichern-Button aktivieren, wenn Profil geklickt wurde
    ;ProfilBtnSave.Enabled := true

    ;MsgBox(item.Text)
}
ProfilListRechtsGeklickt(item, *) {
    global ProfilList
    if (ProfilList.Focused) {

        profilMenu := Menu()

        profilMenu.Add("Gewählt: " item.Text, void)
        profilMenu.Add()
        profilMenu.Add("Profil neu", NeuesProfil)
        profilMenu.Add("Profil umbenennen", UmbenennenProfil)
        profilMenu.Add("Profil laden", ProfilListDoppelGeklickt)
        profilMenu.Add("Profil speichern", SpeichereProfil)
        profilMenu.Add("Profil speichern unter", SpeichernUnterProfil)
        profilMenu.Add("Profil löschen", LöscheProfil)
        profilMenu.Show()
    }
}
UmbenennenProfil(*) {
    global chbDHCP, frmIP, frmSubnetz, frmGateway, frmDNS, frmVLAN, ProfilList
    profilNameAlt := ProfilList.Text
    IB := InputBox("Bitte Profilnamen eingeben", "Profil umbenennen", "w300 h130", profilNameAlt)
    if (IB.Result != "OK")
        return
    ProfilName := Trim(IB.Value)
    if (ProfilName = "") {
        MsgBox("Profilname darf nicht leer sein.", , "Fehler")
        return
    }

    lines := GetAppDataLines()
    for index, line in lines {
        teile := StrSplit(line, ";")
        if (teile.Length >= 2 && teile[1] = "Profil" && teile[2] = profilNameAlt)
            lines[index] := ProfileRecord(ProfilName)
    }
    SaveAppDataLines(lines)
    NetzwerkKartenAktualisieren()
}
SpeichereProfil(*) {
    global ProfilList
    ProfilName := ProfilList.Text
    if (ProfilName = "")
        return

    lines := GetAppDataLines()
    found := false
    for index, line in lines {
        teile := StrSplit(line, ";")
        if (teile.Length >= 2 && teile[1] = "Profil" && teile[2] = ProfilName) {
            lines[index] := ProfileRecord(ProfilName)
            found := true
        }
    }
    if (found) {
        SaveAppDataLines(lines)
        NetzwerkKartenAktualisieren()
    }
}
SpeichernUnterProfil(*) {
    global frmIP
    IB := InputBox("Bitte Profilnamen eingeben", "Profil speichern unter", "w300 h130", frmIP.Value)
    if (IB.Result != "OK")
        return
    ProfilName := Trim(IB.Value)
    if (ProfilName = "") {
        MsgBox("Profilname darf nicht leer sein.", , "Fehler")
        return
    }

    lines := GetAppDataLines()
    for line in lines {
        teile := StrSplit(line, ";")
        if (teile.Length >= 2 && teile[1] = "Profil" && teile[2] = ProfilName) {
            MsgBox("Ein Profil mit diesem Namen existiert bereits. Bitte wählen Sie einen anderen Namen.")
            return
        }
    }
    lines.Push(ProfileRecord(ProfilName))
    SaveAppDataLines(lines)
    NetzwerkKartenAktualisieren()
}
NeuesProfil(*) {
    global frmIP
    IB := InputBox("Bitte Profilnamen eingeben", "Profil neu", "w300 h130", frmIP.Value)
    if (IB.Result != "OK")
        return
    ProfilName := Trim(IB.Value)
    if (ProfilName = "") {
        MsgBox("Profilname darf nicht leer sein.", , "Fehler")
        return
    }

    lines := GetAppDataLines()
    for line in lines {
        teile := StrSplit(line, ";")
        if (teile.Length >= 2 && teile[1] = "Profil" && teile[2] = ProfilName) {
            MsgBox("Ein Profil mit diesem Namen existiert bereits. Bitte wählen Sie einen anderen Namen.")
            return
        }
    }
    lines.Push(ProfileRecord(ProfilName))
    SaveAppDataLines(lines)
    NetzwerkKartenAktualisieren()
}
löscheLeereZeilen() {
    lines := GetAppDataLines()
    SaveAppDataLines(lines)
}
LöscheProfil(*) {
    global ProfilList
    Ergebnis := MsgBox("Profil " ProfilList.Text " löschen?", , "YesNo")
    if (Ergebnis != "Yes")
        return

    lines := GetAppDataLines()
    cleaned := []
    for line in lines {
        teile := StrSplit(line, ";")
        if !(teile.Length >= 2 && teile[1] = "Profil" && teile[2] = ProfilList.Text)
            cleaned.Push(line)
    }
    SaveAppDataLines(cleaned)
    NetzwerkKartenAktualisieren()
}
LadeProfil(Profilname) {
    global chbDHCP, frmIP, frmSubnetz, frmGateway, frmDNS, frmVLAN
    for line in GetAppDataLines() {
        teile := StrSplit(line, ";")
        if (teile.Length >= 7 && teile[1] = "Profil" && teile[2] = Profilname) {
            frmIP.Enabled := true
            frmSubnetz.Enabled := true
            frmGateway.Enabled := true
            frmDNS.Enabled := true
            chbDHCP.Value := teile[3]
            frmIP.Value := teile[4]
            frmSubnetz.Value := teile[5]
            frmGateway.Value := teile[6]
            frmDNS.Value := teile[7]
            frmVLAN.Value := teile.Length >= 8 ? teile[8] : 0
            return
        }
    }
}

ÜbernehmenBtnGeklickt(*) {
    global NetzwerkDDL, chbDHCP, frmIP, frmSubnetz, frmGateway, frmDNS

    selectedKarte := NetzwerkDDL.Text
    if (!selectedKarte)
        return

    ip := Trim(frmIP.Value)
    subnetz := Trim(frmSubnetz.Value)
    gateway := Trim(frmGateway.Value)
    dns := Trim(frmDNS.Value)
    vlanid := Trim(frmVLAN.Value)

    if (chbDHCP.Value) {
        RunWait('netsh interface ip set address name="' selectedKarte '" source=dhcp', , "Hide")
        RunWait('netsh interface ip set dns name="' selectedKarte '" source=dhcp', , "Hide")
        SetVlanId(vlanid)
    } else {
        if (ip = "" || subnetz = "") {
            MsgBox("Bitte IP-Adresse und Subnetzmaske angeben.", , "Fehler")
            return
        }
        else {
            RunWait('netsh interface ip set address name="' selectedKarte '" source=static addr=' . ip . ' mask=' . subnetz ' gateway=' . gateway, , "Hide")
            ;MsgBox(vlanid)
            SetVlanId(vlanid)
        }
        if (dns != "") {
            dnsServers := StrSplit(dns, ",")
            RunWait('netsh interface ip set dns name="' selectedKarte '" source=static addr=' . Trim(dnsServers[1]) . ' register=primary', , "Hide")
        } else {
            RunWait('netsh interface ip set dns name="' selectedKarte '" source=dhcp', , "Hide")
        }
    }
    Sleep(4000)
    NetzwerkKartenAktualisieren()
}
DhcpGewaehlt(*) {
    global chbDHCP, frmIP, frmSubnetz, frmGateway, frmDNS

    if (chbDHCP.Value) {
        frmIP.Enabled := false
        frmSubnetz.Enabled := false
        frmGateway.Enabled := false
        frmDNS.Enabled := false
        frmVLAN.Enabled := true
    } else {
        frmIP.Enabled := true
        frmSubnetz.Enabled := true
        frmGateway.Enabled := true
        frmDNS.Enabled := true
        frmVLAN.Enabled := true

    }
}
Netzwerkkarte_ausgeblendet(netzwerkkarte) {
    for inhalt in GetAppDataLines() {
        if InStr(inhalt, netzwerkkarte)
            return true
    }
    return true
}
NetzwerkKartenAktualisieren(*) {
    global NetzwerkDDL, lblAktuelleKarte, lblAktuelleIP
    global frmIP, frmSubnetz, frmGateway, frmDNS, frmVLAN

    NetzwerkProfileListeLaden()
    frmIP.Enabled := false
    frmSubnetz.Enabled := false
    frmGateway.Enabled := false
    frmDNS.Enabled := false
    frmVLAN.Enabled := true

    if (NetzwerkDDL.Text = "") {
        NetzwerkDDL.Delete()
        NetzwerkDDL.Add(["Netzwerkkarten werden geladen …"])
        NetzwerkDDL.Value := 1
        lblAktuelleKarte.Text := "Netzwerkkarten werden geladen …"
        lblAktuelleIP.Text := "IP: -"
    }
    NetzwerkDDL.Enabled := false

    try {
        NetzwerkStartAsyncAbfrage("Adapterliste", "netsh interface ip show config")
    } catch Error as e {
        NetzwerkDDL.Enabled := true
        lblAktuelleKarte.Text := "Netzwerkkarten konnten nicht geladen werden"
    }
}

NetzwerkProfileListeLaden() {
    global ProfilList
    ProfilList.Delete()
    profilGefunden := false
    for inhalt in GetAppDataLines() {
        teile := StrSplit(inhalt, ";")
        if (teile.Length >= 2 && teile[1] = "Profil") {
            ProfilList.Add([teile[2]])
            profilGefunden := true
        }
    }
    if profilGefunden
        ProfilList.Choose(1)
}

NetzwerkStartAsyncAbfrage(typ, command, adapterName := "", showInfo := false) {
    global NetzwerkQueryJob, NetzwerkQueryGeneration

    SetTimer(NetzwerkAsyncAbfragePruefen, 0)
    if IsObject(NetzwerkQueryJob)
        CancelConsoleCaptureAsync(NetzwerkQueryJob)

    NetzwerkQueryGeneration += 1
    job := StartConsoleCaptureAsync(command)
    job.Kind := typ
    job.AdapterName := adapterName
    job.ShowInfo := showInfo
    job.Generation := NetzwerkQueryGeneration
    NetzwerkQueryJob := job
    SetTimer(NetzwerkAsyncAbfragePruefen, -60)
}

NetzwerkAsyncAbfragePruefen(*) {
    global NetzwerkQueryJob, NetzwerkQueryGeneration
    if !IsObject(NetzwerkQueryJob)
        return

    job := NetzwerkQueryJob
    if ProcessExist(job.Pid) {
        if (A_TickCount - job.StartedAt > 30000) {
            CancelConsoleCaptureAsync(job)
            NetzwerkQueryJob := 0
            NetzwerkAbfrageFehlgeschlagen(job.Kind, job.AdapterName)
            return
        }
        SetTimer(NetzwerkAsyncAbfragePruefen, -100)
        return
    }

    SetTimer(NetzwerkAsyncAbfragePruefen, 0)
    output := FinishConsoleCaptureAsync(job)
    NetzwerkQueryJob := 0
    if (job.Generation != NetzwerkQueryGeneration)
        return

    switch job.Kind {
        case "Adapterliste":
            NetzwerkAdapterlisteGeladen(output)
        case "Adapterdetails":
            NetzwerkAdapterdetailsGeladen(job.AdapterName, output, job.ShowInfo)
        case "VLAN":
            NetzwerkVlanGeladen(job.AdapterName, output)
    }
}

NetzwerkAbfrageFehlgeschlagen(typ, adapterName := "") {
    global NetzwerkDDL, lblAktuelleKarte, lblAktuelleIP
    NetzwerkDDL.Enabled := true
    if (typ = "Adapterliste") {
        lblAktuelleKarte.Text := "Netzwerkkarten konnten nicht geladen werden"
        lblAktuelleIP.Text := "IP: -"
    } else if (typ = "Adapterdetails") {
        lblAktuelleKarte.Text := adapterName
        lblAktuelleIP.Text := "IP: Abfrage fehlgeschlagen"
    }
}

NetzwerkKarteGewaehlt(*) {
    global NetzwerkDDL, lblAktuelleKarte, lblAktuelleIP, start, suppressNetzwerkDDLChange
    if suppressNetzwerkDDLChange
        return

    NetzwerkAdapterAbfrageStarten(true)
}

NetzwerkAdapterAbfrageStarten(showInfo) {
    global NetzwerkDDL, lblAktuelleKarte, lblAktuelleIP, start
    selectedKarte := NetzwerkDDL.Text
    if (selectedKarte = "" || selectedKarte = "Netzwerkkarten werden geladen …")
        return

    lblAktuelleKarte.Text := selectedKarte
    lblAktuelleIP.Text := "IP: wird geladen …"
    try {
        NetzwerkStartAsyncAbfrage("Adapterdetails", 'netsh interface ip show config name="' selectedKarte '"', selectedKarte, showInfo)
    } catch {
        lblAktuelleIP.Text := "IP: Abfrage fehlgeschlagen"
    }
    if (!start)
        letzteNetzwerkKarte("schreiben")
}

NetzwerkAdapterlisteGeladen(output) {
    global NetzwerkDDL, lblAktuelleKarte, lblAktuelleIP, start, suppressNetzwerkDDLChange
    netzwerkKarten := []
    loop Parse, output, "`n", "`r" {
        if (InStr(A_LoopField, "Konfiguration der Schnittstelle")) {
            karte := StrReplace(A_LoopField, "Konfiguration der Schnittstelle", "")
            karte := Trim(StrReplace(karte, '"', ""))
            if (karte != "" && Netzwerkkarte_ausgeblendet(karte))
                netzwerkKarten.Push(karte)
        }
    }

    suppressNetzwerkDDLChange := true
    NetzwerkDDL.Delete()
    if (netzwerkKarten.Length = 0) {
        NetzwerkDDL.Add(["Keine Netzwerkkarte gefunden"])
        NetzwerkDDL.Value := 1
        NetzwerkDDL.Enabled := false
        suppressNetzwerkDDLChange := false
        lblAktuelleKarte.Text := "Keine Netzwerkkarte gefunden"
        lblAktuelleIP.Text := "IP: -"
        return
    }

    for karte in netzwerkKarten
        NetzwerkDDL.Add([karte])
    NetzwerkDDL.Value := 1
    letzteNetzwerkKarte("lesen")
    NetzwerkDDL.Enabled := true
    suppressNetzwerkDDLChange := false
    NetzwerkAdapterAbfrageStarten(true)
    start := false
}

NetzwerkAdapterdetailsGeladen(adapterName, output, showInfo := false) {
    global NetzwerkDDL, frmIP, frmGateway, lblAktuelleKarte, lblAktuelleIP, pingZiele
    if (NetzwerkDDL.Text != adapterName)
        return

    ParseNetzwerkConfig(output)
    lblAktuelleKarte.Text := adapterName
    lblAktuelleIP.Text := "IP: " frmIP.Value
    for address in [frmGateway.Value, frmIP.Value] {
        if (address != "" && address != "-" && !ArrayEnthält(pingZiele, address))
            pingZiele.Push(address)
    }
    if showInfo
        showNetzwerkInfo()
    GetVlanId()
}

NetzwerkVlanGeladen(adapterName, output) {
    global NetzwerkDDL, frmVLAN
    if (NetzwerkDDL.Text != adapterName)
        return
    value := Trim(output)
    frmVLAN.Value := RegExMatch(value, "m)^\s*(\d+)\s*$", &match) ? match[1] : "0"
}
ParseNetzwerkConfig(configText) {
    global frmIP, frmSubnetz, frmGateway, frmDNS, chbDHCP

    eigenschaften := [
        "DHCP aktiviert",
        "IP-Adresse",
        "Subnetzmaske",
        "Standardgateway",
        "DNS-Server"
    ]

    werte := Map()
    for eigenschaft in eigenschaften {
        werte[eigenschaft] := "-"
    }

    zeilen := StrSplit(configText, "`n", "`r")
    dnsServer := []

    for zeile in zeilen {
        zeile := Trim(zeile)
        if (zeile = "")
            continue

        if (InStr(zeile, "DHCP aktiviert:") = 1) {
            teile := StrSplit(zeile, ":", " `t")
            if (teile.Length >= 2) {
                werte["DHCP aktiviert"] := Trim(teile[2])
            }
        }
        else if (InStr(zeile, "IP-Adresse:") = 1) {
            teile := StrSplit(zeile, ":", " `t")
            if (teile.Length >= 2) {
                werte["IP-Adresse"] := Trim(teile[2])
            }
        }
        else if (InStr(zeile, "Subnetzpr") = 1) {
            pattern := "Maske\s+(\d{1,3}(?:\.\d{1,3}){3})"
            if (RegExMatch(zeile, pattern, &match)) {
                werte["Subnetzmaske"] := match[1]
            }
        }
        else if (InStr(zeile, "Standardgateway:") = 1) {
            teile := StrSplit(zeile, ":", " `t")
            if (teile.Length >= 2) {
                werte["Standardgateway"] := Trim(teile[2])
            }
        }
        else if (InStr(zeile, "DNS-Server:")) {
            teile := StrSplit(zeile, ":", " `t")
            if (teile.Length >= 2 && Trim(teile[2]) != "Keine") {
                dnsServer.Push(Trim(teile[2]))
            }
        }
    }

    if (dnsServer.Length > 0) {
        werte["DNS-Server"] := ""
        for i, server in dnsServer {
            if (i > 1) {
                werte["DNS-Server"] .= ", "
            }
            werte["DNS-Server"] .= server
        }
    } else {
        werte["DNS-Server"] := "-"
    }

    frmIP.Value := werte["IP-Adresse"]
    frmSubnetz.Value := werte["Subnetzmaske"]
    frmGateway.Value := werte["Standardgateway"]
    frmDNS.Value := werte["DNS-Server"]
    chbDHCP.Value := (werte["DHCP aktiviert"] = "Ja") ? 1 : 0
}
createDbIfNotExist() {
    legacyPath := A_ScriptDir "\db.txt"
    data := ReadAppData()

    if (data = "") {
        if FileExist(legacyPath)
            data := FileRead(legacyPath)
        if (Trim(data) = "")
            data := DefaultAppData()
        WriteAppData(data)
    }

    ; Die alte Projektdatei wird erst entfernt, nachdem ein Registry-Wert vorhanden ist.
    ; Wenn sie gesperrt ist, bleibt sie liegen, ohne den Programmstart abzubrechen.
    if (ReadAppData() != "" && FileExist(legacyPath)) {
        try FileDelete(legacyPath)
    }
}
; --- Funktion zum Verbinden von Arrayelementen ---
