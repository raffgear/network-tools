﻿; Logik für den Reiter „Öffentliche IP“.
GetÖffentlicheIP(*) {
    global EditExterneIP, EditLand, EditRegion, EditStadt, EditPLZ, EditISP
    try {
        req := ComObject("WinHttp.WinHttpRequest.5.1")
        url := "https://api.ipify.org"
        req.Open("GET", url, false)
        req.SetRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
        req.Send()
        if (req.Status != 200) {
            throw Error("HTTP-Fehler: " req.Status)
        }
        EditExterneIP.Value := req.ResponseText
        A_Clipboard := req.ResponseText


    } catch {
        MsgBox("Fehler beim Abrufen der öffentlichen IP")
    }

    ; Geolokalisierung der IP-Adresse (optional)
    try {
        req := ComObject("WinHttp.WinHttpRequest.5.1")
        url := "http://ip-api.com/line/" EditExterneIP.Value "?fields=country,region,regionName,city,zip,isp"
        req.Open("GET", url, false)
        req.SetRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
        req.Send()
        if (req.Status != 200) {
            throw Error("HTTP-Fehler: " req.Status)
        }
        daten_geolocation := StrSplit(req.ResponseText, "`n")
        EditLand.Value := daten_geolocation[1]
        EditRegion.Value := daten_geolocation[2]
        EditStadt.Value := daten_geolocation[4]
        EditPLZ.Value := daten_geolocation[5]
        EditISP.Value := daten_geolocation[6]


    } catch {

    }
}
