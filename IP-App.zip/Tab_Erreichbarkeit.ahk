﻿; Logik für den Reiter „Erreichbarkeit“.
BtnInsertZielClick(*) {
    global frmIP, frmGateway, frmDNS, EditZiel, chbDHCP, chbSubnetz, frmSubnetz, frmVLAN, btnSaveNotiz
    ; 1. Das Menü-Objekt erstellen
    InsertMenu := Menu()
    InsertMenu.Add(frmIP.Value, MenuHandler)
    InsertMenu.Add(frmDNS.Value, MenuHandler)
    InsertMenu.Add(frmGateway.Value, MenuHandler)
    InsertMenu.Add("Zwischenablage", MenuHandler)

    InsertMenu.Show()


    ; Diese Funktion verarbeitet den Klick auf einen Menüpunkt
    MenuHandler(ItemName, ItemPos, MyMenu) {
        ;MsgBox("Du hast gewählt: " . ItemName)
        if ItemName = "Zwischenablage"
            EditZiel.Value := A_Clipboard
        else
            EditZiel.Value := ItemName
    }
}

tncButtonFunktion(*) {
    global tncPortEdit, EditZiel
    ziel := EditZiel.Text
    port := tncPortEdit.Text
    if (ziel = "") {
        MsgBox("Bitte eine Zieladresse eingeben.")
        return
    }
    if (port = "") {
        Run 'powershell.exe -NoExit -Command "Test-NetConnection -ComputerName ' ziel ' -InformationLevel Detailed"'
    } else {
        Run 'powershell.exe -NoExit -Command "Test-NetConnection -ComputerName ' ziel ' -Port ' port ' -InformationLevel Detailed"'
    }
}
DropDownIPChanged(*) {
    global DropDownIP, pingZiele, EditZiel

    EditZiel.Value := pingZiele[DropDownIP.Value][1]
}
tt(t, tm := 1500) {
    ToolTip t
    SetTimer () => ToolTip(), -tm
}
CopyWert(w) {
    A_Clipboard := w
    tt(w . " wurde in die Zwischenablage kopiert.")
}
;Subnetz Vorgaben
InsertSubnet(*) {
    global chbDHCP

    if (!chbDHCP.value)
    {
        snMenu := Menu()
        snMenu.Add("255.255.255.0", (*) => InsertSubnet2("255.255.255.0"))
        snMenu.Add("255.255.0.0", (*) => InsertSubnet2("255.255.0.0"))
        snMenu.Add("255.0.0.0", (*) => InsertSubnet2("255.0.0.0"))
        snMenu.Add("255.255.255.128", (*) => InsertSubnet2("255.255.255.128"))
        snMenu.Add("255.255.255.192", (*) => InsertSubnet2("255.255.255.192"))
        snMenu.Add("255.255.255.224", (*) => InsertSubnet2("255.255.255.224"))
        snMenu.Add("255.255.255.240", (*) => InsertSubnet2("255.255.255.240"))
        snMenu.Add("255.255.255.248", (*) => InsertSubnet2("255.255.255.248"))
        snMenu.Add("255.255.255.252", (*) => InsertSubnet2("255.255.255.252"))
        snMenu.Add("255.255.255.254", (*) => InsertSubnet2("255.255.255.254"))
        snMenu.Add("255.255.255.255", (*) => InsertSubnet2("255.255.255.255"))
        snMenu.Add("255.255.254.0", (*) => InsertSubnet2("255.255.254.0"))
        snMenu.Add("255.255.252.0", (*) => InsertSubnet2("255.255.252.0"))
        snMenu.Add("255.255.248.0", (*) => InsertSubnet2("255.255.248.0"))
        snMenu.Add("255.255.240.0", (*) => InsertSubnet2("255.255.240.0"))
        snMenu.Add("255.255.224.0", (*) => InsertSubnet2("255.255.224.0"))
        snMenu.Add("255.255.192.0", (*) => InsertSubnet2("255.255.192.0"))
        snMenu.Add("255.255.128.0", (*) => InsertSubnet2("255.255.128.0"))
        snMenu.Add("255.254.0.0", (*) => InsertSubnet2("255.254.0.0"))
        snMenu.Add("255.252.0.0", (*) => InsertSubnet2("255.252.0.0"))
        snMenu.Add("255.248.0.0", (*) => InsertSubnet2("255.248.0.0"))
        snMenu.Add("255.240.0.0", (*) => InsertSubnet2("255.240.0.0"))
        snMenu.Add("255.224.0.0", (*) => InsertSubnet2("255.224.0.0"))
        snMenu.Add("255.192.0.0", (*) => InsertSubnet2("255.192.0.0"))
        snMenu.Add("255.128.0.0", (*) => InsertSubnet2("255.128.0.0"))
        snMenu.Add("254.0.0.0", (*) => InsertSubnet2("254.0.0.0"))
        snMenu.Add("252.0.0.0", (*) => InsertSubnet2("252.0.0.0"))
        snMenu.Add("248.0.0.0", (*) => InsertSubnet2("248.0.0.0"))
        snMenu.Add("240.0.0.0", (*) => InsertSubnet2("240.0.0.0"))
        snMenu.Add("224.0.0.0", (*) => InsertSubnet2("224.0.0.0"))
        snMenu.Add("192.0.0.0", (*) => InsertSubnet2("192.0.0.0"))
        snMenu.Add("128.0.0.0", (*) => InsertSubnet2("128.0.0.0"))

        snMenu.Show()
    }
}
InsertSubnet2(v) {
    frmSubnetz.value := v

}

tracertButtonFunktion(*) {
    global EditZiel
    ziel := EditZiel.Text
    if (ziel = "") {
        MsgBox("Bitte eine Zieladresse eingeben.")
        return
    }
    Run "cmd /k tracert " . ziel
}
pingButtonFunktion(*) {
    global EditZiel
    ziel := EditZiel.Text
    if (ziel = "") {
        MsgBox("Bitte eine Zieladresse eingeben.")
        return
    }
    Run "cmd /k ping -t " . ziel . ""
}
