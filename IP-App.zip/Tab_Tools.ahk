; Logik und Hilfsfenster für den Reiter „Tools“.
#Include "%A_ScriptDir%\tools\Tool_FensterHelfer.ahk"
#Include "%A_ScriptDir%\tools\Tool_FirmwareHelfer.ahk"
#Include "%A_ScriptDir%\tools\Tool_Speedtest.ahk"
#Include "%A_ScriptDir%\tools\Tool_PortErreichbarkeit.ahk"
#Include "%A_ScriptDir%\tools\Tool_IPScanner.ahk"
#Include "%A_ScriptDir%\tools\Tool_DNSAbfrage.ahk"
#Include "%A_ScriptDir%\tools\Tool_Verbindungsmonitor.ahk"
#Include "%A_ScriptDir%\tools\Tool_PortScanner.ahk"
#Include "%A_ScriptDir%\tools\Tool_NaptrSrvScanner.ahk"
#Include "%A_ScriptDir%\tools\Tool_SubnetzRechner.ahk"
#Include "%A_ScriptDir%\tools\Tool_PasswortGenerator.ahk"
#Include "%A_ScriptDir%\tools\Tool_FritzBoxDownloader.ahk"
#Include "%A_ScriptDir%\tools\Tool_LancomDownloader.ahk"

buttonKlick(btn) {
    switch (btn) {
        case 1:
            öffneInternetSpeedtest()
        case 2:
            öffnePortErreichbar()
        case 3:
            öffneIPScanner()
        case 4:
            öffnePortScanner()
        case 5:
            öffneDNSTester()
        case 6:
            öffneNetworkMonitorGui()
        case 7:
            öffneNaptrDnsScanner()

        case 8:
            Run("ms-settings:network")

        case 9:
            Run("taskmgr")

        case 10:
            Run("services.msc")

        case 11:
            Run("devmgmt.msc")

        case 12:
            Run("firewall.cpl")

        case 13:
            Run("ncpa.cpl")

        case 14:
            öffneSubnetzRechner()

        case 15:
            öffnePasswortGenerator()

        case 16:
            Run("eventvwr.msc")

        case 17:
            Run("msinfo32.exe")

        case 18:
            Run("resmon.exe")

        case 19:
            Run("diskmgmt.msc")

        case 20:
            öffneFritzBoxDownloader()

        case 21:
            öffneLancomDownloader()

        default:
    }
}
