; Netzwerk-Tool: Erreichbarkeit eines Ports prüfen.

global portGuiIsOpen := false
global TimerInterval := 5
global TimerCountdown := 0
global TimerActive := false

öffnePortErreichbar(*) {
    ; nur 1 Fenster zulassen
    global portGuiIsOpen, frmIP_PortGui, frmPort_PortGui, txtErreichbar, btnPortErreichbar, ddTimerInterval
    if (!portGuiIsOpen) {
        gp := Gui()
        gp.Title := "Port-Erreichbarkeit"
        ApplyLightAppTheme(gp, 10)


        gp.SetFont("s19 bold c182230", "Segoe UI")
        gp.Add("Text", "x24 y18 w490 h34 +0x200", "Port-Erreichbarkeit")
        gp.SetFont("s10 c65748B", "Segoe UI")
        gp.Add("Text", "x26 y54 w490 h22 +0x200", "Prüfe, ob ein Ziel im Netzwerk auf einem Port erreichbar ist.")

        gp.SetFont("s10 bold c344054", "Segoe UI")
        gp.Add("Text", "x24 y100 w300 h20 +0x200", "Ziel-IP-Adresse")
        gp.Add("Text", "x350 y100 w166 h20 +0x200", "Ziel-Port")
        gp.SetFont("s11", "Segoe UI")
        frmIP_PortGui := gp.Add("Edit", "x24 y124 w300 h36 Multi -VScroll -Wrap", frmGateway.Value)
        frmPort_PortGui := gp.Add("Edit", "x350 y124 w166 h36 Number Multi -VScroll -Wrap", "443")

        gp.SetFont("s10 bold c344054", "Segoe UI")
        gp.Add("Text", "x24 y190 w300 h20 +0x200", "Prüfintervall")
        gp.SetFont("s12", "Segoe UI")
        ddTimerInterval := gp.Add("DropDownList", "x24 y214 w300 h36 Choose3 r6", ["Aus", "3 Sekunden", "5 Sekunden", "10 Sekunden", "30 Sekunden", "1 Minute"])
        btnPortErreichbar := gp.Add("Button", "x350 y211 w166 h42 Default", "Prüfen")
        btnPortErreichbar.SetFont("s12 bold", "Segoe UI")
        btnPortErreichbar.OnEvent("Click", portErreichbar)

        gp.SetFont("s10 bold c344054", "Segoe UI")
        gp.Add("Text", "x24 y282 w490 h20 +0x200", "Prüfergebnis")
        gp.SetFont("s13 bold", "Segoe UI")
        txtErreichbar := gp.Add("Edit", "x24 y306 w492 h64 Center ReadOnly Multi -VScroll -HScroll", "Noch nicht geprüft")
        txtErreichbar.Opt("BackgroundE9EEF5 c344054")

        gp.SetFont("s9 c65748B", "Segoe UI")
        gp.Add("Text", "x24 y384 w492 h20 +0x200", "Wähle „Aus“ für einen Einzeltest oder ein Intervall für Wiederholungen.")

        gp.OnEvent("Close", (*) => (portGuiIsOpen := false, StopPortTimer()))
        gp.Show("w540 h420")
        CenterPortStatusText(frmIP_PortGui, 20)
        CenterPortStatusText(frmPort_PortGui, 20)
        CenterPortStatusText(txtErreichbar, 23)
        gp.Move(setWindowPos(gp), getWindowInfo(MeineGui).y)
        portGuiIsOpen := true
    }


}
CenterPortStatusText(control, lineHeight := 20) {
    clientRect := Buffer(16, 0)
    if !DllCall("GetClientRect", "Ptr", control.Hwnd, "Ptr", clientRect.Ptr)
        return

    clientWidth := NumGet(clientRect, 8, "Int")
    clientHeight := NumGet(clientRect, 12, "Int")
    lineHeight := Min(lineHeight, clientHeight - 2)
    top := Max(0, Floor((clientHeight - lineHeight) / 2))

    NumPut("Int", 3, clientRect, 0)
    NumPut("Int", top, clientRect, 4)
    NumPut("Int", clientWidth - 3, clientRect, 8)
    NumPut("Int", top + lineHeight, clientRect, 12)
    DllCall("SendMessageW", "Ptr", control.Hwnd, "UInt", 0xB3, "Ptr", 0, "Ptr", clientRect.Ptr, "Ptr")
}
portErreichbar(*) {
    global frmIP_PortGui, frmPort_PortGui, txtErreichbar, ip, port, btnPortErreichbar, ddTimerInterval
    global TimerActive, TimerInterval, TimerCountdown

    ; Timer-Intervall aus Dropdown lesen
    selectedItem := ddTimerInterval.Text
    intervalSeconds := GetIntervalFromSelection(selectedItem)

    if (selectedItem = "Aus") {
        ; Einmalige Prüfung
        StopPortTimer()
        PerformSinglePortTest()
    } else if (TimerActive) {
        ; Timer stoppen falls aktiv
        StopPortTimer()
    } else {
        ; Timer starten
        TimerInterval := intervalSeconds
        StartPortTimer()
    }
}
StartPortTimer() {
    global TimerActive, TimerCountdown, TimerInterval, btnPortErreichbar

    TimerActive := true
    TimerCountdown := TimerInterval
    UpdateButtonText()

    ; Sofort ersten Test durchführen
    PerformPortTest()

    ; Timer starten (1000ms = 1 Sekunde)
    SetTimer PortTimer, 1000
}
StopPortTimer() {
    global TimerActive, btnPortErreichbar, scanPID

    TimerActive := false
    SetTimer PortTimer, 0  ; Timer stoppen
    btnPortErreichbar.Text := "Prüfen"


}
PortTimer() {
    global TimerCountdown, TimerInterval

    TimerCountdown--
    UpdateButtonText()

    if (TimerCountdown <= 0) {
        ; Zeit abgelaufen - Test durchführen
        PerformPortTest()
        TimerCountdown := TimerInterval  ; Reset
    }
}
UpdateButtonText() {
    global TimerActive, TimerCountdown, btnPortErreichbar

    if TimerActive {
        btnPortErreichbar.Text := "Stop (" . TimerCountdown . "s)"
    } else {
        btnPortErreichbar.Text := "Prüfen"
    }
}
PerformPortTest() {
    global frmIP_PortGui, frmPort_PortGui, txtErreichbar, ip, port

    txtErreichbar.Enabled := false
    txtErreichbar.Text := "IP wird überprüft..."
    txtErreichbar.Opt("BackgroundYellow cBlack")

    ip := frmIP_PortGui.Text
    port := frmPort_PortGui.Text

    ; Schneller Ping-Test
    if (!QuickPingTest(ip)) {
        txtErreichbar.Text := "IP nicht erreichbar"
        txtErreichbar.Opt("BackgroundRed cWhite")
        txtErreichbar.Enabled := true
        return
    }

    ; Port-Test nur wenn IP erreichbar
    txtErreichbar.Text := "Port wird überprüft..."
    scanner := PortScanner
    results := scanner.Scan(ip, [port], timeout := 500)

    if (results[port] = "Open") {
        txtErreichbar.Text := "Port erreichbar"
        txtErreichbar.Opt("BackgroundGreen cWhite")
    } else {
        txtErreichbar.Text := "Port nicht erreichbar"
        txtErreichbar.Opt("BackgroundRed cWhite")
    }

    txtErreichbar.Enabled := true
}
PerformSinglePortTest() {
    global frmIP_PortGui, frmPort_PortGui, txtErreichbar, ip, port, btnPortErreichbar

    btnPortErreichbar.Text := "läuft..."
    txtErreichbar.Enabled := false
    txtErreichbar.Text := "IP wird überprüft..."
    txtErreichbar.Opt("BackgroundYellow cBlack")

    ip := frmIP_PortGui.Text
    port := frmPort_PortGui.Text
    btnPortErreichbar.Enabled := false

    ; Schneller Ping-Test
    if (!QuickPingTest(ip)) {
        txtErreichbar.Text := "IP nicht erreichbar"
        txtErreichbar.Opt("BackgroundRed cWhite")
        txtErreichbar.Enabled := true
        btnPortErreichbar.Enabled := true
        btnPortErreichbar.Text := "Prüfen"
        return
    }

    txtErreichbar.Text := "Port wird überprüft..."
    scanner := PortScanner
    results := scanner.Scan(ip, [port], timeout := 500)

    if (results[port] = "Open") {
        txtErreichbar.Text := "Port erreichbar"
        txtErreichbar.Opt("BackgroundGreen cWhite")
    } else {
        txtErreichbar.Text := "Port nicht erreichbar"
        txtErreichbar.Opt("BackgroundRed cWhite")
    }

    txtErreichbar.Enabled := true
    btnPortErreichbar.Enabled := true
    btnPortErreichbar.Text := "Prüfen"
}
GetIntervalFromSelection(selection) {
    switch selection {
        case "3 Sekunden": return 3
        case "5 Sekunden": return 5
        case "10 Sekunden": return 10
        case "30 Sekunden": return 30
        case "1 Minute": return 60
        default: return 5  ; Fallback
    }
}
QuickPingTest(ip) {
    try {
        cmd := 'ping ' ip ' -n 1'
        tempFile := "\port_scan_result.txt"
        cmd := Format('cmd /c ping -n 1 {} > "{}"', ip, tempFile)
        RunWait(cmd, , "Hide")

        ; Datei einlesen und auswerten
        if FileExist(tempFile) {
            output := FileRead(tempFile)
            FileDelete(tempFile)
        }
        return (!InStr(output, "Zielhost"))
    }
    return false
}
scanPortErreichbarkeit() {
    global ip, port, txtErreichbar

    ; Temporäre Datei für Ergebnis
    tempFile := A_Temp "\port_scan_result.txt"

    ; PowerShell-Befehl
    ;Test-NetConnection 192.168.2.10 -Port 80 |% {$_.TcpTestSucceeded}
    psCommand := "Test-NetConnection " ip " -Port " port " |% {$_.TcpTestSucceeded} | Out-File -FilePath '" tempFile "' -Encoding UTF8"

    ;MsgBox(psCommand)
    ; PowerShell ausführen
    RunWait("PowerShell -Command " psCommand, , "Hide")

    ; Ergebnis aus Datei lesen
    if FileExist(tempFile) {
        result := Trim(FileRead(tempFile))
        FileDelete(tempFile)

        if (InStr(result, "t")) {
            ;MsgBox(result)
            txtErreichbar.Text := "Port erreichbar"
            txtErreichbar.Opt("BackgroundGreen cWhite")

        } else {
            ; MsgBox(result)
            txtErreichbar.Text := "Port nicht erreichbar"
            txtErreichbar.Opt("BackgroundRed cWhite")


        }
        btnPortErreichbar.Enabled := true

    }
}