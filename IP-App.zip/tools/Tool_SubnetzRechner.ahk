; Netzwerk-Tool: IPv4-Subnetz-Rechner.

global subnetCalcGuiIsOpen := false
global subnetCalcRange := ""
global subnetCalcIPInput
global subnetCalcPrefixInput
global subnetCalcResults
global subnetCalcStatus

öffneSubnetzRechner(*) {
    global subnetCalcGuiIsOpen, subnetCalcIPInput, subnetCalcPrefixInput
    global subnetCalcResults, subnetCalcStatus, frmIP, frmSubnetz

    if (subnetCalcGuiIsOpen)
        return

    subnetCalcGuiIsOpen := true
    defaultIP := Trim(frmIP.Value)
    if !SubnetCalcIsIPv4(defaultIP)
        defaultIP := "192.168.1.1"

    defaultPrefix := SubnetCalcPrefixFromMask(Trim(frmSubnetz.Value))
    if (defaultPrefix < 0)
        defaultPrefix := 24

    subnetCalcGui := Gui(, "Subnetz-Rechner")
    ApplyLightAppTheme(subnetCalcGui, 10)


    subnetCalcGui.SetFont("s19 bold c182230", "Segoe UI")
    subnetCalcGui.Add("Text", "x24 y18 w600 h34 +0x200", "Subnetz-Rechner")
    subnetCalcGui.SetFont("s10 c65748B", "Segoe UI")
    subnetCalcGui.Add("Text", "x26 y54 w620 h22 +0x200", "Berechnet Netzadresse, Broadcast, Hostbereich und Scan-Range.")

    subnetCalcGui.SetFont("s10 bold c344054", "Segoe UI")
    subnetCalcGui.Add("Text", "x24 y100 w370 h20 +0x200", "IPv4-Adresse")
    subnetCalcGui.Add("Text", "x420 y100 w90 h20 +0x200", "Präfix / CIDR")
    subnetCalcGui.SetFont("s11", "Segoe UI")
    subnetCalcIPInput := subnetCalcGui.Add("Edit", "x24 y124 w370 h36 Multi -VScroll -Wrap", defaultIP)
    subnetCalcPrefixInput := subnetCalcGui.Add("Edit", "x420 y124 w90 h36 Number Multi -VScroll -Wrap", defaultPrefix)
    subnetCalcPrefixSpinner := subnetCalcGui.Add("UpDown", "Range0-32", defaultPrefix)
    subnetCalcPrefixInput.OnEvent("Change", UpdateSubnetCalculation)
    subnetCalcPrefixSpinner.OnEvent("Change", UpdateSubnetCalculation)

    subnetCalcGui.SetFont("s10 bold", "Segoe UI")
    calculateButton := subnetCalcGui.Add("Button", "x530 y121 w126 h42 Default", "Berechnen")
    calculateButton.OnEvent("Click", CalculateSubnet)

    subnetCalcGui.SetFont("s10 bold c344054", "Segoe UI")
    subnetCalcGui.Add("Text", "x24 y184 w400 h22 +0x200", "Ergebnisübersicht")
    subnetCalcResults := []
    resultLabels := ["CIDR-Netz", "Netzadresse", "Subnetzmaske", "Broadcast-Adresse", "Hostbereich", "Nutzbare Hosts", "Scan-Range"]
    loop resultLabels.Length
        subnetCalcResults.Push(SubnetCalcAddResultRow(subnetCalcGui, 210 + (A_Index - 1) * 49, resultLabels[A_Index], A_Index))

    subnetCalcGui.SetFont("s9 c65748B", "Segoe UI")
    subnetCalcGui.Add("Text", "x24 y573 w500 h32 +0x200", "Bei /31 und /32 werden alle Adressen als nutzbare Hosts behandelt.")
    subnetCalcStatus := subnetCalcGui.Add("Text", "x24 y613 w500 h20 +0x200", "")
    subnetCalcGui.SetFont("s10 bold", "Segoe UI")
    copyRangeButton := subnetCalcGui.Add("Button", "x550 y600 w186 h40", "Scan-Range kopieren")
    copyRangeButton.OnEvent("Click", CopySubnetScanRange)

    subnetCalcGui.OnEvent("Close", CloseSubnetCalculator)
    subnetCalcGui.Show("w760 h660")
    CenterSubnetCalcField(subnetCalcIPInput, 20)
    CenterSubnetCalcField(subnetCalcPrefixInput, 20)
    subnetCalcGui.Move(setWindowPos(subnetCalcGui), getWindowInfo(MeineGui).y)
    CalculateSubnet()
}

CalculateSubnet(*) {
    global subnetCalcIPInput, subnetCalcPrefixInput, subnetCalcResults, subnetCalcStatus, subnetCalcRange

    ipText := Trim(subnetCalcIPInput.Value)
    prefixText := Trim(subnetCalcPrefixInput.Value)
    if !SubnetCalcIsIPv4(ipText) {
        MsgBox("Bitte eine gültige IPv4-Adresse eingeben.")
        return
    }
    if !RegExMatch(prefixText, "^\d{1,2}$") || Integer(prefixText) > 32 {
        MsgBox("Der CIDR-Präfix muss zwischen 0 und 32 liegen.")
        return
    }

    prefix := Integer(prefixText)
    addressValue := SubnetCalcIPv4ToUInt(ipText)
    blockSize := 2 ** (32 - prefix)
    networkValue := Floor(addressValue / blockSize) * blockSize
    broadcastValue := networkValue + blockSize - 1
    subnetMaskValue := 4294967295 - blockSize + 1

    if (prefix >= 31) {
        firstHostValue := networkValue
        lastHostValue := broadcastValue
        hostCount := blockSize
    } else {
        firstHostValue := networkValue + 1
        lastHostValue := broadcastValue - 1
        hostCount := Max(0, blockSize - 2)
    }

    networkText := SubnetCalcUIntToIPv4(networkValue)
    maskText := SubnetCalcUIntToIPv4(subnetMaskValue)
    broadcastText := SubnetCalcUIntToIPv4(broadcastValue)
    firstHostText := SubnetCalcUIntToIPv4(firstHostValue)
    lastHostText := SubnetCalcUIntToIPv4(lastHostValue)
    cidrText := networkText "/" prefix
    subnetCalcRange := firstHostText " - " lastHostText

    subnetCalcResults[1].Text := cidrText
    subnetCalcResults[2].Text := networkText
    subnetCalcResults[3].Text := maskText
    subnetCalcResults[4].Text := broadcastText
    subnetCalcResults[5].Text := firstHostText " - " lastHostText
    subnetCalcResults[6].Text := hostCount
    subnetCalcResults[7].Text := subnetCalcRange
    subnetCalcStatus.Text := "Berechnung abgeschlossen."
}

UpdateSubnetCalculation(*) {
    global subnetCalcIPInput, subnetCalcPrefixInput

    ipText := Trim(subnetCalcIPInput.Value)
    prefixText := Trim(subnetCalcPrefixInput.Value)
    if !SubnetCalcIsIPv4(ipText)
        return
    if !RegExMatch(prefixText, "^\d{1,2}$") || Integer(prefixText) > 32
        return

    CalculateSubnet()
}
SubnetCalcAddResultRow(targetGui, y, label, index) {
    isEmphasized := (index = 1 || index = 5 || index = 7)
    if (isEmphasized)
        rowColor := "E4EEFF"
    else if (Mod(index, 2) = 0)
        rowColor := "EDF2F8"
    else
        rowColor := "FFFFFF"

    targetGui.Add("Text", "x24 y" y " w712 h42 Background" rowColor)
    if (isEmphasized)
        targetGui.Add("Text", "x24 y" y " w4 h42 Background3B82F6")

    labelColor := isEmphasized ? "c1D4ED8" : "c667085"
    targetGui.SetFont("s10 bold " labelColor, "Segoe UI")
    targetGui.Add("Text", "x42 y" y " w220 h42 +0x200", label)

    if (isEmphasized)
        targetGui.SetFont("s12 bold c173B75", "Segoe UI")
    else
        targetGui.SetFont("s11 c182230", "Segoe UI")
    return targetGui.Add("Text", "x280 y" y " w438 h42 +0x200", "—")
}
SubnetCalcIsIPv4(address) {
    regex := "^(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$"
    return RegExMatch(address, regex)
}

SubnetCalcIPv4ToUInt(address) {
    octets := StrSplit(address, ".")
    return Integer(octets[1]) * 16777216 + Integer(octets[2]) * 65536 + Integer(octets[3]) * 256 + Integer(octets[4])
}

SubnetCalcUIntToIPv4(value) {
    octet1 := Floor(value / 16777216)
    value := Mod(value, 16777216)
    octet2 := Floor(value / 65536)
    value := Mod(value, 65536)
    octet3 := Floor(value / 256)
    octet4 := Mod(value, 256)
    return octet1 "." octet2 "." octet3 "." octet4
}

SubnetCalcPrefixFromMask(mask) {
    if !SubnetCalcIsIPv4(mask)
        return -1

    prefix := 0
    foundZero := false
    for octetText in StrSplit(mask, ".") {
        octet := Integer(octetText)
        bitValue := 128
        loop 8 {
            bitIsOne := (Floor(octet / bitValue) >= 1)
            if (bitIsOne) {
                if (foundZero)
                    return -1
                prefix += 1
                octet -= bitValue
            } else {
                foundZero := true
            }
            bitValue := bitValue / 2
        }
    }
    return prefix
}

CenterSubnetCalcField(control, lineHeight := 20) {
    clientRect := Buffer(16, 0)
    if !DllCall("GetClientRect", "Ptr", control.Hwnd, "Ptr", clientRect.Ptr)
        return

    clientWidth := NumGet(clientRect, 8, "Int")
    clientHeight := NumGet(clientRect, 12, "Int")
    lineHeight := Min(lineHeight, clientHeight - 2)
    top := Max(0, Floor((clientHeight - lineHeight) / 2))

    NumPut("Int", 3, clientRect, 0)
    NumPut("Int", top, clientRect, 4)
    NumPut("Int", clientWidth - 3, clientRect, 8)
    NumPut("Int", top + lineHeight, clientRect, 12)
    DllCall("SendMessageW", "Ptr", control.Hwnd, "UInt", 0xB3, "Ptr", 0, "Ptr", clientRect.Ptr, "Ptr")
}

CopySubnetScanRange(*) {
    global subnetCalcRange, subnetCalcStatus
    if (subnetCalcRange = "")
        return
    A_Clipboard := subnetCalcRange
    subnetCalcStatus.Text := "Scan-Range in die Zwischenablage kopiert."
}

CloseSubnetCalculator(*) {
    global subnetCalcGuiIsOpen
    subnetCalcGuiIsOpen := false
}












