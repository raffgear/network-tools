; Netzwerk-Tool: IPv4-Subnetz-Rechner.

global subnetCalcGuiIsOpen := false
global subnetCalcRange := ""
global subnetCalcIPInput
global subnetCalcPrefixInput
global subnetCalcResults
global subnetCalcStatus

öffneSubnetzRechner(*) {
    global subnetCalcGuiIsOpen, subnetCalcIPInput, subnetCalcPrefixInput
    global subnetCalcResults, subnetCalcStatus, frmIP, frmSubnetz

    if (subnetCalcGuiIsOpen)
        return

    subnetCalcGuiIsOpen := true
    defaultIP := Trim(frmIP.Value)
    if !SubnetCalcIsIPv4(defaultIP)
        defaultIP := "192.168.1.1"

    defaultPrefix := SubnetCalcPrefixFromMask(Trim(frmSubnetz.Value))
    if (defaultPrefix < 0)
        defaultPrefix := 24

    subnetCalcGui := Gui(, "Subnetz-Rechner")
    ApplyLightAppTheme(subnetCalcGui, 10)


    subnetCalcGui.SetFont("s17 bold c182230", "Segoe UI")
    subnetCalcGui.Add("Text", "x20 y14 w620 h30 +0x200", "Subnetz-Rechner")
    subnetCalcGui.SetFont("s9 c65748B", "Segoe UI")
    subnetCalcGui.Add("Text", "x22 y44 w620 h18 +0x200", "Netzadresse, Broadcast, Hostbereich und Scan-Range auf einen Blick.")

    subnetCalcGui.SetFont("s10 bold c344054", "Segoe UI")
    subnetCalcGui.Add("Text", "x20 y76 w330 h18 +0x200", "IPv4-Adresse")
    subnetCalcGui.Add("Text", "x368 y76 w88 h18 +0x200", "Präfix / CIDR")
    subnetCalcGui.SetFont("s10", "Segoe UI")
    subnetCalcIPInput := subnetCalcGui.Add("Edit", "x20 y97 w330 h32 Multi -VScroll -Wrap", defaultIP)
    subnetCalcPrefixInput := subnetCalcGui.Add("Edit", "x368 y97 w88 h32 Number Multi -VScroll -Wrap", defaultPrefix)
    subnetCalcPrefixSpinner := subnetCalcGui.Add("UpDown", "Range0-32", defaultPrefix)
    subnetCalcPrefixInput.OnEvent("Change", UpdateSubnetCalculation)
    subnetCalcPrefixSpinner.OnEvent("Change", UpdateSubnetCalculation)

    subnetCalcGui.SetFont("s10 bold", "Segoe UI")
    calculateButton := subnetCalcGui.Add("Button", "x474 y97 w126 h34 Default", "Berechnen")
    calculateButton.OnEvent("Click", CalculateSubnet)

    subnetCalcGui.SetFont("s10 bold c344054", "Segoe UI")
    subnetCalcGui.Add("Text", "x20 y146 w400 h20 +0x200", "Ergebnisübersicht")
    subnetCalcResults := []
    resultLabels := ["CIDR-Netz", "Netzadresse", "Subnetzmaske", "Broadcast-Adresse", "Hostbereich", "Nutzbare Hosts", "Scan-Range"]
    loop resultLabels.Length
        subnetCalcResults.Push(SubnetCalcAddResultRow(subnetCalcGui, 171 + (A_Index - 1) * 36, resultLabels[A_Index], A_Index))

    subnetCalcGui.SetFont("s9 c65748B", "Segoe UI")
    subnetCalcGui.Add("Text", "x20 y437 w440 h18 +0x200", "Bei /31 und /32 gelten alle Adressen als nutzbare Hosts.")
    subnetCalcStatus := subnetCalcGui.Add("Text", "x20 y462 w430 h18 +0x200", "")
    subnetCalcGui.SetFont("s10 bold", "Segoe UI")
    copyRangeButton := subnetCalcGui.Add("Button", "x474 y451 w166 h34", "Scan-Range kopieren")
    copyRangeButton.OnEvent("Click", CopySubnetScanRange)

    subnetCalcGui.OnEvent("Close", CloseSubnetCalculator)
    subnetCalcGui.Show("w660 h510")
    CenterSubnetCalcField(subnetCalcIPInput, 20)
    CenterSubnetCalcField(subnetCalcPrefixInput, 20)
    subnetCalcGui.Move(setWindowPos(subnetCalcGui), getWindowInfo(MeineGui).y)
    CalculateSubnet()
}

CalculateSubnet(*) {
    global subnetCalcIPInput, subnetCalcPrefixInput, subnetCalcResults, subnetCalcStatus, subnetCalcRange

    ipText := Trim(subnetCalcIPInput.Value)
    prefixText := Trim(subnetCalcPrefixInput.Value)
    if !SubnetCalcIsIPv4(ipText) {
        MsgBox("Bitte eine gültige IPv4-Adresse eingeben.")
        return
    }
    if !RegExMatch(prefixText, "^\d{1,2}$") || Integer(prefixText) > 32 {
        MsgBox("Der CIDR-Präfix muss zwischen 0 und 32 liegen.")
        return
    }

    prefix := Integer(prefixText)
    addressValue := SubnetCalcIPv4ToUInt(ipText)
    blockSize := 2 ** (32 - prefix)
    networkValue := Floor(addressValue / blockSize) * blockSize
    broadcastValue := networkValue + blockSize - 1
    subnetMaskValue := 4294967295 - blockSize + 1

    if (prefix >= 31) {
        firstHostValue := networkValue
        lastHostValue := broadcastValue
        hostCount := blockSize
    } else {
        firstHostValue := networkValue + 1
        lastHostValue := broadcastValue - 1
        hostCount := Max(0, blockSize - 2)
    }

    networkText := SubnetCalcUIntToIPv4(networkValue)
    maskText := SubnetCalcUIntToIPv4(subnetMaskValue)
    broadcastText := SubnetCalcUIntToIPv4(broadcastValue)
    firstHostText := SubnetCalcUIntToIPv4(firstHostValue)
    lastHostText := SubnetCalcUIntToIPv4(lastHostValue)
    cidrText := networkText "/" prefix
    subnetCalcRange := firstHostText " - " lastHostText

    subnetCalcResults[1].Text := cidrText
    subnetCalcResults[2].Text := networkText
    subnetCalcResults[3].Text := maskText
    subnetCalcResults[4].Text := broadcastText
    subnetCalcResults[5].Text := firstHostText " - " lastHostText
    subnetCalcResults[6].Text := hostCount
    subnetCalcResults[7].Text := subnetCalcRange
    subnetCalcStatus.Text := "Berechnung abgeschlossen."
}

UpdateSubnetCalculation(*) {
    global subnetCalcIPInput, subnetCalcPrefixInput

    ipText := Trim(subnetCalcIPInput.Value)
    prefixText := Trim(subnetCalcPrefixInput.Value)
    if !SubnetCalcIsIPv4(ipText)
        return
    if !RegExMatch(prefixText, "^\d{1,2}$") || Integer(prefixText) > 32
        return

    CalculateSubnet()
}
SubnetCalcAddResultRow(targetGui, y, label, index) {
    rowColor := Mod(index, 2) ? "FFFFFF" : "F0F4F8"
    targetGui.Add("Text", "x20 y" y " w620 h32 Background" rowColor)

    targetGui.SetFont("s9 bold c475467", "Segoe UI")
    targetGui.Add("Text", "x30 y" y " w190 h32 +0x200 Background" rowColor, label)

    valueFont := (index = 1 || index = 5 || index = 7) ? "s10 bold c1849A9" : "s10 bold c182230"
    targetGui.SetFont(valueFont, "Segoe UI")
    return targetGui.Add("Text", "x230 y" y " w398 h32 +0x200 Background" rowColor, "—")
}
SubnetCalcIsIPv4(address) {
    regex := "^(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$"
    return RegExMatch(address, regex)
}

SubnetCalcIPv4ToUInt(address) {
    octets := StrSplit(address, ".")
    return Integer(octets[1]) * 16777216 + Integer(octets[2]) * 65536 + Integer(octets[3]) * 256 + Integer(octets[4])
}

SubnetCalcUIntToIPv4(value) {
    octet1 := Floor(value / 16777216)
    value := Mod(value, 16777216)
    octet2 := Floor(value / 65536)
    value := Mod(value, 65536)
    octet3 := Floor(value / 256)
    octet4 := Mod(value, 256)
    return octet1 "." octet2 "." octet3 "." octet4
}

SubnetCalcPrefixFromMask(mask) {
    if !SubnetCalcIsIPv4(mask)
        return -1

    prefix := 0
    foundZero := false
    for octetText in StrSplit(mask, ".") {
        octet := Integer(octetText)
        bitValue := 128
        loop 8 {
            bitIsOne := (Floor(octet / bitValue) >= 1)
            if (bitIsOne) {
                if (foundZero)
                    return -1
                prefix += 1
                octet -= bitValue
            } else {
                foundZero := true
            }
            bitValue := bitValue / 2
        }
    }
    return prefix
}

CenterSubnetCalcField(control, lineHeight := 20) {
    clientRect := Buffer(16, 0)
    if !DllCall("GetClientRect", "Ptr", control.Hwnd, "Ptr", clientRect.Ptr)
        return

    clientWidth := NumGet(clientRect, 8, "Int")
    clientHeight := NumGet(clientRect, 12, "Int")
    lineHeight := Min(lineHeight, clientHeight - 2)
    top := Max(0, Floor((clientHeight - lineHeight) / 2))

    NumPut("Int", 3, clientRect, 0)
    NumPut("Int", top, clientRect, 4)
    NumPut("Int", clientWidth - 3, clientRect, 8)
    NumPut("Int", top + lineHeight, clientRect, 12)
    DllCall("SendMessageW", "Ptr", control.Hwnd, "UInt", 0xB3, "Ptr", 0, "Ptr", clientRect.Ptr, "Ptr")
}

CopySubnetScanRange(*) {
    global subnetCalcRange, subnetCalcStatus
    if (subnetCalcRange = "")
        return
    A_Clipboard := subnetCalcRange
    subnetCalcStatus.Text := "Scan-Range in die Zwischenablage kopiert."
}

CloseSubnetCalculator(*) {
    global subnetCalcGuiIsOpen
    subnetCalcGuiIsOpen := false
}












