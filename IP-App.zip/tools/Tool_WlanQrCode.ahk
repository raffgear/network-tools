; Netzwerk-Tool: WLAN-Zugangsdaten lokal mit der eingebetteten QR-JavaScript-Bibliothek
; erzeugen. Die WebBrowser-Seite ist eine lokale HTML-Datei und verwendet kein Internet.

global wlanQrGeoeffnet := false
global wlanQrSsidEdit, wlanQrPasswortEdit, wlanQrVerschluesselung, wlanQrGroesse, wlanQrStatus
global wlanQrBrowserControl, wlanQrBrowser, wlanQrTempFile := "", wlanQrQueuedData := ""
global wlanQrBrowserReady := false, wlanQrDatenGueltig := false

öffneWlanQrCode(*) {
    global MeineGui
    global wlanQrGeoeffnet, wlanQrSsidEdit, wlanQrPasswortEdit, wlanQrVerschluesselung
    global wlanQrGroesse, wlanQrStatus, wlanQrBrowserControl, wlanQrBrowser, wlanQrTempFile, wlanQrBrowserReady

    if wlanQrGeoeffnet
        return
    wlanQrGeoeffnet := true
    wlanQrBrowserReady := false

    qrGui := Gui(, "WLAN-QR-Code")
    ApplyLightAppTheme(qrGui, 10)

    qrGui.SetFont("s17 bold c182230", "Segoe UI")
    qrGui.Add("Text", "x22 y16 w455 h34 +0x200", "WLAN-Zugang als QR-Code")
    qrGui.SetFont("s9 c65748B", "Segoe UI")
    qrGui.Add("Text", "x24 y52 w455 h22 +0x200", "Der Code wird offline auf diesem Computer erstellt.")

    qrGui.SetFont("s10 bold c344054", "Segoe UI")
    qrGui.Add("Text", "x24 y88 w180 h22 +0x200", "Netzwerkname (SSID)")
    qrGui.SetFont("s10", "Segoe UI")
    wlanQrSsidEdit := qrGui.Add("Edit", "x24 y112 w270 h34 Multi -VScroll -Wrap", "")
    wlanQrSsidEdit.OnEvent("Change", AktualisiereWlanQr)

    qrGui.SetFont("s10 bold c344054", "Segoe UI")
    qrGui.Add("Text", "x24 y159 w180 h22 +0x200", "Passwort")
    qrGui.SetFont("s10", "Segoe UI")
    wlanQrPasswortEdit := qrGui.Add("Edit", "x24 y183 w270 h34 Multi -VScroll -Wrap", "")
    wlanQrPasswortEdit.OnEvent("Change", AktualisiereWlanQr)

    qrGui.SetFont("s10 bold c344054", "Segoe UI")
    qrGui.Add("Text", "x24 y230 w190 h22 +0x200", "Verschlüsselung")
    qrGui.SetFont("s10", "Segoe UI")
    wlanQrVerschluesselung := qrGui.Add("DropDownList", "x24 y254 w270 r3 Choose1", ["WPA / WPA2", "WEP", "Offen (ohne Passwort)"])
    wlanQrVerschluesselung.OnEvent("Change", AktualisiereWlanQr)

    qrGui.SetFont("s10 bold c344054", "Segoe UI")
    qrGui.Add("Text", "x326 y88 w170 h22 Center +0x200", "Vorschau")
    wlanQrBrowserControl := qrGui.Add("ActiveX", "x314 y116 w196 h196", "Shell.Explorer")
    wlanQrBrowser := wlanQrBrowserControl.Value
    try wlanQrBrowser.Silent := true

    qrGui.SetFont("s9 c65748B", "Segoe UI")
    wlanQrStatus := qrGui.Add("Text", "x24 y316 w491 h24 +0x200", "SSID und Passwort eingeben.")
    qrGui.SetFont("s9 bold c344054", "Segoe UI")
    qrGui.Add("Text", "x310 y347 w48 h28 +0x200", "PNG:")
    qrGui.SetFont("s9", "Segoe UI")
    wlanQrGroesse := qrGui.Add("DropDownList", "x350 y349 w78 h24 r3 Choose2", ["256 px", "512 px", "1024 px"])
    speichernBtn := qrGui.Add("Button", "x433 y347 w82 h28", "Speichern")
    speichernBtn.OnEvent("Click", SpeichereWlanQrPng)

    qrGui.OnEvent("Close", SchliesseWlanQrCode)
    qrGui.OnEvent("Escape", SchliesseWlanQrCode)
    qrGui.Show("w530 h390")
    qrGui.Move(setWindowPos(qrGui), getWindowInfo(MeineGui).y)
    CenterModernEdit(wlanQrSsidEdit, 22)
    CenterModernEdit(wlanQrPasswortEdit, 22)

    wlanQrTempFile := A_Temp "\NetworkTools_WLAN_QR.html"
    WlanQrWriteHtml("")
    wlanQrBrowser.Navigate(WlanQrPathToFileUrl(wlanQrTempFile))
    SetTimer(WlanQrBrowserLoaded, 100)
}

SchliesseWlanQrCode(*) {
    global wlanQrGeoeffnet, wlanQrBrowser, wlanQrTempFile, wlanQrBrowserReady
    wlanQrGeoeffnet := false
    wlanQrBrowserReady := false
    SetTimer(WlanQrBrowserLoaded, 0)
    try wlanQrBrowser.Navigate("about:blank")
    SetTimer(WlanQrDeleteTempFile, -500)
}

WlanQrDeleteTempFile() {
    global wlanQrTempFile
    if (wlanQrTempFile != "")
        try FileDelete(wlanQrTempFile)
}

AktualisiereWlanQr(*) {
    global wlanQrSsidEdit, wlanQrPasswortEdit, wlanQrVerschluesselung, wlanQrStatus
    global wlanQrQueuedData, wlanQrDatenGueltig, wlanQrBrowserReady

    ssid := wlanQrSsidEdit.Value
    passwort := wlanQrPasswortEdit.Value
    typ := wlanQrVerschluesselung.Value = 2 ? "WEP" : (wlanQrVerschluesselung.Value = 3 ? "nopass" : "WPA")

    if (ssid = "") {
        wlanQrDatenGueltig := false
        wlanQrQueuedData := ""
        wlanQrStatus.Text := "Bitte den Netzwerknamen (SSID) eingeben."
        if wlanQrBrowserReady
            WlanQrSetPageData("")
        return
    }
    if (typ != "nopass" && passwort = "") {
        wlanQrDatenGueltig := false
        wlanQrQueuedData := ""
        wlanQrStatus.Text := "Bitte das WLAN-Passwort eingeben."
        if wlanQrBrowserReady
            WlanQrSetPageData("")
        return
    }

    wifi := "WIFI:T:" typ ";S:" WlanQrEscapeField(ssid) ";"
    if (typ != "nopass")
        wifi .= "P:" WlanQrEscapeField(passwort) ";"
    wifi .= ";"

    wlanQrDatenGueltig := true
    wlanQrQueuedData := wifi
    wlanQrStatus.Text := "QR-Code aktualisiert. Die Zugangsdaten werden nicht übertragen."
    if wlanQrBrowserReady
        WlanQrSetPageData(wifi)
}

WlanQrBrowserLoaded() {
    global wlanQrGeoeffnet, wlanQrBrowser, wlanQrBrowserReady, wlanQrQueuedData, wlanQrDatenGueltig
    if !wlanQrGeoeffnet {
        SetTimer(WlanQrBrowserLoaded, 0)
        return
    }
    try {
        if (wlanQrBrowser.ReadyState = 4) {
            wlanQrBrowser.Document.parentWindow.execScript("window.__wlanQrReady = (typeof window.setWlanQrData === 'function');", "JScript")
            if wlanQrBrowser.Document.parentWindow.__wlanQrReady {
                SetTimer(WlanQrBrowserLoaded, 0)
                wlanQrBrowserReady := true
                WlanQrSetPageData(wlanQrQueuedData)
                return
            }
        }
    } catch {
    }
    SetTimer(WlanQrBrowserLoaded, -100)
}

WlanQrSetPageData(wifi) {
    global wlanQrBrowser, wlanQrStatus
    try {
        js := "window.setWlanQrData('" WlanQrJsEscape(wifi) "');"
        wlanQrBrowser.Document.parentWindow.execScript(js, "JScript")
    } catch as err {
        wlanQrStatus.Text := "QR-Erzeugung fehlgeschlagen (Zeile " err.Line "). " err.Message
    }
}

SpeichereWlanQrPng(*) {
    global wlanQrGroesse, wlanQrBrowser, wlanQrBrowserReady, wlanQrDatenGueltig, wlanQrStatus
    if !wlanQrDatenGueltig {
        wlanQrStatus.Text := "Bitte erst gültige WLAN-Daten eingeben."
        return
    }
    if !wlanQrBrowserReady {
        wlanQrStatus.Text := "QR-Code wird noch vorbereitet. Bitte kurz warten."
        return
    }

    groessen := [256, 512, 1024]
    pixel := groessen[wlanQrGroesse.Value]
    ziel := EnvGet("USERPROFILE") "\Downloads\WLAN-QR-Code-" pixel "px.png"
    datei := FileSelect("S16", ziel, "WLAN-QR-Code als PNG speichern", "PNG-Bild (*.png)")
    if (datei = "")
        return
    if (StrLower(SubStr(datei, -4)) != ".png")
        datei .= ".png"

    try {
        wlanQrBrowser.Document.parentWindow.execScript("window.dlResult = renderToDataUrl(" pixel ");", "JScript")
        dataUrl := "" wlanQrBrowser.Document.parentWindow.dlResult
        if (SubStr(dataUrl, 1, 14) != "data:image/png")
            throw Error("Der Browser hat keine PNG-Daten geliefert.")
        komma := InStr(dataUrl, ",")
        if !komma
            throw Error("Die PNG-Bilddaten sind ungültig.")
        bild := WlanQrDecodeBase64(SubStr(dataUrl, komma + 1))
        dateiObj := FileOpen(datei, "w")
        if !IsObject(dateiObj)
            throw Error("Die Zieldatei konnte nicht geöffnet werden.")
        dateiObj.RawWrite(bild)
        dateiObj.Close()
        antwort := MsgBox(
            "PNG-Datei (" pixel " px) wurde erstellt unter:`n`n" datei "`n`nMöchten Sie den Ordner öffnen und die Datei markieren?",
            "WLAN-QR-Code gespeichert",
            "YesNo Iconi"
        )
        if (antwort = "Yes")
            Run('explorer.exe /select,"' datei '"')
        wlanQrStatus.Text := "PNG gespeichert (" pixel " px): " datei
    } catch as err {
        wlanQrStatus.Text := "PNG-Export fehlgeschlagen (Zeile " err.Line "). " err.Message
    }
}

WlanQrWriteHtml(data) {
    global WlanQrHtmlTemplate, wlanQrTempFile
    html := StrReplace(WlanQrHtmlTemplate, "##DATA##", WlanQrJsEscape(data))
    try FileDelete(wlanQrTempFile)
    FileAppend(html, wlanQrTempFile, "UTF-8")
}

WlanQrEscapeField(value) {
    value := StrReplace(value, "\", "\\")
    value := StrReplace(value, ";", "\;")
    value := StrReplace(value, ",", "\,")
    value := StrReplace(value, ":", "\:")
    return StrReplace(value, "`"", "\`"")
}

WlanQrJsEscape(value) {
    value := StrReplace(value, "\", "\\")
    value := StrReplace(value, "'", "\'")
    value := StrReplace(value, "`"", "\`"")
    value := StrReplace(value, "`n", "\n")
    return StrReplace(value, "`r", "\r")
}

WlanQrDecodeBase64(value) {
    size := 0
    if !DllCall("Crypt32\CryptStringToBinaryW", "Str", value, "UInt", 0, "UInt", 1, "Ptr", 0, "UInt*", &size, "Ptr", 0, "Ptr", 0)
        throw Error("PNG-Größe konnte nicht ermittelt werden.")
    imageData := Buffer(size)
    if !DllCall("Crypt32\CryptStringToBinaryW", "Str", value, "UInt", 0, "UInt", 1, "Ptr", imageData.Ptr, "UInt*", &size, "Ptr", 0, "Ptr", 0)
        throw Error("PNG-Daten konnten nicht dekodiert werden.")
    return imageData
}

WlanQrPathToFileUrl(path) {
    result := "file:///"
    normalized := StrReplace(path, "\", "/")
    for _, character in StrSplit(normalized) {
        code := Ord(character)
        if ((code >= 0x30 && code <= 0x39) || (code >= 0x41 && code <= 0x5A)
            || (code >= 0x61 && code <= 0x7A) || character = "/" || character = "-"
            || character = "_" || character = "." || character = "~" || character = ":") {
            result .= character
        } else {
            encoded := Buffer(4)
            count := StrPut(character, encoded, "UTF-8") - 1
            loop count
                result .= Format("%{:02X}", NumGet(encoded, A_Index - 1, "UChar"))
        }
    }
    return result
}

WlanQrHtmlTemplate := "
(
    <!DOCTYPE html>
    <html>
    <head>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta charset='UTF-8'>
    <title>WiFi QR-Code</title>
    <style>
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
      -ms-overflow-style: none;
      background: #f5f5f5;
      font-family: 'Segoe UI', sans-serif;
    }
    .center {
      display: table;
      width: 100%;
      height: 100%;
    }
    .center-inner {
      display: table-cell;
      vertical-align: middle;
      text-align: center;
    }
    #qr {
      display: inline-block;
      vertical-align: middle;
    }
    .err {
      color: #c00;
      font-weight: 600;
      font-size: 12px;
      padding: 8px;
    }
    </style>
    </head>
    <body>
    <div class='center'>
      <div class='center-inner'>
        <canvas id='qr'></canvas>
        <div id='err' class='err'></div>
      </div>
    </div>
    <script>
    window.onerror = function(msg, url, line) {
      var el = document.getElementById('err');
      if (el) el.innerHTML = 'JS-Fehler: ' + msg + ' (Zeile ' + line + ')';
      return false;
    };
    var QR = (function() {
      function zeros(n) { var a = new Array(n); for (var i = 0; i < n; i++) a[i] = 0; return a; }
      function falses(n) { var a = new Array(n); for (var i = 0; i < n; i++) a[i] = false; return a; }
    
      var EXP = new Array(512), LOG = new Array(256);
      for (var i = 0, x = 1; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11D; }
      for (var i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
      function mul(a, b) { return (a && b) ? EXP[LOG[a] + LOG[b]] : 0; }
    
      function rsGen(n) {
        var g = [1];
        for (var i = 0; i < n; i++) {
          var ng = zeros(g.length + 1);
          for (var j = 0; j < g.length; j++) {
            ng[j]   ^= g[j];
            ng[j+1] ^= mul(g[j], EXP[i]);
          }
          g = ng;
        }
        return g;
      }
      function rsEnc(data, n) {
        var g = rsGen(n), res = data.concat(zeros(n));
        for (var i = 0; i < data.length; i++) {
          var c = res[i];
          if (c) for (var j = 1; j < g.length; j++) res[i+j] ^= mul(g[j], c);
        }
        return res.slice(data.length);
      }
    
      var V = [null,
        {ec:10, bl:[[1,16]], al:[]},
        {ec:16, bl:[[1,28]], al:[6,18]},
        {ec:26, bl:[[1,44]], al:[6,22]},
        {ec:18, bl:[[2,32]], al:[6,26]},
        {ec:24, bl:[[2,43]], al:[6,30]},
        {ec:16, bl:[[4,27]], al:[6,34]},
        {ec:18, bl:[[4,31]], al:[6,22,38]},
        {ec:22, bl:[[2,38],[2,39]], al:[6,24,42]},
        {ec:22, bl:[[3,36],[2,37]], al:[6,26,46]},
        {ec:26, bl:[[4,43],[1,44]], al:[6,28,50]}
      ];
      function dataCap(v) {
        var c = 0;
        for (var i = 0; i < V[v].bl.length; i++) c += V[v].bl[i][0] * V[v].bl[i][1];
        return c;
      }
      function chooseVer(n) {
        for (var v = 1; v <= 10; v++) {
          var cb = v <= 9 ? 8 : 16;
          if (4 + cb + n * 8 <= dataCap(v) * 8) return v;
        }
        return -1;
      }
      function encodeData(bytes, v) {
        var cb = v <= 9 ? 8 : 16, cap = dataCap(v), bits = [];
        function put(val, len) { for (var i = len - 1; i >= 0; i--) bits.push((val >> i) & 1); }
        put(4, 4); put(bytes.length, cb);
        for (var i = 0; i < bytes.length; i++) put(bytes[i], 8);
        for (var i = 0; i < 4 && bits.length < cap * 8; i++) bits.push(0);
        while (bits.length % 8) bits.push(0);
        var pad = [0xEC, 0x11], pi = 0;
        while (bits.length < cap * 8) put(pad[pi++ % 2], 8);
        var data = [];
        for (var i = 0; i < bits.length; i += 8) {
          var b = 0;
          for (var j = 0; j < 8; j++) b = (b << 1) | bits[i+j];
          data.push(b);
        }
        return data;
      }
      function buildCW(data, v) {
        var info = V[v], blocks = [], idx = 0;
        for (var g = 0; g < info.bl.length; g++)
          for (var b = 0; b < info.bl[g][0]; b++) {
            var dlen = info.bl[g][1], d = data.slice(idx, idx + dlen);
            idx += dlen;
            blocks.push({ d: d, e: rsEnc(d, info.ec) });
          }
        var result = [], maxD = 0;
        for (var i = 0; i < blocks.length; i++) maxD = Math.max(maxD, blocks[i].d.length);
        for (var i = 0; i < maxD; i++)
          for (var b = 0; b < blocks.length; b++)
            if (i < blocks[b].d.length) result.push(blocks[b].d[i]);
        for (var i = 0; i < info.ec; i++)
          for (var b = 0; b < blocks.length; b++) result.push(blocks[b].e[i]);
        return result;
      }
      function makeMat(v) {
        var size = v * 4 + 17, m = [], f = [];
        for (var i = 0; i < size; i++) { m.push(zeros(size)); f.push(falses(size)); }
        function finder(r, c) {
          for (var i = -1; i <= 7; i++) for (var j = -1; j <= 7; j++) {
            var rr = r + i, cc = c + j;
            if (rr < 0 || rr >= size || cc < 0 || cc >= size) continue;
            var val = 0;
            if (i >= 0 && i <= 6 && j >= 0 && j <= 6)
              val = (i===0||i===6||j===0||j===6||(i>=2&&i<=4&&j>=2&&j<=4)) ? 1 : 0;
            m[rr][cc] = val; f[rr][cc] = true;
          }
        }
        finder(0,0); finder(0,size-7); finder(size-7,0);
        for (var i = 8; i < size - 8; i++) {
          m[6][i] = (i%2===0) ? 1 : 0; f[6][i] = true;
          m[i][6] = (i%2===0) ? 1 : 0; f[i][6] = true;
        }
        var al = V[v].al;
        for (var a = 0; a < al.length; a++) for (var b = 0; b < al.length; b++) {
          var r = al[a], c = al[b];
          if (f[r][c]) continue;
          for (var dr = -2; dr <= 2; dr++) for (var dc = -2; dc <= 2; dc++) {
            var val = (Math.abs(dr)===2||Math.abs(dc)===2||(dr===0&&dc===0)) ? 1 : 0;
            m[r+dr][c+dc] = val; f[r+dr][c+dc] = true;
          }
        }
        m[size-8][8] = 1; f[size-8][8] = true;
        var fp  = [[0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[7,8],[8,8],
                   [size-7,8],[size-6,8],[size-5,8],[size-4,8],[size-3,8],[size-2,8],[size-1,8]];
        var fp2 = [[8,size-1],[8,size-2],[8,size-3],[8,size-4],[8,size-5],[8,size-6],[8,size-7],[8,size-8],
                   [8,7],[8,5],[8,4],[8,3],[8,2],[8,1],[8,0]];
        for (var i = 0; i < 15; i++) { f[fp[i][0]][fp[i][1]] = true; f[fp2[i][0]][fp2[i][1]] = true; }
        return { m: m, f: f, size: size, fp: fp, fp2: fp2 };
      }
      function placeData(mat, cw) {
        var m = mat.m, f = mat.f, size = mat.size, bitIdx = 0, total = cw.length * 8, up = true;
        for (var col = size - 1; col >= 1; col -= 2) {
          if (col === 6) col = 5;
          for (var i = 0; i < size; i++) {
            var row = up ? size - 1 - i : i;
            for (var c = 0; c < 2; c++) {
              var cc = col - c;
              if (f[row][cc]) continue;
              var bit = 0;
              if (bitIdx < total) { bit = (cw[bitIdx >> 3] >> (7 - (bitIdx & 7))) & 1; bitIdx++; }
              m[row][cc] = bit;
            }
          }
          up = !up;
        }
      }
      function maskFn(k, i, j) {
        switch (k) {
          case 0: return (i+j) % 2 === 0;
          case 1: return i % 2 === 0;
          case 2: return j % 3 === 0;
          case 3: return (i+j) % 3 === 0;
          case 4: return (Math.floor(i/2) + Math.floor(j/3)) % 2 === 0;
          case 5: return ((i*j) % 2 + (i*j) % 3) === 0;
          case 6: return (((i*j) % 2 + (i*j) % 3) % 2) === 0;
          case 7: return (((i+j) % 2 + (i*j) % 3) % 2) === 0;
        }
      }
      function applyMask(mat, k) {
        var m = mat.m, f = mat.f, size = mat.size;
        for (var i = 0; i < size; i++) for (var j = 0; j < size; j++)
          if (!f[i][j] && maskFn(k, i, j)) m[i][j] ^= 1;
      }
      function penalty(m) {
        var size = m.length, p = 0;
        for (var i = 0; i < size; i++) {
          var rC = 1, cC = 1;
          for (var j = 1; j < size; j++) {
            if (m[i][j] === m[i][j-1]) rC++; else { if (rC >= 5) p += rC - 2; rC = 1; }
            if (m[j][i] === m[j-1][i]) cC++; else { if (cC >= 5) p += cC - 2; cC = 1; }
          }
          if (rC >= 5) p += rC - 2;
          if (cC >= 5) p += cC - 2;
        }
        for (var i = 0; i < size - 1; i++) for (var j = 0; j < size - 1; j++)
          if (m[i][j] === m[i][j+1] && m[i][j] === m[i+1][j] && m[i][j] === m[i+1][j+1]) p += 3;
        for (var i = 0; i < size; i++) for (var j = 0; j < size - 10; j++) {
          if (m[i][j]&&!m[i][j+1]&&m[i][j+2]&&m[i][j+3]&&m[i][j+4]&&!m[i][j+5]&&m[i][j+6]&&!m[i][j+7]&&!m[i][j+8]&&!m[i][j+9]&&!m[i][j+10]) p += 40;
          if (!m[i][j]&&!m[i][j+1]&&!m[i][j+2]&&!m[i][j+3]&&m[i][j+4]&&!m[i][j+5]&&m[i][j+6]&&m[i][j+7]&&m[i][j+8]&&!m[i][j+9]&&m[i][j+10]) p += 40;
          if (m[j][i]&&!m[j+1][i]&&m[j+2][i]&&m[j+3][i]&&m[j+4][i]&&!m[j+5][i]&&m[j+6][i]&&!m[j+7][i]&&!m[j+8][i]&&!m[j+9][i]&&!m[j+10][i]) p += 40;
          if (!m[j][i]&&!m[j+1][i]&&!m[j+2][i]&&!m[j+3][i]&&m[j+4][i]&&!m[j+5][i]&&m[j+6][i]&&m[j+7][i]&&m[j+8][i]&&!m[j+9][i]&&m[j+10][i]) p += 40;
        }
        var dark = 0;
        for (var i = 0; i < size; i++) for (var j = 0; j < size; j++) if (m[i][j]) dark++;
        p += Math.floor(Math.abs(dark * 100 / (size * size) - 50) / 5) * 10;
        return p;
      }
      function fmtBits(mask) {
        var data = mask, rem = data << 10;
        for (var i = 14; i >= 10; i--) if (rem & (1 << i)) rem ^= 0x537 << (i - 10);
        return ((data << 10) | rem) ^ 0x5412;
      }
      function placeFmt(mat, mask) {
        var fmt = fmtBits(mask), m = mat.m;
        for (var i = 0; i < 15; i++) {
          var bit = (fmt >> i) & 1;
          m[mat.fp[i][0]][mat.fp[i][1]] = bit;
          m[mat.fp2[i][0]][mat.fp2[i][1]] = bit;
        }
      }
      function strToBytes(text) {
        var s = unescape(encodeURIComponent(text));
        var bytes = [];
        for (var i = 0; i < s.length; i++) bytes.push(s.charCodeAt(i));
        return bytes;
      }
      function generate(text) {
        var bytes = strToBytes(text);
        var v = chooseVer(bytes.length);
        if (v < 0) return null;
        var data = encodeData(bytes, v), cw = buildCW(data, v);
        var mat = makeMat(v);
        placeData(mat, cw);
        var best = null, bestP = Infinity;
        for (var k = 0; k < 8; k++) {
          var t = {
            m: (function(arr){ var r=[]; for(var x=0;x<arr.length;x++) r.push(arr[x].slice()); return r; })(mat.m),
            f: mat.f, size: mat.size, fp: mat.fp, fp2: mat.fp2
          };
          applyMask(t, k); placeFmt(t, k);
          var p = penalty(t.m);
          if (p < bestP) { bestP = p; best = t; }
        }
        return best.m;
      }
      return { generate: generate };
    })();
    
    var qrMatrix = null;
    var qrMargin = 4;
    window.dlResult = '';
    
    function layoutCanvas() {
      if (!qrMatrix) return;
      var canvas = document.getElementById('qr');
      var pad = 12;
      var availW = document.documentElement.clientWidth  - pad * 2;
      var availH = document.documentElement.clientHeight - pad * 2;
      if (availW < 40) availW = 40;
      if (availH < 40) availH = 40;
      var avail = availW < availH ? availW : availH;
    
      var size = qrMatrix.length;
      var total = size + qrMargin * 2;
      var cell = Math.floor(avail / total);
      if (cell < 2) cell = 2;
      var cs = cell * total;
    
      canvas.width = cs;
      canvas.height = cs;
      canvas.style.width = cs + 'px';
      canvas.style.height = cs + 'px';
    
      var ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, cs, cs);
      ctx.fillStyle = '#000000';
      for (var i = 0; i < size; i++)
        for (var j = 0; j < size; j++)
          if (qrMatrix[i][j])
            ctx.fillRect((j + qrMargin) * cell, (i + qrMargin) * cell, cell, cell);
    }
    
    window.onresize = layoutCanvas;
    
    window.setWlanQrData = function(text) {
      var canvas = document.getElementById('qr');
      var err = document.getElementById('err');
      if (!text) {
        qrMatrix = null;
        canvas.style.display = 'none';
        err.innerHTML = '';
        return;
      }
      qrMatrix = QR.generate(text);
      if (!qrMatrix) {
        canvas.style.display = 'none';
        err.innerHTML = 'Inhalt zu lang fuer QR-Code.';
        return;
      }
      canvas.style.display = 'inline-block';
      err.innerHTML = '';
      layoutCanvas();
    };
    window.setWlanQrData('##DATA##');
    
    function renderToDataUrl(targetPx) {
      if (!qrMatrix) return '';
      var size = qrMatrix.length;
      var total = size + qrMargin * 2;
      var c = document.createElement('canvas');
      c.width = targetPx; c.height = targetPx;
      var ctx = c.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, targetPx, targetPx);
      ctx.fillStyle = '#000000';
      var cell = targetPx / total;
      for (var i = 0; i < size; i++) {
        for (var j = 0; j < size; j++) {
          if (qrMatrix[i][j]) {
            var x0 = Math.round((j + qrMargin) * cell);
            var y0 = Math.round((i + qrMargin) * cell);
            var x1 = Math.round((j + qrMargin + 1) * cell);
            var y1 = Math.round((i + qrMargin + 1) * cell);
            ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
          }
        }
      }
      return c.toDataURL('image/png');
    }
    </script>
    </body>
    </html>
)"
