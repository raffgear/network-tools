; Netzwerk-Tool: kryptografisch sicherer Passwortgenerator.

global passwortGeneratorGeoeffnet := false
global passwortLaengeSlider
global passwortLaengeAnzeige
global passwortAusgabeEdit
global passwortBuchstabenCheck
global passwortZahlenCheck
global passwortSonderzeichenCheck
global passwortStatusText

öffnePasswortGenerator(*) {
    global MeineGui
    global passwortGeneratorGeoeffnet, passwortLaengeSlider, passwortLaengeAnzeige, passwortAusgabeEdit
    global passwortBuchstabenCheck, passwortZahlenCheck, passwortSonderzeichenCheck, passwortStatusText
    if passwortGeneratorGeoeffnet
        return

    passwortGeneratorGeoeffnet := true
    passwortGui := Gui(, "Passwort-Generator")
    ApplyLightAppTheme(passwortGui, 10)

    passwortGui.SetFont("s18 bold c182230", "Segoe UI")
    passwortGui.Add("Text", "x24 y18 w472 h34 +0x200", "Sicheres Passwort erzeugen")
    passwortGui.SetFont("s10 c65748B", "Segoe UI")
    passwortGui.Add("Text", "x26 y55 w472 h24 +0x200", "Gewählte Zeichenarten werden berücksichtigt, soweit die Länge es zulässt.")

    passwortGui.SetFont("s10 bold c344054", "Segoe UI")
    passwortGui.Add("Text", "x24 y94 w130 h22 +0x200", "Passwortlänge")
    passwortGui.SetFont("s11", "Segoe UI")
    passwortLaengeSlider := passwortGui.Add("Slider", "x24 y117 w280 h40 Range1-24 TickInterval1 ToolTip", 20)
    passwortLaengeSlider.OnEvent("Change", GenerierePasswort)
    passwortGui.SetFont("s9 c65748B", "Segoe UI")
    passwortLaengeAnzeige := passwortGui.Add("Text", "x312 y126 w70 h22 +0x200", "20 Zeichen")
    generierenBtn := passwortGui.Add("Button", "x388 y117 w108 h40", "Neu erzeugen")
    generierenBtn.SetFont("s10 bold", "Segoe UI")
    generierenBtn.OnEvent("Click", GenerierePasswort)

    passwortGui.SetFont("s10 bold c344054", "Segoe UI")
    passwortGui.Add("Text", "x24 y171 w250 h22 +0x200", "Zeichenarten")
    passwortGui.SetFont("s10", "Segoe UI")
    passwortBuchstabenCheck := passwortGui.Add("Checkbox", "x24 y197 w130 h26 Checked", "Buchstaben")
    passwortZahlenCheck := passwortGui.Add("Checkbox", "x166 y197 w100 h26 Checked", "Zahlen")
    passwortSonderzeichenCheck := passwortGui.Add("Checkbox", "x278 y197 w170 h26 Checked", "Sonderzeichen")
    passwortBuchstabenCheck.OnEvent("Click", GenerierePasswort)
    passwortZahlenCheck.OnEvent("Click", GenerierePasswort)
    passwortSonderzeichenCheck.OnEvent("Click", GenerierePasswort)

    passwortGui.SetFont("s10 bold c344054", "Segoe UI")
    passwortGui.Add("Text", "x24 y236 w250 h22 +0x200", "Generiertes Passwort")
    passwortAusgabeEdit := passwortGui.Add("Edit", "x24 y262 w472 h40 ReadOnly Multi -VScroll -Wrap", "")
    passwortAusgabeEdit.SetFont("s12", "Segoe UI")

    passwortStatusText := passwortGui.Add("Text", "x24 y310 w300 h24 +0x200 c65748B", "")
    kopierenBtn := passwortGui.Add("Button", "x344 y308 w152 h40", "Passwort kopieren")
    kopierenBtn.SetFont("s10 bold", "Segoe UI")
    kopierenBtn.OnEvent("Click", KopierePasswort)

    passwortGui.OnEvent("Close", (*) => (passwortGeneratorGeoeffnet := false))
    passwortGui.Show("w520 h366")
    passwortGui.Move(setWindowPos(passwortGui), getWindowInfo(MeineGui).y)
    CenterModernEdit(passwortAusgabeEdit, 22)
    GenerierePasswort()
}

GenerierePasswort(*) {
    global passwortLaengeSlider, passwortLaengeAnzeige, passwortAusgabeEdit
    global passwortBuchstabenCheck, passwortZahlenCheck, passwortSonderzeichenCheck, passwortStatusText
    laenge := passwortLaengeSlider.Value
    passwortLaengeAnzeige.Text := laenge . " Zeichen"

    klein := "abcdefghijklmnopqrstuvwxyz"
    gross := "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    ziffern := "0123456789"
    ; Vom Benutzer gewünschte, kompakte Sonderzeichenauswahl.
    sonder := "?!%+_$#@"
    pool := ""
    gruppen := []
    zeichen := []

    if passwortBuchstabenCheck.Value {
        pool .= klein . gross
        gruppen.Push(klein . gross)
    }
    if passwortZahlenCheck.Value {
        pool .= ziffern
        gruppen.Push(ziffern)
    }
    if passwortSonderzeichenCheck.Value {
        pool .= sonder
        gruppen.Push(sonder)
    }

    if (pool = "") {
        passwortAusgabeEdit.Value := ""
        passwortStatusText.Text := "Bitte mindestens eine Zeichenart auswählen."
        return
    }

    ; Jede gewählte Zeichenart mindestens einmal verwenden, soweit die Länge
    ; das zulässt. Bei kürzerer Länge wird eine zufällige Auswahl getroffen.
    gruppenIndex := gruppen.Length
    while (gruppenIndex > 1) {
        tauschMit := SecureRandomIndex(gruppenIndex)
        temp := gruppen[gruppenIndex]
        gruppen[gruppenIndex] := gruppen[tauschMit]
        gruppen[tauschMit] := temp
        gruppenIndex -= 1
    }
    pflichtAnzahl := Min(laenge, gruppen.Length)
    loop pflichtAnzahl
        zeichen.Push(SubStr(gruppen[A_Index], SecureRandomIndex(StrLen(gruppen[A_Index])), 1))

    if (gruppen.Length > laenge)
        passwortStatusText.Text := "Bei dieser Länge passen nicht alle gewählten Arten hinein."
    else
        passwortStatusText.Text := ""

    loop laenge - zeichen.Length
        zeichen.Push(SubStr(pool, SecureRandomIndex(StrLen(pool)), 1))

    index := zeichen.Length
    while (index > 1) {
        tauschMit := SecureRandomIndex(index)
        temp := zeichen[index]
        zeichen[index] := zeichen[tauschMit]
        zeichen[tauschMit] := temp
        index -= 1
    }

    passwort := ""
    for zeichenTeil in zeichen
        passwort .= zeichenTeil
    passwortAusgabeEdit.Value := passwort
}

SecureRandomIndex(maxWert) {
    if (maxWert < 1 || maxWert > 256)
        throw ValueError("Zufallsbereich muss zwischen 1 und 256 liegen.")

    grenze := 256 - Mod(256, maxWert)
    zufallsByte := Buffer(1, 0)
    loop {
        status := DllCall("bcrypt\BCryptGenRandom", "Ptr", 0, "Ptr", zufallsByte.Ptr, "UInt", 1, "UInt", 2, "UInt")
        if (status != 0)
            throw OSError(status)
        wert := NumGet(zufallsByte, 0, "UChar")
        if (wert < grenze)
            return Mod(wert, maxWert) + 1
    }
}

KopierePasswort(*) {
    global passwortAusgabeEdit
    if (passwortAusgabeEdit.Value = "")
        return
    A_Clipboard := passwortAusgabeEdit.Value
    ToolTip("Passwort in die Zwischenablage kopiert.")
    SetTimer(() => ToolTip(), -1500)
}
