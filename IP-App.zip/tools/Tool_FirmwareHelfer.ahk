; Gemeinsame Helfer zum Lesen der Dateigröße aus Apache-Verzeichnislisten.

FirmwareParseIndexSizes(html) {
    sizes := Map()
    rowPosition := 1
    rowPattern := "is)<tr\b[^>]*>(.*?)</tr>"
    cellPattern := "is)<td\b[^>]*>(.*?)</td>"
    quote := Chr(34)
    linkPattern := "is)<a\s+href=" . quote . "([^" . quote . "]+)" . quote

    while RegExMatch(html, rowPattern, &rowMatch, rowPosition) {
        rowPosition := rowMatch.Pos + rowMatch.Len
        rowHtml := rowMatch[1]
        if !RegExMatch(rowHtml, linkPattern, &linkMatch)
            continue

        href := StrReplace(linkMatch[1], "&amp;", "&")
        cells := []
        cellPosition := 1
        while RegExMatch(rowHtml, cellPattern, &cellMatch, cellPosition) {
            cellPosition := cellMatch.Pos + cellMatch.Len
            cells.Push(Trim(RegExReplace(cellMatch[1], "<[^>]+>", "")))
        }
        if (cells.Length < 3)
            continue

        sizeText := Trim(StrReplace(cells[cells.Length], "&nbsp;", ""))
        sizeText := StrReplace(sizeText, Chr(160), "")
        sizeBytes := FirmwareParseSizeText(sizeText)
        if (sizeBytes > 0)
            sizes[href] := sizeBytes
    }

    ; AVM und LANCOM verwenden teilweise Apache-Indexzeilen ohne <table>:
    ; die Bytes stehen als Klartext hinter </a> und vor dem nächsten Link.
    anchorPosition := 1
    anchorPattern := "is)<a\s+href=" . quote . "([^" . quote . "]+)" . quote . "[^>]*>.*?</a>"
    while RegExMatch(html, anchorPattern, &anchorMatch, anchorPosition) {
        anchorPosition := anchorMatch.Pos + anchorMatch.Len
        href := StrReplace(anchorMatch[1], "&amp;", "&")
        if (href = "" || sizes.Has(href))
            continue

        nextAnchorPosition := 0
        if RegExMatch(html, "i)<a\s+href=", &nextAnchor, anchorPosition)
            nextAnchorPosition := nextAnchor.Pos
        textLength := (nextAnchorPosition > 0) ? nextAnchorPosition - anchorPosition : StrLen(html) - anchorPosition + 1
        trailingText := SubStr(html, anchorPosition, textLength)
        trailingText := RegExReplace(trailingText, "<[^>]*>", " ")
        trailingText := StrReplace(trailingText, "&nbsp;", " ")
        trailingText := StrReplace(trailingText, "&#160;", " ")
        trailingText := StrReplace(trailingText, Chr(160), " ")
        sizeBytes := FirmwareParseSizeText(trailingText)
        if (sizeBytes > 0)
            sizes[href] := sizeBytes
    }
    return sizes
}

FirmwareParseSizeText(sizeText) {
    sizeText := Trim(sizeText)
    if RegExMatch(sizeText, "i)([\d.,]+)\s*([KMGT])(?:I?B)?\s*$", &sizeMatch) {
        amountText := sizeMatch[1]
        if (InStr(amountText, ",") && !InStr(amountText, ".")) {
            if RegExMatch(amountText, ",\d{3}$")
                amountText := StrReplace(amountText, ",", "")
            else
                amountText := StrReplace(amountText, ",", ".")
        } else {
            amountText := StrReplace(amountText, ",", "")
        }
        amount := amountText + 0
        unit := StrUpper(sizeMatch[2])
        multiplier := unit = "K" ? 1024 : unit = "M" ? 1048576 : unit = "G" ? 1073741824 : 1099511627776
        return Round(amount * multiplier)
    }

    ; Bei Apache-Listings wird die Dateigröße oft als reine Bytezahl angegeben.
    if RegExMatch(sizeText, "([\d,]+)\s*$", &sizeMatch) {
        byteText := StrReplace(sizeMatch[1], ",", "")
        if (byteText != "")
            return Integer(byteText)
    }
    return 0
}

FirmwareParseIndexDates(html) {
    dates := Map()
    quote := Chr(34)
    anchorPattern := "is)<a\s+href=" . quote . "([^" . quote . "]+)" . quote . "[^>]*>.*?</a>"
    anchorPosition := 1

    while RegExMatch(html, anchorPattern, &anchorMatch, anchorPosition) {
        anchorPosition := anchorMatch.Pos + anchorMatch.Len
        href := StrReplace(anchorMatch[1], "&amp;", "&")
        if (href = "" || dates.Has(href))
            continue

        nextAnchorPosition := 0
        if RegExMatch(html, "i)<a\s+href=", &nextAnchor, anchorPosition)
            nextAnchorPosition := nextAnchor.Pos
        textLength := (nextAnchorPosition > 0) ? nextAnchorPosition - anchorPosition : StrLen(html) - anchorPosition + 1
        trailingText := SubStr(html, anchorPosition, textLength)
        trailingText := RegExReplace(trailingText, "<[^>]*>", " ")
        trailingText := StrReplace(trailingText, "&nbsp;", " ")
        trailingText := StrReplace(trailingText, "&#160;", " ")
        trailingText := StrReplace(trailingText, Chr(160), " ")

        if RegExMatch(trailingText, "i)(\d{1,2}-[A-Za-z]{3,4}-\d{4}\s+\d{2}:\d{2}|\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}(?::\d{2})?)", &dateMatch)
            dates[href] := dateMatch[1]
    }
    return dates
}

FirmwareFormatGermanDate(dateText) {
    monthNames := ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"]
    monthNumbers := Map("jan", 1, "feb", 2, "mar", 3, "apr", 4, "may", 5, "jun", 6, "jul", 7, "aug", 8, "sep", 9, "sept", 9, "oct", 10, "nov", 11, "dec", 12)

    if RegExMatch(dateText, "i)^(\d{1,2})-([A-Za-z]{3,4})-(\d{4})\s+(.+)$", &dateMatch) {
        monthKey := StrLower(dateMatch[2])
        if !monthNumbers.Has(monthKey)
            return dateText
        return Format("{:02}. {} {} {}", Integer(dateMatch[1]), monthNames[monthNumbers[monthKey]], dateMatch[3], dateMatch[4])
    }

    if RegExMatch(dateText, "^(\d{4})-(\d{2})-(\d{2})\s+(.+)$", &dateMatch) {
        monthNumber := Integer(dateMatch[2])
        if (monthNumber < 1 || monthNumber > 12)
            return dateText
        return Format("{:02}. {} {} {}", Integer(dateMatch[3]), monthNames[monthNumber], dateMatch[1], dateMatch[4])
    }
    return dateText = "" ? "—" : dateText
}

FirmwareAlignListViewHeaderLeft(listView, columnNumber) {
    headerHwnd := DllCall("SendMessageW", "Ptr", listView.Hwnd, "UInt", 0x101F, "Ptr", 0, "Ptr", 0, "Ptr")
    if !headerHwnd
        return

    headerItemSize := (A_PtrSize = 8) ? 72 : 48
    formatOffset := (A_PtrSize = 8) ? 28 : 20
    headerItem := Buffer(headerItemSize, 0)
    NumPut("UInt", 0x0004, headerItem, 0) ; HDI_FORMAT
    headerIndex := columnNumber - 1
    if !DllCall("SendMessageW", "Ptr", headerHwnd, "UInt", 0x120B, "Ptr", headerIndex, "Ptr", headerItem, "Ptr")
        return

    format := NumGet(headerItem, formatOffset, "Int")
    format := format & ~0x0003 ; HDF_JUSTIFYMASK = linksbündig
    NumPut("Int", format, headerItem, formatOffset)
    DllCall("SendMessageW", "Ptr", headerHwnd, "UInt", 0x120C, "Ptr", headerIndex, "Ptr", headerItem, "Ptr")
}

FirmwareFormatSizeMB(byteCount) {
    if (byteCount <= 0)
        return "—"
    sizeMB := byteCount / 1048576
    return StrReplace(Format("{:.2f}", sizeMB), ".", ",") " MB"
}
