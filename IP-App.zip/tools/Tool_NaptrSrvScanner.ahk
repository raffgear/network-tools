; Netzwerk-Tool: NAPTR- und SRV-DNS-Scanner.

global naptrDnsGuiIsOpen := false
Global WaitObj
global naptrDnsServer := ""
global NaptrDnsGui
global dnsUrl := ""
global dropDownnaptrDnsServer

;--------Start Naptr DNS Scanner----------------
öffneNaptrDnsScanner(*) {
    global naptrDnsGuiIsOpen, dnsUrl, dropDown, dropDownnaptrDnsServer, lvNAPTR, lvSRV, NaptrDnsGui
    if (!naptrDnsGuiIsOpen) {
        naptrDnsGuiIsOpen := true
        NaptrDnsGui := Gui("", "Telekom DNS: NAPTR & SRV Check")
        NaptrDnsGui.OnEvent("Close", (*) => naptrDnsGuiIsOpen := false)
        ApplyLightAppTheme(NaptrDnsGui, 10)

        ; NAPTR Tabelle (mehr Höhe, da nur 4 Zeilen – besser sichtbar)
        NaptrDnsGui.Add("Text", "x10", "VoIP-Server-Url")

        dropDown := NaptrDnsGui.Add("DropDownList", "Choose1 w200 x250 y32", ["tel.t-online.de", "reg.sip-trunk.telekom.de"])
        dropDown.OnEvent("Change", (*) => url.Value := dropDown.Text)
        dropDown.SetFont("s10", "Segoe UI")

        url := NaptrDnsGui.Add("Edit", "w200 h27 x30 y32 -Multi -Wrap")
        url.Value := "tel.t-online.de"
        url.SetFont("s10 bold", "Segoe UI")

        NaptrDnsGui.Add("Text", "x10 y68", "DNS-Server-Url")
        dropDownnaptrDnsServer := NaptrDnsGui.Add("DropDownList", "Choose1 w200 x250 y90", ["default", "8.8.8.8", "1.1.1.1", "9.9.9.9", "217.0.43.177", "217.0.43.161", "194.25.0.70", "194.25.0.62", "194.25.0.54"])
        dropDownnaptrDnsServer.OnEvent("Change", changenaptrDnsServer)
        dropDownnaptrDnsServer.SetFont("s10", "Segoe UI")

        dnsUrl := NaptrDnsGui.Add("Edit", "w200 h27 x30 y90 -Multi -Wrap")
        dnsUrl.Value := "default"
        dnsUrl.SetFont("s10 bold", "Segoe UI")

        NaptrDnsGui.Add("Text", "x10", "NAPTR Records").SetFont("s10 bold", "Segoe UI")
        lvNAPTR := NaptrDnsGui.Add("ListView", "w600 h100 x10", ["Order", "Preference", "Flags", "Services", "Replacement"])
        lvNAPTR.SetFont("s10", "Segoe UI")

        ; SRV Tabelle
        NaptrDnsGui.Add("Text", , "SRV Records").SetFont("s10 bold", "Segoe UI")
        lvSRV := NaptrDnsGui.Add("ListView", "w600 h270 x10", ["Replacement", "NameTarget", "Priority", "Weight", "Port"])
        lvSRV.SetFont("s10", "Segoe UI")


        ; Listview Titel formatieren
        hwndHeader := SendMessage(0x101F, 0, 0, lvNAPTR.Hwnd) ; LVM_GETHEADER = 0x101F
        hwndHeader2 := SendMessage(0x101F, 0, 0, lvSRV.Hwnd) ; LVM_GETHEADER = 0x101F
        hFont := DllCall("CreateFontW", "int", -14,      ; Höhe (Punkt, negativ)
            "int", 0,           ; Breite
            "int", 0,           ; Escapement
            "int", 0,           ; Orientierung
            "int", 700,     ; Fett
            "uint", 0,          ; Italic
            "uint", 0,          ; Underline
            "uint", 0,          ; StrikeOut
            "uint", 0x1,        ; Zeichensatz (DEFAULT)
            "uint", 0,          ; Ausgabepräzision
            "uint", 0,          ; Clip-Präzision
            "uint", 0,          ; Qualität
            "uint", 0,          ; Pitch & Family
            "wstr", "Segoe UI", ; Schriftname
            "ptr")
        ; oder "Consolas" je nach GUI-Schrift
        SendMessage(0x30, hFont, 1, hwndHeader)
        SendMessage(0x30, hFont, 1, hwndHeader2)

        btn := NaptrDnsGui.Add("Button", "w120 h90 x480 y30", "Start")
        btn.SetFont("s12 bold", "Segoe UI")
        btn.OnEvent("Click", (*) => CheckDNS(url.Value))

        ; Fenstergröße explizit setzen
        NaptrDnsGui.Show("w620")
        NaptrDnsGui.Move(setWindowPos(NaptrDnsGui), getWindowInfo(MeineGui).y)


    }
}

changenaptrDnsServer(*) {
    global naptrDnsServer, dnsUrl, naptrDnsGuiisOpen, dropDownnaptrDnsServer
    dnsUrl.Value := dropDownnaptrDnsServer.Text
    if (dropDownnaptrDnsServer.Text == "default") {
        naptrDnsServer := ""
    }
    else {
        naptrDnsServer := "-Server " . dropDownnaptrDnsServer.Text
    }

}

CheckDNS(url) {
    Global WaitObj, naptrDnsServer
    WaitObj := StartAnimation("DNS Abfrage läuft...", "Bitte warten...")
    ; ==========================================
    ; TEMPORÄRE DATEIEN
    ; ==========================================
    tempPS1 := A_Temp "\dns_full_check.ps1"
    tempNAPTR := A_Temp "\dns_naptr.csv"
    tempSRV := A_Temp "\dns_srv.csv"

    ; ==========================================
    ; POWERSHELL SCRIPT MIT TRENNERN IN SRV-TABELLE
    ; ==========================================
    psCode := "
    (
        $ErrorActionPreference = 'SilentlyContinue'
        $domain = 'tel.t-online.de'
        
        # 1. NAPTR Abfrage
        $naptr = Resolve-DnsName -Name $domain -Type ANY naptrDnsServer| Where-Object { $_.QueryType -eq 35 }
        
        $naptrResults = foreach ($rec in $naptr) {
            $bytes = $rec.Data
            if ($null -eq $bytes -or $bytes.Length -lt 40) { continue }
        
            $order = [uint16]($bytes[1] -shl 8) -bor $bytes[0]
            $pref  = [uint16]($bytes[3] -shl 8) -bor $bytes[2]
        
            $text = [System.Text.Encoding]::Unicode.GetString($bytes, 40, $bytes.Length - 40)
            $parts = $text.Split([char]0) | Where-Object { $_ -ne '' }
        
            $flags       = if ($parts.Count -gt 0) { $parts[0] } else { '' }
            $services    = if ($parts.Count -gt 1) { $parts[1] } else { '' }
            $replacement = if ($parts.Count -gt 2) { $parts[2] } else { '' }
        
            [PSCustomObject]@{
                Order       = $order
                Preference  = $pref
                Flags       = $flags
                Services    = $services
                Replacement = $replacement
            }
        }
        
        # NAPTR CSV nur bei Daten
        if ($naptrResults) {
            $naptrResults | Export-Csv -Path '###NAPTRCSV###' -NoTypeInformation
        }
        
        # 2. SRV Abfragen sammeln MIT TRENNERN
        $allSRV = @()
        foreach ($row in $naptrResults) {
            if ($row.Replacement -and $row.Replacement -match '\.') {
                # Trenner vor neuem Replacement (außer beim ersten)
                if ($allSRV.Count -gt 0) {
                    $allSRV += [PSCustomObject]@{
                        Replacement = '--------------------'
                        NameTarget  = ''
                        Priority    = ''
                        Weight      = ''
                        Port        = ''
                    }
                }
                # Überschrift mit dem Replacement
        
                # SRV Abfrage
                $srv = Resolve-DnsName -Name $row.Replacement -Type SRV
                if ($srv) {
                    foreach ($rec in @($srv)) {
                        $allSRV += [PSCustomObject]@{
                            Replacement = $row.Replacement
                            NameTarget  = $rec.NameTarget
                            Priority    = $rec.Priority
                            Weight      = $rec.Weight
                            Port        = $rec.Port
                        }
                    }
                } else {
                    $allSRV += [PSCustomObject]@{
                        Replacement = $row.Replacement
                        NameTarget  = '(keine SRV Einträge)'
                        Priority    = ''
                        Weight      = ''
                        Port        = ''
                    }
                }
            }
        }
        
        # SRV CSV nur bei Daten
        if ($allSRV) {
            $allSRV | Export-Csv -Path '###SRVCSV###' -NoTypeInformation
        }
    )"


    ; Pfade in PowerShell-Code einsetzen
    psCode := StrReplace(psCode, "###NAPTRCSV###", tempNAPTR)
    psCode := StrReplace(psCode, "###SRVCSV###", tempSRV)
    psCode := StrReplace(psCode, 'tel.t-online.de', url)
    psCode := StrReplace(psCode, 'naptrDnsServer', naptrDnsServer)

    ; ==========================================
    ; ALTE DATEIEN ENTFERNEN & SCRIPT SPEICHERN
    ; ==========================================
    if FileExist(tempPS1)
        FileDelete(tempPS1)
    if FileExist(tempNAPTR)
        FileDelete(tempNAPTR)
    if FileExist(tempSRV)
        FileDelete(tempSRV)

    FileAppend(psCode, tempPS1, "UTF-8")

    ; ==========================================
    ; POWERSHELL AUSFÜHREN (IM HINTERGRUND)
    ; ==========================================
    RunWait('powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' tempPS1 '"', , "Hide")
    ; ==========================================
    ; TABELLEN LEEREN
    ; ==========================================
    lvNAPTR.Delete()
    lvSRV.Delete()

    ; ==========================================
    ; TABELLEN AUS CSV BEFÜLLEN
    ; ==========================================

    FillListView(lvNAPTR, tempNAPTR)
    FillListView(lvSRV, tempSRV)

    ; Spaltenbreiten automatisch am Inhalt und Header orientieren
    Loop 5
        lvNAPTR.ModifyCol(A_Index, "AutoHdr")
    Loop 5
        lvSRV.ModifyCol(A_Index, "AutoHdr")

    ; ==========================================
    ; AUFRÄUMEN
    ; ==========================================
    if FileExist(tempPS1)
        FileDelete(tempPS1)
    if FileExist(tempNAPTR)
        FileDelete(tempNAPTR)
    if FileExist(tempSRV)
        FileDelete(tempSRV)
    StopAnimation(WaitObj)

}
; ==========================================
; HILFSFUNKTION: CSV IN LISTVIEW LADEN
; ==========================================
FillListView(lv, csvPath) {
    if !FileExist(csvPath)
        return
    if FileGetSize(csvPath) = 0
        return

    content := FileRead(csvPath, "UTF-8")
    lines := StrSplit(content, "`n", "`r")
    if lines.Length <= 1   ; nur Header oder leer
        return

    ; erste Zeile (Header) überspringen
    Loop lines.Length - 1 {
        line := Trim(lines[A_Index + 1])
        if line = ""
            continue

        ; CSV-Zeile parsen (entfernt Anführungszeichen)
        fields := []
        pos := 1
        lineLen := StrLen(line)
        while pos <= lineLen {
            if (SubStr(line, pos, 1) = '"') {
                ; Feld in Anführungszeichen
                endQuote := InStr(line, '"', , pos + 1)
                if !endQuote
                    break
                field := SubStr(line, pos + 1, endQuote - pos - 1)
                fields.Push(field)
                pos := endQuote + 1
                ; Komma nach Anführungszeichen überspringen
                if (SubStr(line, pos, 1) = ",")
                    pos++
            } else {
                ; Feld ohne Anführungszeichen
                nextComma := InStr(line, ",", , pos)
                if !nextComma
                    nextComma := lineLen + 1
                field := Trim(SubStr(line, pos, nextComma - pos))
                fields.Push(field)
                pos := nextComma + 1
            }
        }

        ; Zeile zur ListView hinzufügen – mit leerem Options-String
        if fields.Length > 0
            lv.Add("", fields*)
    }
}

StartAnimation(Titel, Untertext := "") {
    global NaptrDnsGui
    NaptrDnsGui.GetPos(&X, &Y, &Width, &Height)

    ;MsgBox "X: " X "`nY: " Y "`nBreite: " Width "`nHöhe: " Height
    ; Erstellt ein kompaktes Lade-Fenster
    AniGui := Gui("-Caption +Border +AlwaysOnTop", "WaitGui")
    ApplyLightAppTheme(AniGui, 10)

    AniGui.SetFont("s10 bold", "Segoe UI")
    AniGui.Add("Text", "w300 Center", Titel)

    if (Untertext != "") {
        AniGui.SetFont("s9", "Segoe UI")
        AniGui.Add("Text", "w300 Center c65748B", Untertext)
    }

    ; Erstellt den Marquee-Balken (Style +0x8)
    ; c0078D7 ist das klassische Windows-Blau
    prg := AniGui.Add("Progress", "w240 h12 c3B82F6 +0x8", 0)

    AniGui.Show("w320 h90")
    AniGui.Move(X + (Width - 320) // 2, Y + (Height - 90) // 2) ; Zentriert über NaptrDnsGui

    ; Nachricht an Windows senden: Starte die unendliche Bewegung
    ; 0x40A = PBM_SETMARQUEE | 1 = Start | 50 = Geschwindigkeit (ms)
    SendMessage(0x40A, 1, 50, prg.Hwnd)

    return AniGui ; Rückgabe des Objekts zum späteren Schließen
}

StopAnimation(GuiObj) {
    if (IsObject(GuiObj))
        GuiObj.Destroy()
}


;--------Ende Naptr DNS Scanner----------------



