; LANCOM-Firmware aus dem offiziellen LANCOM FTP-Verzeichnis anzeigen und laden.

global lancomDownloaderOpen := false
global lancomDownloaderGui
global lancomChannelList
global lancomDeviceList
global lancomSearchEdit
global lancomContentList
global lancomPathText
global lancomTargetEdit
global lancomStatusText
global lancomDownloadButton
global lancomDeviceEntries := []
global lancomVisibleDeviceEntries := []
global lancomChannelEntries := []
global lancomFileEntries := []
global lancomScanFolders := []
global lancomVisitedFolders := Map()
global lancomCurrentModelLabel := ""
global lancomScanFolderCount := 0
global lancomScanErrorCount := 0
global lancomScanGeneration := 0
global lancomTargetFolder := ""
global lancomDownloadPid := 0
global lancomDownloadActive := false
global lancomDownloadScriptPath := ""
global lancomDownloadStatusPath := ""
global lancomDownloadPartialPath := ""
global lancomDownloadTargetPath := ""
global lancomDownloadFileName := ""

öffneLancomDownloader(*) {
    global MeineGui, lancomDownloaderOpen, lancomDownloaderGui
    global lancomChannelList, lancomDeviceList, lancomSearchEdit, lancomContentList, lancomPathText
    global lancomTargetEdit, lancomStatusText, lancomDownloadButton
    global lancomTargetFolder

    if lancomDownloaderOpen {
        try WinActivate("ahk_id " lancomDownloaderGui.Hwnd)
        return
    }

    lancomDownloaderOpen := true
    if (lancomTargetFolder = "" || !DirExist(lancomTargetFolder))
        lancomTargetFolder := LancomGetDownloadsFolder()
    lancomDownloaderGui := Gui(, "LANCOM Firmware-Downloader")
    ApplyLightAppTheme(lancomDownloaderGui, 10)

    lancomDownloaderGui.SetFont("s18 bold c182230", "Segoe UI")
    lancomDownloaderGui.Add("Text", "x24 y18 w820 h34", "LANCOM Firmware")
    lancomDownloaderGui.SetFont("s10 c65748B", "Segoe UI")
    lancomDownloaderGui.Add("Text", "x26 y54 w840 h22", "LANCOM FTP-Verzeichnis durchsuchen und Firmware in einen Ordner deiner Wahl laden.")

    lancomDownloaderGui.SetFont("s10 bold c344054", "Segoe UI")
    lancomDownloaderGui.Add("Text", "x24 y88 w250 h22", "Release-Kanal")
    lancomPathText := lancomDownloaderGui.Add("Text", "x294 y88 w582 h22", "Unterordner und Downloads — Modell auswählen")
    lancomDownloaderGui.SetFont("s10", "Segoe UI")
    lancomChannelList := lancomDownloaderGui.Add("DropDownList", "x24 y112 w250 r6", [])
    lancomSearchEdit := lancomDownloaderGui.Add("Edit", "x24 y150 w214 h32 Multi -VScroll -Wrap", "")
    DllCall("SendMessageW", "Ptr", lancomSearchEdit.Hwnd, "UInt", 0x1501, "Ptr", 1, "Str", "Modell suchen, z. B. LC-1790VA", "Ptr")
    clearSearchButton := lancomDownloaderGui.Add("Button", "x242 y150 w32 h32", "x")
    clearSearchButton.SetFont("s9 bold", "Segoe UI")
    clearSearchButton.OnEvent("Click", LancomClearSearch)
    lancomDeviceList := lancomDownloaderGui.Add("ListBox", "x24 y188 w250 h344", [])
    lancomContentList := lancomDownloaderGui.AddListView("x294 y112 w582 h420", ["Unterordner", "Datei", "Größe", "Geändert"])
    lancomContentList.ModifyCol(1, 120)
    lancomContentList.ModifyCol(2, 230)
    lancomContentList.ModifyCol(3, 75)
    lancomContentList.ModifyCol(4, 120)
    lancomChannelList.OnEvent("Change", LancomLoadDevices)
    lancomSearchEdit.OnEvent("Change", LancomApplyModelFilter)
    lancomDeviceList.OnEvent("Change", LancomDeviceSelected)
    lancomContentList.OnEvent("ItemSelect", LancomContentSelected)
    lancomContentList.OnEvent("DoubleClick", LancomContentActivated)

    refreshButton := lancomDownloaderGui.Add("Button", "x24 y542 w250 h34", "Geräteliste aktualisieren")
    refreshButton.OnEvent("Click", LancomLoadModels)
    lancomDownloaderGui.SetFont("s9 bold c344054", "Segoe UI")
    lancomDownloaderGui.Add("Text", "x294 y548 w76 h22 +0x200", "Zielordner")
    lancomTargetEdit := lancomDownloaderGui.Add("Edit", "x372 y542 w402 h34 ReadOnly -VScroll -Wrap", lancomTargetFolder)
    browseButton := lancomDownloaderGui.Add("Button", "x784 y542 w92 h34", "Ordner …")
    browseButton.OnEvent("Click", LancomChooseTargetFolder)

    lancomStatusText := lancomDownloaderGui.Add("Text", "x294 y590 w410 h32 +0x200 c65748B", "Lade LANCOM-Liste von LANCOM FTP …")
    lancomDownloadButton := lancomDownloaderGui.Add("Button", "x724 y588 w152 h36 Disabled", "Herunterladen")
    lancomDownloadButton.SetFont("s10 bold", "Segoe UI")
    lancomDownloadButton.OnEvent("Click", LancomDownloadSelected)

    lancomDownloaderGui.OnEvent("Close", LancomDownloaderClose)
    lancomDownloaderGui.Show("w900 h640")
    lancomDownloaderGui.Move(setWindowPos(lancomDownloaderGui), getWindowInfo(MeineGui).y)
    CenterModernEdit(lancomSearchEdit, 22)
    CenterModernEdit(lancomTargetEdit, 22)
    LancomLoadModels()
}

LancomClearSearch(*) {
    global lancomSearchEdit
    lancomSearchEdit.Value := ""
    lancomSearchEdit.Focus()
    LancomApplyModelFilter()
}

LancomLoadModels(*) {
    global lancomChannelList, lancomChannelEntries, lancomDeviceList
    global lancomDeviceEntries, lancomVisibleDeviceEntries, lancomStatusText
    global lancomContentList, lancomFileEntries, lancomScanFolders, lancomDownloadButton
    global lancomCurrentModelLabel, lancomPathText, lancomScanGeneration

    SetTimer(LancomScanNextFolder, 0)
    lancomScanGeneration += 1
    lancomChannelList.Delete()
    lancomDeviceList.Delete()
    lancomContentList.Delete()
    lancomChannelEntries := []
    lancomDeviceEntries := []
    lancomVisibleDeviceEntries := []
    lancomFileEntries := []
    lancomScanFolders := []
    lancomCurrentModelLabel := ""
    lancomPathText.Text := "Unterordner und Downloads — Modell auswählen"
    lancomDownloadButton.Enabled := false
    lancomStatusText.Text := "Lade Release-Kanäle von LANCOM FTP …"

    try {
        html := LancomRequestText("https://ftp.lancom.de/")
        labels := []
        defaultIndex := 0
        for entry in LancomParseIndex(html) {
            if (!entry.IsDirectory || !RegExMatch(entry.Href, "i)^(documentation|lancom-(archive|beta|releasecandidates|releases)|t-systems-releases)/$"))
                continue
            channelName := RegExReplace(entry.Name, "/$")
            channelLabel := channelName
            if (StrLower(channelName) = "documentation") {
                channelLabel := "Documentation"
            } else if (StrLower(channelName) = "lancom-releases") {
                channelLabel .= " (Stable)"
            } else if (StrLower(channelName) = "lancom-archive") {
                channelLabel .= " (Archiv)"
                defaultIndex := lancomChannelEntries.Length + 1
            } else if (StrLower(channelName) = "lancom-beta") {
                channelLabel .= " (Beta)"
            } else if (StrLower(channelName) = "lancom-releasecandidates") {
                channelLabel .= " (Release Candidates)"
            }
            lancomChannelEntries.Push({Href: entry.Href, Name: channelName, Label: channelLabel})
            labels.Push(channelLabel)
        }
        if (labels.Length)
            lancomChannelList.Add(labels)
        if (labels.Length) {
            if (defaultIndex = 0)
                defaultIndex := 1
            lancomChannelList.Choose(defaultIndex)
            LancomLoadDevices()
        } else {
            lancomStatusText.Text := "Auf der LANCOM-Startseite wurden keine passenden Verzeichnisse gefunden."
        }
    } catch Error as e {
        lancomStatusText.Text := "LANCOM FTP-Liste konnte nicht geladen werden: " e.Message
    }
}

LancomLoadDevices(*) {
    global lancomChannelList, lancomChannelEntries, lancomDeviceEntries, lancomVisibleDeviceEntries
    global lancomDeviceList, lancomContentList, lancomFileEntries, lancomScanFolders
    global lancomDownloadButton, lancomCurrentModelLabel, lancomPathText, lancomStatusText, lancomScanGeneration

    channelIndex := lancomChannelList.Value
    if (channelIndex < 1 || channelIndex > lancomChannelEntries.Length)
        return

    SetTimer(LancomScanNextFolder, 0)
    lancomScanGeneration += 1
    lancomDeviceList.Delete()
    lancomContentList.Delete()
    lancomDeviceEntries := []
    lancomVisibleDeviceEntries := []
    lancomFileEntries := []
    lancomScanFolders := []
    lancomCurrentModelLabel := ""
    lancomDownloadButton.Enabled := false
    lancomPathText.Text := "Unterordner und Downloads — Modell auswählen"
    channel := lancomChannelEntries[channelIndex]
    lancomStatusText.Text := "Lade Geräte aus " channel.Label " …"
    try {
        html := LancomRequestText("https://ftp.lancom.de/" channel.Href)
        for entry in LancomParseIndex(html) {
            if !entry.IsDirectory
                continue
            deviceName := RegExReplace(entry.Name, "/$")
            lancomDeviceEntries.Push({Href: channel.Href entry.Href, Label: deviceName})
        }
        LancomApplyModelFilter()
    } catch Error as e {
        lancomStatusText.Text := "Geräteliste konnte nicht geladen werden: " e.Message
    }
}

LancomApplyModelFilter(*) {
    global lancomSearchEdit, lancomDeviceList, lancomDeviceEntries, lancomVisibleDeviceEntries
    global lancomContentList, lancomFileEntries, lancomScanFolders, lancomDownloadButton
    global lancomCurrentModelLabel, lancomPathText, lancomStatusText, lancomScanGeneration

    SetTimer(LancomScanNextFolder, 0)
    lancomScanGeneration += 1
    lancomScanFolders := []
    lancomDeviceList.Delete()
    lancomVisibleDeviceEntries := []
    labels := []
    filterText := StrLower(Trim(lancomSearchEdit.Value))
    for model in lancomDeviceEntries {
        if (filterText = "" || InStr(StrLower(model.Label), filterText)) {
            lancomVisibleDeviceEntries.Push(model)
            labels.Push(model.Label)
        }
    }
    if (labels.Length)
        lancomDeviceList.Add(labels)

    lancomContentList.Delete()
    LancomSetFolderColumnVisibility(true)
    lancomFileEntries := []
    lancomDownloadButton.Enabled := false
    lancomCurrentModelLabel := ""
    lancomPathText.Text := "Unterordner und Downloads — Modell auswählen"
    lancomStatusText.Text := labels.Length " Modelle gefunden. Modell anklicken, um alle Dateien zu suchen."
}

LancomDeviceSelected(ctrl, *) {
    global lancomDeviceList, lancomVisibleDeviceEntries

    index := lancomDeviceList.Value
    if (index < 1 || index > lancomVisibleDeviceEntries.Length)
        return

    LancomLoadModelFiles(lancomVisibleDeviceEntries[index])
}

LancomLoadModelFiles(model) {
    global lancomScanFolders, lancomVisitedFolders, lancomFileEntries
    global lancomCurrentModelLabel, lancomPathText, lancomStatusText
    global lancomContentList, lancomDownloadButton, lancomScanFolderCount, lancomScanErrorCount
    global lancomScanGeneration

    SetTimer(LancomScanNextFolder, 0)
    lancomScanGeneration += 1
    lancomContentList.Delete()
    LancomSetFolderColumnVisibility(true)
    lancomFileEntries := []
    lancomScanFolders := [{Url: "https://ftp.lancom.de/" model.Href, RelativePath: ""}]
    lancomVisitedFolders := Map()
    lancomCurrentModelLabel := model.Label
    lancomScanFolderCount := 0
    lancomScanErrorCount := 0
    lancomDownloadButton.Enabled := false
    lancomPathText.Text := model.Label " — Dateien aus allen Unterordnern"
    lancomStatusText.Text := "Durchsuche die LANCOM FTP-Ordner für " model.Label " …"
    SetTimer(LancomScanNextFolder, -10)
}

LancomScanNextFolder(*) {
    global lancomDownloaderOpen, lancomScanFolders, lancomVisitedFolders, lancomFileEntries
    global lancomCurrentModelLabel, lancomScanFolderCount, lancomScanErrorCount
    global lancomContentList, lancomStatusText, lancomScanGeneration
    generation := lancomScanGeneration

    if !lancomDownloaderOpen
        return
    if (lancomCurrentModelLabel = "")
        return

    if (lancomScanFolders.Length = 0) {
        SetTimer(LancomScanNextFolder, 0)
        LancomRenderFileEntries()
        lancomStatusText.Text := lancomFileEntries.Length " Dateien in " lancomScanFolderCount " Ordnern gefunden."
        if (lancomScanErrorCount > 0)
            lancomStatusText.Text .= " " lancomScanErrorCount " Ordner konnten nicht gelesen werden."
        return
    }

    folder := lancomScanFolders.RemoveAt(1)
    if lancomVisitedFolders.Has(folder.Url) {
        SetTimer(LancomScanNextFolder, -10)
        return
    }
    lancomVisitedFolders[folder.Url] := true
    lancomScanFolderCount += 1

    try {
        html := LancomRequestText(folder.Url)
    } catch Error as e {
        if (generation != lancomScanGeneration)
            return
        lancomScanErrorCount += 1
        lancomStatusText.Text := "Ordner konnte nicht gelesen werden; fahre mit weiteren Ordnern fort …"
        SetTimer(LancomScanNextFolder, -10)
        return
    }
    if (generation != lancomScanGeneration)
        return

    for entry in LancomParseIndex(html) {
        if (generation != lancomScanGeneration)
            return
        if entry.IsDirectory {
            lancomScanFolders.Push({Url: folder.Url entry.Href, RelativePath: folder.RelativePath entry.Name "/"})
        } else {
            subfolder := (folder.RelativePath = "") ? "(Hauptordner)" : RegExReplace(folder.RelativePath, "/$")
            file := {Name: entry.Name, Url: folder.Url entry.Href, Subfolder: subfolder, SizeBytes: entry.SizeBytes, Modified: entry.Modified}
            lancomFileEntries.Push(file)
        }
    }

    lancomStatusText.Text := "Durchsuche " lancomCurrentModelLabel ": " lancomFileEntries.Length " Dateien gefunden …"
    SetTimer(LancomScanNextFolder, -10)
}

LancomContentSelected(*) {
    global lancomContentList, lancomFileEntries, lancomDownloadButton, lancomStatusText

    index := lancomContentList.GetNext(0)
    if (index < 1 || index > lancomFileEntries.Length) {
        lancomDownloadButton.Enabled := false
        return
    }
    lancomDownloadButton.Enabled := true
    lancomStatusText.Text := "Datei ausgewählt: " lancomFileEntries[index].Name
}

LancomRenderFileEntries() {
    global lancomContentList, lancomFileEntries

    folderSet := Map()
    for file in lancomFileEntries
        folderSet[file.Subfolder] := true

    showFolders := (folderSet.Count > 1)
    LancomSetFolderColumnVisibility(showFolders)
    for file in lancomFileEntries {
        subfolder := showFolders ? file.Subfolder : ""
        lancomContentList.Add(, subfolder, file.Name, FirmwareFormatSizeMB(file.SizeBytes), FirmwareFormatGermanDate(file.Modified))
    }
    LancomAutoSizeColumns(showFolders)
}

LancomAutoSizeColumns(showFolders) {
    global lancomContentList
    firstColumn := showFolders ? 1 : 2
    columnCount := 5 - firstColumn
    Loop columnCount {
        column := A_Index + firstColumn - 1
        if (column = 4)
            lancomContentList.ModifyCol(column, "Auto Right")
        else
            lancomContentList.ModifyCol(column, "Auto")
    }
    FirmwareAlignListViewHeaderLeft(lancomContentList, 4)
}

LancomSetFolderColumnVisibility(showFolders) {
    global lancomContentList
    if showFolders {
        lancomContentList.ModifyCol(1, 120)
        lancomContentList.ModifyCol(2, 230)
    } else {
        lancomContentList.ModifyCol(1, 1)
        lancomContentList.ModifyCol(2, 349)
    }
    lancomContentList.ModifyCol(3, 75)
    lancomContentList.ModifyCol(4, 120)
}

LancomContentActivated(*) {
    LancomDownloadSelected()
}

LancomChooseTargetFolder(*) {
    global lancomTargetFolder, lancomTargetEdit

    pickerStart := ""
    try {
        pickerStart := EnvGet("USERPROFILE")
    } catch {
        pickerStart := A_MyDocuments
    }
    if !DirExist(pickerStart)
        pickerStart := A_MyDocuments

    selectedFolder := DirSelect(pickerStart, 1, "Download-Ordner für LANCOM-Firmware wählen")
    if (selectedFolder = "")
        return
    lancomTargetFolder := selectedFolder
    lancomTargetEdit.Value := selectedFolder
}

LancomDownloadSelected(*) {
    global lancomContentList, lancomFileEntries, lancomTargetFolder
    global lancomStatusText, lancomDownloadActive, lancomDownloadScriptPath
    global lancomDownloadStatusPath, lancomDownloadPartialPath, lancomDownloadTargetPath
    global lancomDownloadFileName, lancomDownloadPid

    if lancomDownloadActive
        return

    index := lancomContentList.GetNext(0)
    if (index < 1 || index > lancomFileEntries.Length)
        return
    entry := lancomFileEntries[index]

    if (lancomTargetFolder = "" || !DirExist(lancomTargetFolder)) {
        LancomStatusText.Text := "Bitte zuerst einen vorhandenen Zielordner auswählen."
        return
    }

    fileName := entry.Name
    if (fileName = "" || fileName = "." || fileName = ".." || InStr(fileName, "\") || InStr(fileName, ":")) {
        lancomStatusText.Text := "Der LANCOM FTP-Dateiname ist ungültig."
        return
    }

    targetPath := lancomTargetFolder "\" fileName
    if FileExist(targetPath) {
        answer := MsgBox("Die Datei ist bereits vorhanden:`n`n" targetPath "`n`nSoll sie ersetzt werden?", "Datei vorhanden", "YesNo Icon!")
        if (answer != "Yes")
            return
    }

    url := entry.Url
    suffix := DllCall("GetCurrentProcessId") "_" A_TickCount
    lancomDownloadScriptPath := A_Temp "\lancom-download-" suffix ".ps1"
    lancomDownloadStatusPath := A_Temp "\lancom-download-" suffix ".status"
    lancomDownloadPartialPath := targetPath ".part"
    lancomDownloadTargetPath := targetPath
    lancomDownloadFileName := fileName
    if FileExist(lancomDownloadStatusPath)
        try FileDelete(lancomDownloadStatusPath)

    psScript := "`$ErrorActionPreference = 'Stop'`n"
        . "`$ProgressPreference = 'SilentlyContinue'`n"
        . "`$url = " LancomPSQuote(url) "`n"
        . "`$target = " LancomPSQuote(targetPath) "`n"
        . "`$partial = " LancomPSQuote(lancomDownloadPartialPath) "`n"
        . "`$status = " LancomPSQuote(lancomDownloadStatusPath) "`n"
        . "try { Invoke-WebRequest -Uri `$url -OutFile `$partial -UseBasicParsing -TimeoutSec 3600; Move-Item -LiteralPath `$partial -Destination `$target -Force; [System.IO.File]::WriteAllText(`$status, 'OK') }`n"
        . "catch { if (Test-Path -LiteralPath `$partial) { Remove-Item -LiteralPath `$partial -Force -ErrorAction SilentlyContinue }; [System.IO.File]::WriteAllText(`$status, 'ERR|' + `$_.Exception.Message) }`n"

    try {
        FileAppend(psScript, lancomDownloadScriptPath, "UTF-8")
        lancomDownloadActive := true
        lancomStatusText.Text := "Download wird gestartet: " fileName
        Run('powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' lancomDownloadScriptPath '"', , "Hide", &lancomDownloadPid)
        SetTimer(LancomPollDownload, 500)
    } catch Error as e {
        lancomDownloadActive := false
        lancomDownloadPid := 0
        lancomStatusText.Text := "Downloadstart fehlgeschlagen: " e.Message
    }
}

LancomPollDownload(*) {
    global lancomDownloadActive, lancomDownloadPid, lancomDownloadStatusPath
    global lancomDownloadPartialPath, lancomDownloadScriptPath, lancomDownloadFileName
    global lancomDownloadTargetPath, lancomStatusText

    if !lancomDownloadActive {
        SetTimer(LancomPollDownload, 0)
        return
    }

    if FileExist(lancomDownloadStatusPath) {
        result := Trim(FileRead(lancomDownloadStatusPath, "UTF-8"))
        downloadSucceeded := (result = "OK")
        if (result = "OK")
            lancomStatusText.Text := "Download abgeschlossen: " lancomDownloadFileName
        else if InStr(result, "ERR|") = 1
            lancomStatusText.Text := "Download fehlgeschlagen: " SubStr(result, 5)
        else
            lancomStatusText.Text := "Download beendet: " lancomDownloadFileName
        LancomCleanupDownloadFiles()
        lancomDownloadActive := false
        lancomDownloadPid := 0
        SetTimer(LancomPollDownload, 0)
        if downloadSucceeded
            LancomShowDownloadComplete(lancomDownloadFileName, lancomDownloadTargetPath)
        return
    }

    if (lancomDownloadPartialPath != "" && FileExist(lancomDownloadPartialPath)) {
        try {
            sizeMb := Round(FileGetSize(lancomDownloadPartialPath) / 1048576, 1)
        } catch {
            sizeMb := 0
        }
        lancomStatusText.Text := "Download läuft … " sizeMb " MB empfangen"
    } else {
        lancomStatusText.Text := "Download läuft … " lancomDownloadFileName
    }

    if (lancomDownloadPid && !ProcessExist(lancomDownloadPid)) {
        lancomStatusText.Text := "Downloadprozess wurde ohne Abschlussmeldung beendet."
        LancomCleanupDownloadFiles()
        lancomDownloadActive := false
        lancomDownloadPid := 0
        SetTimer(LancomPollDownload, 0)
    }
}

LancomShowDownloadComplete(fileName, folderPath) {
    popup := Gui("+AlwaysOnTop +ToolWindow", "Download abgeschlossen")
    ApplyLightAppTheme(popup, 10)
    popup.SetFont("s10 bold c182230", "Segoe UI")
    popup.Add("Text", "x20 y18 w370 h24 +0x200", "Die Firmware-Datei wurde heruntergeladen:")
    popup.SetFont("s9 c344054", "Segoe UI")
    popup.Add("Text", "x20 y48 w370 h28 +0x200", fileName)
    openFolderButton := popup.Add("Button", "x220 y94 w170 h34", "Zum Downloadordner")
    openFolderButton.SetFont("s10 bold", "Segoe UI")
    openFolderButton.OnEvent("Click", (*) => LancomOpenDownloadFolder(popup, folderPath))
    popup.Show("w410 h145 Center")
}

LancomOpenDownloadFolder(popup, filePath) {
    try Run('explorer.exe /select,"' filePath '"')
    try popup.Destroy()
}

LancomCleanupDownloadFiles() {
    global lancomDownloadScriptPath, lancomDownloadStatusPath, lancomDownloadPartialPath

    for path in [lancomDownloadScriptPath, lancomDownloadStatusPath, lancomDownloadPartialPath] {
        if (path != "" && FileExist(path))
            try FileDelete(path)
    }
    lancomDownloadScriptPath := ""
    lancomDownloadStatusPath := ""
    lancomDownloadPartialPath := ""
}

LancomDownloaderClose(*) {
    global lancomDownloaderOpen, lancomDownloadActive, lancomDownloadPid
    global lancomDownloaderGui, lancomScanGeneration

    lancomDownloaderOpen := false
    SetTimer(LancomPollDownload, 0)
    SetTimer(LancomScanNextFolder, 0)
    lancomScanGeneration += 1
    if (lancomDownloadActive && lancomDownloadPid && ProcessExist(lancomDownloadPid)) {
        try ProcessClose(lancomDownloadPid)
    }
    if lancomDownloadActive {
        LancomCleanupDownloadFiles()
        lancomDownloadActive := false
        lancomDownloadPid := 0
    }
    try lancomDownloaderGui.Destroy()
}

LancomRequestText(url) {
    request := ComObject("WinHttp.WinHttpRequest.5.1")
    request.SetTimeouts(5000, 5000, 15000, 15000)
    request.Open("GET", url, false)
    request.SetRequestHeader("User-Agent", "NetworkTools-LANCOMDownloader/1.0")
    request.Send()
    if (request.Status < 200 || request.Status >= 300)
        throw Error("LANCOM FTP antwortet mit HTTP " request.Status ".")
    return request.ResponseText
}

LancomParseIndex(html) {
    entries := []
    sizeByHref := FirmwareParseIndexSizes(html)
    modifiedByHref := FirmwareParseIndexDates(html)
    position := 1
    quote := Chr(34)
    pattern := "is)<a\s+href=" . quote . "([^" . quote . "]+)" . quote . "[^>]*>(.*?)</a>"
    while RegExMatch(html, pattern, &match, position) {
        position := match.Pos + match.Len
        href := StrReplace(match[1], "&amp;", "&")
        name := Trim(RegExReplace(match[2], "<[^>]+>", ""))
        if (href = "" || SubStr(href, 1, 1) = "?" || InStr(href, "://") || InStr(href, "\"))
            continue
        if (href = "../" || href = "./" || name = "Parent Directory")
            continue
        isDirectory := (SubStr(href, StrLen(href), 1) = "/")
        if (name = "")
            name := RegExReplace(href, "/$")
        sizeBytes := sizeByHref.Has(href) ? sizeByHref[href] : 0
        modified := modifiedByHref.Has(href) ? modifiedByHref[href] : ""
        entries.Push({Name: name, Href: href, IsDirectory: isDirectory, SizeBytes: sizeBytes, Modified: modified})
    }
    return entries
}

LancomPSQuote(value) {
    return "'" StrReplace(value, "'", "''") "'"
}

LancomGetDownloadsFolder() {
    try {
        shellApp := ComObject("Shell.Application")
        downloadsNamespace := shellApp.NameSpace("shell:Downloads")
        if (downloadsNamespace && DirExist(downloadsNamespace.Self.Path))
            return downloadsNamespace.Self.Path
    }
    try {
        profilePath := EnvGet("USERPROFILE")
    } catch {
        return A_MyDocuments
    }
    fallbackPath := profilePath "\Downloads"
    if DirExist(fallbackPath)
        return fallbackPath
    return A_MyDocuments
}
