; Netzwerk-Tool: DNS-Abfrage (ANY).

global dnsTesterIsOpen := false
global domainIP := "tel.t-online.de"
global dnsIP := ""

öffneDNSTester(*) {
    global DomainDropDown, DNSDropDown, ParallelDropDown, StartButton, StatusText, ResultEdit, DomainEdit, DnsEdit, dnsTesterIsOpen, MeineGui

    if (!dnsTesterIsOpen) {
        dnsTesterIsOpen := true
        ; GUI erstellen
        DnsGui := Gui(, "DNS Record Abfrage Tool")
        ApplyLightAppTheme(DnsGui, 10)
        ;DnsGui.Opt("+Resize +MinSize600x400")


        DnsGui.SetFont("s10", "Segoe UI")

        ; Domain Eingabe
        DnsGui.Add("Text", "w220", "Domain:")
        DomainDropDown := DnsGui.Add("DropDownList", "w400 vQueryName Choose1", [
            "tel.t-online.de (DTAG Retail Produkte)",
            "reg.sip-trunk.telekom.de (DTAG DeutschlandLan SIP-Trunk)",
            "hpbx.deutschland-lan.de (DTAG CloudPBX)",
            "hpbxsec.deutschland-lan.de (DTAG CloudPBX verschlüsselt)",
            "000000000000.primary.companyflex.de (DTAG CompanyFlex primary)",
            "000000000000.secondary.companyflex.de (DTAG CompanyFlex secondary)"
        ])
        DomainEdit := DnsGui.Add("Edit", "w400", DomainDropDown.Text)

        ; DNS Server Auswahl
        DnsGui.Add("Text", "w220 y+10", "DNS Server:")
        DNSDropDown := DnsGui.Add("DropDownList", "w360 vDNSServer Choose1", [
            "internal (DNS resolver of Windows OS)",
            "217.0.43.177 (DTAG DSL-Resolver Frankfurt)",
            "217.0.43.161 (DTAG DSL-Resolver Leipzig)",
            "194.25.0.54 (DTAG BPA-Resolver Leipzig)",
            "194.25.0.62 (DTAG BPA-Resolver Hannover)",
            "194.25.0.70 (DTAG BPA-Resolver Frankfurt/Main)",
            "194.25.0.52 (DTAG DCIP-Resolver Leipzig)",
            "194.25.0.60 (DTAG DCIP-Resolver Hannover)",
            "194.25.0.68 (DTAG DCIP-Resolver Frankfurt/Main)",
            "8.8.8.8 (Google)",
            "8.8.4.4 (Google)",
            "9.9.9.9 (Quad9 without ECS)",
            "149.112.112.112 (Quad9 without ECS)",
            "9.9.9.11 (Quad9 with ECS)",
            "149.112.112.11 (Quad9 with ECS)",
            "1.1.1.1 (Cloudflare)",
            "1.0.0.1 (Cloudflare)"
        ])
        DNSEdit := DnsGui.Add("Edit", "w360", DNSDropDown.Text)

        ; ; Parallelisierungs-Option
        ; DnsGui.Add("Text", "w180 y+10", "Parallel Abfragen:")
        ; ParallelDropDown := DnsGui.Add("DropDownList", "w100 vParallel Choose3", ["1", "2", "3", "5", "10"])

        ; Start Button
        StartButton := DnsGui.Add("Button", "w160 y+20", "&Abfrage starten")
        StartButton.OnEvent("Click", StartDNSQuery)

        ; Ergebnis Textbereich
        DnsGui.Add("Text", "w220 y+20", "Ergebnisse:")
        DnsGui.SetFont("s9", "Segoe UI")
        ResultEdit := DnsGui.Add("Edit", "w400 h400 ReadOnly +Multi +HScroll +VScroll")
        DnsGui.SetFont("s10", "Segoe UI")
        ; Statuszeile
        StatusText := DnsGui.Add("Text", "w400 vStatus", "Bereit für DNS-Abfrage...")

        DnsGui.Show()
        DnsGui.Move(setWindowPos(DnsGui), getWindowInfo(MeineGui).y)


        DNSDropDown.OnEvent("Change", DNSDropDownChanged)
        DomainDropDown.OnEvent("Change", DomainDropDownChanged)
        DomainEdit.OnEvent("Change", DomainEditChanged)
        DNSEdit.OnEvent("Change", DNSEditChanged)
        DNSGui.OnEvent("Close", CloseDNSTester)
    }
}
CloseDNSTester(*) {
    global dnsTesterIsOpen
    dnsTesterIsOpen := false
}



DomainEditChanged(*) {
    global DomainEdit, DomainDropDown, domainIP
    domainIP := DomainEdit.Value

}
DNSEditChanged(*) {
    global DNSEdit, DNSDropDown, dnsIP
    dnsIP := DNSEdit.Value

}
DNSDropDownChanged(*) {
    global DNSDropDown, DnsEdit, dnsIP
    ; DNS-Server-IP basierend auf Auswahl setzen

    switch DNSDropDown.Text {
        case "internal (DNS resolver of Windows OS)": dnsIP := ""
        case "217.0.43.177 (DTAG DSL-Resolver Frankfurt)": dnsIP := "217.0.43.177"
        case "217.0.43.161 (DTAG DSL-Resolver Leipzig)": dnsIP := "217.0.43.161"
        case "194.25.0.54 (DTAG BPA-Resolver Leipzig)": dnsIP := "194.25.0.54"
        case "194.25.0.62 (DTAG BPA-Resolver Hannover)": dnsIP := "194.25.0.62"
        case "194.25.0.70 (DTAG BPA-Resolver Frankfurt/Main)": dnsIP := "194.25.0.70"
        case "194.25.0.52 (DTAG DCIP-Resolver Leipzig)": dnsIP := "194.25.0.52"
        case "194.25.0.60 (DTAG DCIP-Resolver Hannover)": dnsIP := "194.25.0.60"
        case "194.25.0.68 (DTAG DCIP-Resolver Frankfurt/Main)": dnsIP := "194.25.0.68"
        case "8.8.8.8 (Google)": dnsIP := "8.8.8.8"
        case "8.8.4.4 (Google)": dnsIP := "8.8.4.4"
        case "9.9.9.9 (Quad9 without ECS)": dnsIP := "9.9.9.9"
        case "149.112.112.112 (Quad9 without ECS)": dnsIP := "149.112.112.112"
        case "9.9.9.11 (Quad9 with ECS)": dnsIP := "9.9.9.11"
        case "149.112.112.11 (Quad9 with ECS)": dnsIP := "149.112.112.11"
        case "1.1.1.1 (Cloudflare)": dnsIP := "1.1.1.1"
        case "1.0.0.1 (Cloudflare)": dnsIP := "1.0.0.1"
    }
    DNSEdit.Value := dnsIP
}
DomainDropDownChanged(*) {
    global domainIP, DomainEdit, DomainDropDown
    ; Domain-IP basierend auf Auswahl setzen

    switch DomainDropDown.Text {
        case "tel.t-online.de (DTAG Retail Produkte)": domainIP := "tel.t-online.de"
        case "reg.sip-trunk.telekom.de (DTAG DeutschlandLan SIP-Trunk)": domainIP := "reg.sip-trunk.telekom.de"
        case "hpbx.deutschland-lan.de (DTAG CloudPBX)": domainIP := "hpbx.deutschland-lan.de"
        case "hpbxsec.deutschland-lan.de (DTAG CloudPBX verschlüsselt)": domainIP := "hpbxsec.deutschland-lan.de"
        case "000000000000.primary.companyflex.de (DTAG CompanyFlex primary)": domainIP := "000000000000.primary.companyflex.de"
        case "000000000000.secondary.companyflex.de (DTAG CompanyFlex secondary)": domainIP := "000000000000.secondary.companyflex.de"
    }
    DomainEdit.Value := domainIP
}
; Event-Handler für Start-Button
StartDNSQuery(*) {
    global domainIP, dnsIP, DomainEdit, DomainDropDown, DNSDropDown, ParallelDropDown, StartButton, StatusText, ResultEdit, DnsGui, StatusText, StartButton, DomainEdit, DnsEdit, domainIP, dnsIP


    ; Button deaktivieren während der Abfrage
    StartButton.Enabled := false
    StartButton.Text := "Läuft..."

    ; Status aktualisieren
    StatusText.Text := "Abfrage läuft... Bitte warten."
    ResultEdit.Value := "" ; Vorherige Ergebnisse löschen

    ; DNS Record Typen definieren
    recordTypes := [
        "ANY"
    ]
    ; recordTypes := [
    ;     "UNKNOWN", "A_AAAA", "A", "NS", "MD", "MF", "CNAME", "SOA", "MB", "MG",
    ;     "MR", "NULL", "WKS", "PTR", "HINFO", "MINFO", "MX", "TXT", "RP", "AFSDB",
    ;     "X25", "ISDN", "RT", "AAAA", "SRV", "DNAME", "OPT", "DS", "RRSIG", "NSEC",
    ;     "DNSKEY", "DHCID", "NSEC3", "NSEC3PARAM", "ANY", "ALL", "WINS"
    ; ]
    ergebnisse := ""
    for type in recordTypes {
        ;MsgBox(domainIP . " " . dnsIP)
        ergebnisse .= RunDNSQuery(type, domainIP, dnsIP) . "`n"


    }

    if (StrLen(ergebnisse) = 1) {
        ergebnisse := "Keine DNS-Records gefunden"
    }

    ResultEdit.Value := Trim(ergebnisse)
    ; Status und Button zurücksetzen
    StatusText.Text := "Abfrage abgeschlossen!"
    StartButton.Enabled := true
    StartButton.Text := "&Abfrage starten"


    ; Funktion für einzelne DNS-Abfrage
    RunDNSQuery(type, domain, dnsIP) {
        global DnsGui, StatusText, StartButton
        ; PowerShell-Befehl erstellen
        psCommand := ""
        if (dnsIP != "") {
            psCommand := "Resolve-DnsName -Name '" domain "' -Type " type " -Server '" dnsIP "' -ErrorAction SilentlyContinue | Out-File -FilePath .\test.txt"
        } else {
            psCommand := "Resolve-DnsName -Name '" domain "' -Type " type " -ErrorAction SilentlyContinue | Out-File -FilePath .\test.txt"
        }


        ; PowerShell ausführen
        RunWait("PowerShell -Command " psCommand, , "Hide")


        ; Ausgabedatei
        outputFile := "test.txt"


        ; Ergebnis aus Datei lesen
        if FileExist(outputFile) {
            result := ""
            f := FileOpen(outputFile, "r")
            while f.AtEOF != true
            {
                line := f.ReadLine()
                if A_Index > 3
                    result := result . "`n" . line
            }

            FileDelete(outputFile)


            return result


        }
        return "Keine Ausgabedatei gefunden"
    }


}


