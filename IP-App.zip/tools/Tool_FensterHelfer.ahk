; Gemeinsame Positionierung der Tool-Fenster.

setWindowPos(window) {
    global MeineGui
    MeineGui.GetPos(&mgx, &mgy, &mgw, &mghh)
    window.GetPos(&x, &y, &w, &h)
    return mgx - w
}
getWindowInfo(window) {

    window.GetPos(&X, &Y, &Breite, &Hoehe)
    win := Object()
    win.X := X
    win.y := y
    win.breite := Breite
    win.hoehe := Hoehe

    return win
}

ApplyLightAppTheme(window, fontSize := 10) {
    window.BackColor := "F4F6FA"
    window.SetFont("s" fontSize " c182230", "Segoe UI")
}

SetToolWaitAnimation(control, running, interval := 55) {
    if !IsObject(control)
        return
    if running {
        control.Visible := true
        DllCall("SendMessageW", "Ptr", control.Hwnd, "UInt", 0x40A, "Ptr", 1, "Ptr", interval, "Ptr")
    } else {
        DllCall("SendMessageW", "Ptr", control.Hwnd, "UInt", 0x40A, "Ptr", 0, "Ptr", 0, "Ptr")
        control.Visible := false
    }
}


CenterModernEdit(control, lineHeight := 20) {
    clientRect := Buffer(16, 0)
    if !DllCall("GetClientRect", "Ptr", control.Hwnd, "Ptr", clientRect.Ptr)
        return

    clientWidth := NumGet(clientRect, 8, "Int")
    clientHeight := NumGet(clientRect, 12, "Int")
    lineHeight := Min(lineHeight, clientHeight - 2)
    top := Max(0, Floor((clientHeight - lineHeight) / 2))

    NumPut("Int", 3, clientRect, 0)
    NumPut("Int", top, clientRect, 4)
    NumPut("Int", clientWidth - 3, clientRect, 8)
    NumPut("Int", top + lineHeight, clientRect, 12)
    DllCall("SendMessageW", "Ptr", control.Hwnd, "UInt", 0xB3, "Ptr", 0, "Ptr", clientRect.Ptr, "Ptr")
}
