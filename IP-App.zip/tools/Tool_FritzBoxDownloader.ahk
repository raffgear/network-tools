; FRITZ!Box-Firmware aus dem offiziellen AVM-Verzeichnis anzeigen und laden.

global fritzBoxDownloaderOpen := false
global fritzBoxDownloaderGui
global fritzBoxDeviceList
global fritzBoxSearchEdit
global fritzBoxContentList
global fritzBoxPathText
global fritzBoxTargetEdit
global fritzBoxStatusText
global fritzBoxDownloadButton
global fritzBoxDeviceEntries := []
global fritzBoxVisibleDeviceEntries := []
global fritzBoxFileEntries := []
global fritzBoxScanFolders := []
global fritzBoxVisitedFolders := Map()
global fritzBoxCurrentModelLabel := ""
global fritzBoxScanFolderCount := 0
global fritzBoxScanErrorCount := 0
global fritzBoxScanGeneration := 0
global fritzBoxTargetFolder := ""
global fritzBoxDownloadPid := 0
global fritzBoxDownloadActive := false
global fritzBoxDownloadScriptPath := ""
global fritzBoxDownloadStatusPath := ""
global fritzBoxDownloadPartialPath := ""
global fritzBoxDownloadTargetPath := ""
global fritzBoxDownloadFileName := ""

öffneFritzBoxDownloader(*) {
    global MeineGui, fritzBoxDownloaderOpen, fritzBoxDownloaderGui
    global fritzBoxDeviceList, fritzBoxSearchEdit, fritzBoxContentList, fritzBoxPathText
    global fritzBoxTargetEdit, fritzBoxStatusText, fritzBoxDownloadButton
    global fritzBoxTargetFolder

    if fritzBoxDownloaderOpen {
        try WinActivate("ahk_id " fritzBoxDownloaderGui.Hwnd)
        return
    }

    fritzBoxDownloaderOpen := true
    if (fritzBoxTargetFolder = "" || !DirExist(fritzBoxTargetFolder))
        fritzBoxTargetFolder := FritzBoxGetDownloadsFolder()
    fritzBoxDownloaderGui := Gui(, "FRITZ!Box Firmware-Downloader")
    ApplyLightAppTheme(fritzBoxDownloaderGui, 10)

    fritzBoxDownloaderGui.SetFont("s18 bold c182230", "Segoe UI")
    fritzBoxDownloaderGui.Add("Text", "x24 y18 w820 h34", "FRITZ!Box Firmware")
    fritzBoxDownloaderGui.SetFont("s10 c65748B", "Segoe UI")
    fritzBoxDownloaderGui.Add("Text", "x26 y54 w840 h22", "AVM-Verzeichnis durchsuchen und Firmware in einen Ordner deiner Wahl laden.")

    fritzBoxDownloaderGui.SetFont("s10 bold c344054", "Segoe UI")
    fritzBoxDownloaderGui.Add("Text", "x24 y88 w250 h22", "FRITZ!Box-Modelle")
    fritzBoxPathText := fritzBoxDownloaderGui.Add("Text", "x294 y88 w582 h22", "Unterordner und Downloads — Modell auswählen")
    fritzBoxDownloaderGui.SetFont("s10", "Segoe UI")
    fritzBoxSearchEdit := fritzBoxDownloaderGui.Add("Edit", "x24 y112 w214 h32 Multi -VScroll -Wrap", "")
    DllCall("SendMessageW", "Ptr", fritzBoxSearchEdit.Hwnd, "UInt", 0x1501, "Ptr", 1, "Str", "Modell suchen, z. B. 7530", "Ptr")
    clearSearchButton := fritzBoxDownloaderGui.Add("Button", "x242 y112 w32 h32", "x")
    clearSearchButton.SetFont("s9 bold", "Segoe UI")
    clearSearchButton.OnEvent("Click", FritzBoxClearSearch)
    fritzBoxDeviceList := fritzBoxDownloaderGui.Add("ListBox", "x24 y150 w250 h382", [])
    fritzBoxContentList := fritzBoxDownloaderGui.AddListView("x294 y112 w582 h420", ["Unterordner", "Datei", "Größe", "Geändert"])
    FritzBoxAutoSizeColumns()
    fritzBoxSearchEdit.OnEvent("Change", FritzBoxApplyModelFilter)
    fritzBoxDeviceList.OnEvent("Change", FritzBoxDeviceSelected)
    fritzBoxContentList.OnEvent("ItemSelect", FritzBoxContentSelected)
    fritzBoxContentList.OnEvent("DoubleClick", FritzBoxContentActivated)

    refreshButton := fritzBoxDownloaderGui.Add("Button", "x24 y542 w250 h34", "Geräteliste aktualisieren")
    refreshButton.OnEvent("Click", FritzBoxLoadModels)
    fritzBoxDownloaderGui.SetFont("s9 bold c344054", "Segoe UI")
    fritzBoxDownloaderGui.Add("Text", "x294 y548 w76 h22 +0x200", "Zielordner")
    fritzBoxTargetEdit := fritzBoxDownloaderGui.Add("Edit", "x372 y542 w402 h34 ReadOnly -VScroll -Wrap", fritzBoxTargetFolder)
    browseButton := fritzBoxDownloaderGui.Add("Button", "x784 y542 w92 h34", "Ordner …")
    browseButton.OnEvent("Click", FritzBoxChooseTargetFolder)

    fritzBoxStatusText := fritzBoxDownloaderGui.Add("Text", "x294 y590 w410 h32 +0x200 c65748B", "Lade FRITZ!Box-Liste von AVM …")
    fritzBoxDownloadButton := fritzBoxDownloaderGui.Add("Button", "x724 y588 w152 h36 Disabled", "Herunterladen")
    fritzBoxDownloadButton.SetFont("s10 bold", "Segoe UI")
    fritzBoxDownloadButton.OnEvent("Click", FritzBoxDownloadSelected)

    fritzBoxDownloaderGui.OnEvent("Close", FritzBoxDownloaderClose)
    fritzBoxDownloaderGui.Show("w900 h640")
    fritzBoxDownloaderGui.Move(setWindowPos(fritzBoxDownloaderGui), getWindowInfo(MeineGui).y)
    CenterModernEdit(fritzBoxSearchEdit, 22)
    CenterModernEdit(fritzBoxTargetEdit, 22)
    FritzBoxLoadModels()
}

FritzBoxClearSearch(*) {
    global fritzBoxSearchEdit
    fritzBoxSearchEdit.Value := ""
    fritzBoxSearchEdit.Focus()
    FritzBoxApplyModelFilter()
}

FritzBoxLoadModels(*) {
    global fritzBoxDeviceList, fritzBoxDeviceEntries, fritzBoxVisibleDeviceEntries, fritzBoxStatusText
    global fritzBoxContentList, fritzBoxFileEntries, fritzBoxScanFolders, fritzBoxDownloadButton
    global fritzBoxCurrentModelLabel, fritzBoxPathText, fritzBoxScanGeneration

    SetTimer(FritzBoxScanNextFolder, 0)
    fritzBoxScanGeneration += 1
    fritzBoxDeviceList.Delete()
    fritzBoxContentList.Delete()
    fritzBoxDeviceEntries := []
    fritzBoxVisibleDeviceEntries := []
    fritzBoxFileEntries := []
    fritzBoxScanFolders := []
    fritzBoxCurrentModelLabel := ""
    fritzBoxPathText.Text := "Unterordner und Downloads — Modell auswählen"
    fritzBoxDownloadButton.Enabled := false
    fritzBoxStatusText.Text := "Lade Modellliste von AVM …"

    try {
        html := FritzBoxRequestText("https://download.avm.de/fritzbox/")
        for entry in FritzBoxParseIndex(html) {
            if (!entry.IsDirectory || !RegExMatch(entry.Href, "i)^fritzbox-[a-z0-9-]+/$"))
                continue
            model := RegExReplace(entry.Href, "/$")
            model := RegExReplace(model, "i)^fritzbox-", "")
            model := StrReplace(model, "-", " ")
            fritzBoxDeviceEntries.Push({Href: entry.Href, Label: "FRITZ!Box " model})
        }
        FritzBoxApplyModelFilter()
    } catch Error as e {
        fritzBoxStatusText.Text := "AVM-Liste konnte nicht geladen werden: " e.Message
    }
}

FritzBoxApplyModelFilter(*) {
    global fritzBoxSearchEdit, fritzBoxDeviceList, fritzBoxDeviceEntries, fritzBoxVisibleDeviceEntries
    global fritzBoxContentList, fritzBoxFileEntries, fritzBoxScanFolders, fritzBoxDownloadButton
    global fritzBoxCurrentModelLabel, fritzBoxPathText, fritzBoxStatusText, fritzBoxScanGeneration

    SetTimer(FritzBoxScanNextFolder, 0)
    fritzBoxScanGeneration += 1
    fritzBoxScanFolders := []
    fritzBoxDeviceList.Delete()
    fritzBoxVisibleDeviceEntries := []
    labels := []
    filterText := StrLower(Trim(fritzBoxSearchEdit.Value))
    for model in fritzBoxDeviceEntries {
        if (filterText = "" || InStr(StrLower(model.Label), filterText)) {
            fritzBoxVisibleDeviceEntries.Push(model)
            labels.Push(model.Label)
        }
    }
    if (labels.Length)
        fritzBoxDeviceList.Add(labels)

    fritzBoxContentList.Delete()
    FritzBoxAutoSizeColumns()
    fritzBoxFileEntries := []
    fritzBoxDownloadButton.Enabled := false
    fritzBoxCurrentModelLabel := ""
    fritzBoxPathText.Text := "Unterordner und Downloads — Modell auswählen"
    fritzBoxStatusText.Text := labels.Length " Modelle gefunden. Modell anklicken, um alle Dateien zu suchen."
}

FritzBoxDeviceSelected(ctrl, *) {
    global fritzBoxDeviceList, fritzBoxVisibleDeviceEntries

    index := fritzBoxDeviceList.Value
    if (index < 1 || index > fritzBoxVisibleDeviceEntries.Length)
        return

    FritzBoxLoadModelFiles(fritzBoxVisibleDeviceEntries[index])
}

FritzBoxLoadModelFiles(model) {
    global fritzBoxScanFolders, fritzBoxVisitedFolders, fritzBoxFileEntries
    global fritzBoxCurrentModelLabel, fritzBoxPathText, fritzBoxStatusText
    global fritzBoxContentList, fritzBoxDownloadButton, fritzBoxScanFolderCount, fritzBoxScanErrorCount
    global fritzBoxScanGeneration

    SetTimer(FritzBoxScanNextFolder, 0)
    fritzBoxScanGeneration += 1
    fritzBoxContentList.Delete()
    FritzBoxAutoSizeColumns()
    fritzBoxFileEntries := []
    fritzBoxScanFolders := [{Url: "https://download.avm.de/fritzbox/" model.Href, RelativePath: ""}]
    fritzBoxVisitedFolders := Map()
    fritzBoxCurrentModelLabel := model.Label
    fritzBoxScanFolderCount := 0
    fritzBoxScanErrorCount := 0
    fritzBoxDownloadButton.Enabled := false
    fritzBoxPathText.Text := model.Label " — Dateien aus allen Unterordnern"
    fritzBoxStatusText.Text := "Durchsuche die AVM-Ordner für " model.Label " …"
    SetTimer(FritzBoxScanNextFolder, -10)
}

FritzBoxScanNextFolder(*) {
    global fritzBoxDownloaderOpen, fritzBoxScanFolders, fritzBoxVisitedFolders, fritzBoxFileEntries
    global fritzBoxCurrentModelLabel, fritzBoxScanFolderCount, fritzBoxScanErrorCount
    global fritzBoxContentList, fritzBoxStatusText, fritzBoxScanGeneration
    generation := fritzBoxScanGeneration

    if !fritzBoxDownloaderOpen
        return
    if (fritzBoxCurrentModelLabel = "")
        return

    if (fritzBoxScanFolders.Length = 0) {
        SetTimer(FritzBoxScanNextFolder, 0)
        fritzBoxStatusText.Text := fritzBoxFileEntries.Length " Dateien in " fritzBoxScanFolderCount " Ordnern gefunden."
        if (fritzBoxScanErrorCount > 0)
            fritzBoxStatusText.Text .= " " fritzBoxScanErrorCount " Ordner konnten nicht gelesen werden."
        return
    }

    folder := fritzBoxScanFolders.RemoveAt(1)
    if fritzBoxVisitedFolders.Has(folder.Url) {
        SetTimer(FritzBoxScanNextFolder, -10)
        return
    }
    fritzBoxVisitedFolders[folder.Url] := true
    fritzBoxScanFolderCount += 1

    try {
        html := FritzBoxRequestText(folder.Url)
    } catch Error as e {
        if (generation != fritzBoxScanGeneration)
            return
        fritzBoxScanErrorCount += 1
        fritzBoxStatusText.Text := "Ordner konnte nicht gelesen werden; fahre mit weiteren Ordnern fort …"
        SetTimer(FritzBoxScanNextFolder, -10)
        return
    }
    if (generation != fritzBoxScanGeneration)
        return

    for entry in FritzBoxParseIndex(html) {
        if (generation != fritzBoxScanGeneration)
            return
        if entry.IsDirectory {
            fritzBoxScanFolders.Push({Url: folder.Url entry.Href, RelativePath: folder.RelativePath entry.Name "/"})
        } else {
            subfolder := (folder.RelativePath = "") ? "(Hauptordner)" : RegExReplace(folder.RelativePath, "/$")
            file := {Name: entry.Name, Url: folder.Url entry.Href, Subfolder: subfolder, SizeBytes: entry.SizeBytes, Modified: entry.Modified}
            fritzBoxFileEntries.Push(file)
            fritzBoxContentList.Add(, subfolder, entry.Name, FirmwareFormatSizeMB(entry.SizeBytes), FirmwareFormatGermanDate(entry.Modified))
        }
    }

    FritzBoxAutoSizeColumns()
    fritzBoxStatusText.Text := "Durchsuche " fritzBoxCurrentModelLabel ": " fritzBoxFileEntries.Length " Dateien gefunden …"
    SetTimer(FritzBoxScanNextFolder, -10)
}

FritzBoxAutoSizeColumns() {
    global fritzBoxContentList
    Loop 4 {
        if (A_Index = 4)
            fritzBoxContentList.ModifyCol(A_Index, "Auto Right")
        else
            fritzBoxContentList.ModifyCol(A_Index, "Auto")
    }
    FirmwareAlignListViewHeaderLeft(fritzBoxContentList, 4)
}

FritzBoxContentSelected(*) {
    global fritzBoxContentList, fritzBoxFileEntries, fritzBoxDownloadButton, fritzBoxStatusText

    index := fritzBoxContentList.GetNext(0)
    if (index < 1 || index > fritzBoxFileEntries.Length) {
        fritzBoxDownloadButton.Enabled := false
        return
    }
    fritzBoxDownloadButton.Enabled := true
    fritzBoxStatusText.Text := "Datei ausgewählt: " fritzBoxFileEntries[index].Name
}

FritzBoxContentActivated(*) {
    FritzBoxDownloadSelected()
}

FritzBoxChooseTargetFolder(*) {
    global fritzBoxTargetFolder, fritzBoxTargetEdit

    pickerStart := ""
    try {
        pickerStart := EnvGet("USERPROFILE")
    } catch {
        pickerStart := A_MyDocuments
    }
    if !DirExist(pickerStart)
        pickerStart := A_MyDocuments

    selectedFolder := DirSelect(pickerStart, 1, "Download-Ordner für FRITZ!Box-Firmware wählen")
    if (selectedFolder = "")
        return
    fritzBoxTargetFolder := selectedFolder
    fritzBoxTargetEdit.Value := selectedFolder
}

FritzBoxDownloadSelected(*) {
    global fritzBoxContentList, fritzBoxFileEntries, fritzBoxTargetFolder
    global fritzBoxStatusText, fritzBoxDownloadActive, fritzBoxDownloadScriptPath
    global fritzBoxDownloadStatusPath, fritzBoxDownloadPartialPath, fritzBoxDownloadTargetPath
    global fritzBoxDownloadFileName, fritzBoxDownloadPid

    if fritzBoxDownloadActive
        return

    index := fritzBoxContentList.GetNext(0)
    if (index < 1 || index > fritzBoxFileEntries.Length)
        return
    entry := fritzBoxFileEntries[index]

    if (fritzBoxTargetFolder = "" || !DirExist(fritzBoxTargetFolder)) {
        FritzBoxStatusText.Text := "Bitte zuerst einen vorhandenen Zielordner auswählen."
        return
    }

    fileName := entry.Name
    if (fileName = "" || fileName = "." || fileName = ".." || InStr(fileName, "\") || InStr(fileName, ":")) {
        fritzBoxStatusText.Text := "Der AVM-Dateiname ist ungültig."
        return
    }

    targetPath := fritzBoxTargetFolder "\" fileName
    if FileExist(targetPath) {
        answer := MsgBox("Die Datei ist bereits vorhanden:`n`n" targetPath "`n`nSoll sie ersetzt werden?", "Datei vorhanden", "YesNo Icon!")
        if (answer != "Yes")
            return
    }

    url := entry.Url
    suffix := DllCall("GetCurrentProcessId") "_" A_TickCount
    fritzBoxDownloadScriptPath := A_Temp "\fritzbox-download-" suffix ".ps1"
    fritzBoxDownloadStatusPath := A_Temp "\fritzbox-download-" suffix ".status"
    fritzBoxDownloadPartialPath := targetPath ".part"
    fritzBoxDownloadTargetPath := targetPath
    fritzBoxDownloadFileName := fileName
    if FileExist(fritzBoxDownloadStatusPath)
        try FileDelete(fritzBoxDownloadStatusPath)

    psScript := "`$ErrorActionPreference = 'Stop'`n"
        . "`$ProgressPreference = 'SilentlyContinue'`n"
        . "`$url = " FritzBoxPSQuote(url) "`n"
        . "`$target = " FritzBoxPSQuote(targetPath) "`n"
        . "`$partial = " FritzBoxPSQuote(fritzBoxDownloadPartialPath) "`n"
        . "`$status = " FritzBoxPSQuote(fritzBoxDownloadStatusPath) "`n"
        . "try { Invoke-WebRequest -Uri `$url -OutFile `$partial -UseBasicParsing -TimeoutSec 3600; Move-Item -LiteralPath `$partial -Destination `$target -Force; [System.IO.File]::WriteAllText(`$status, 'OK') }`n"
        . "catch { if (Test-Path -LiteralPath `$partial) { Remove-Item -LiteralPath `$partial -Force -ErrorAction SilentlyContinue }; [System.IO.File]::WriteAllText(`$status, 'ERR|' + `$_.Exception.Message) }`n"

    try {
        FileAppend(psScript, fritzBoxDownloadScriptPath, "UTF-8")
        fritzBoxDownloadActive := true
        fritzBoxStatusText.Text := "Download wird gestartet: " fileName
        Run('powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' fritzBoxDownloadScriptPath '"', , "Hide", &fritzBoxDownloadPid)
        SetTimer(FritzBoxPollDownload, 500)
    } catch Error as e {
        fritzBoxDownloadActive := false
        fritzBoxDownloadPid := 0
        fritzBoxStatusText.Text := "Downloadstart fehlgeschlagen: " e.Message
    }
}

FritzBoxPollDownload(*) {
    global fritzBoxDownloadActive, fritzBoxDownloadPid, fritzBoxDownloadStatusPath
    global fritzBoxDownloadPartialPath, fritzBoxDownloadScriptPath, fritzBoxDownloadFileName
    global fritzBoxDownloadTargetPath, fritzBoxStatusText

    if !fritzBoxDownloadActive {
        SetTimer(FritzBoxPollDownload, 0)
        return
    }

    if FileExist(fritzBoxDownloadStatusPath) {
        result := Trim(FileRead(fritzBoxDownloadStatusPath, "UTF-8"))
        downloadSucceeded := (result = "OK")
        if (result = "OK")
            fritzBoxStatusText.Text := "Download abgeschlossen: " fritzBoxDownloadFileName
        else if InStr(result, "ERR|") = 1
            fritzBoxStatusText.Text := "Download fehlgeschlagen: " SubStr(result, 5)
        else
            fritzBoxStatusText.Text := "Download beendet: " fritzBoxDownloadFileName
        FritzBoxCleanupDownloadFiles()
        fritzBoxDownloadActive := false
        fritzBoxDownloadPid := 0
        SetTimer(FritzBoxPollDownload, 0)
        if downloadSucceeded
            FritzBoxShowDownloadComplete(fritzBoxDownloadFileName, fritzBoxDownloadTargetPath)
        return
    }

    if (fritzBoxDownloadPartialPath != "" && FileExist(fritzBoxDownloadPartialPath)) {
        try {
            sizeMb := Round(FileGetSize(fritzBoxDownloadPartialPath) / 1048576, 1)
        } catch {
            sizeMb := 0
        }
        fritzBoxStatusText.Text := "Download läuft … " sizeMb " MB empfangen"
    } else {
        fritzBoxStatusText.Text := "Download läuft … " fritzBoxDownloadFileName
    }

    if (fritzBoxDownloadPid && !ProcessExist(fritzBoxDownloadPid)) {
        fritzBoxStatusText.Text := "Downloadprozess wurde ohne Abschlussmeldung beendet."
        FritzBoxCleanupDownloadFiles()
        fritzBoxDownloadActive := false
        fritzBoxDownloadPid := 0
        SetTimer(FritzBoxPollDownload, 0)
    }
}

FritzBoxShowDownloadComplete(fileName, folderPath) {
    popup := Gui("+AlwaysOnTop +ToolWindow", "Download abgeschlossen")
    ApplyLightAppTheme(popup, 10)
    popup.SetFont("s10 bold c182230", "Segoe UI")
    popup.Add("Text", "x20 y18 w370 h24 +0x200", "Die Firmware-Datei wurde heruntergeladen:")
    popup.SetFont("s9 c344054", "Segoe UI")
    popup.Add("Text", "x20 y48 w370 h28 +0x200", fileName)
    openFolderButton := popup.Add("Button", "x220 y94 w170 h34", "Zum Downloadordner")
    openFolderButton.SetFont("s10 bold", "Segoe UI")
    openFolderButton.OnEvent("Click", (*) => FritzBoxOpenDownloadFolder(popup, folderPath))
    popup.Show("w410 h145 Center")
}

FritzBoxOpenDownloadFolder(popup, filePath) {
    try Run('explorer.exe /select,"' filePath '"')
    try popup.Destroy()
}

FritzBoxCleanupDownloadFiles() {
    global fritzBoxDownloadScriptPath, fritzBoxDownloadStatusPath, fritzBoxDownloadPartialPath

    for path in [fritzBoxDownloadScriptPath, fritzBoxDownloadStatusPath, fritzBoxDownloadPartialPath] {
        if (path != "" && FileExist(path))
            try FileDelete(path)
    }
    fritzBoxDownloadScriptPath := ""
    fritzBoxDownloadStatusPath := ""
    fritzBoxDownloadPartialPath := ""
}

FritzBoxDownloaderClose(*) {
    global fritzBoxDownloaderOpen, fritzBoxDownloadActive, fritzBoxDownloadPid
    global fritzBoxDownloaderGui, fritzBoxScanGeneration

    fritzBoxDownloaderOpen := false
    SetTimer(FritzBoxPollDownload, 0)
    SetTimer(FritzBoxScanNextFolder, 0)
    fritzBoxScanGeneration += 1
    if (fritzBoxDownloadActive && fritzBoxDownloadPid && ProcessExist(fritzBoxDownloadPid)) {
        try ProcessClose(fritzBoxDownloadPid)
    }
    if fritzBoxDownloadActive {
        FritzBoxCleanupDownloadFiles()
        fritzBoxDownloadActive := false
        fritzBoxDownloadPid := 0
    }
    try fritzBoxDownloaderGui.Destroy()
}

FritzBoxRequestText(url) {
    request := ComObject("WinHttp.WinHttpRequest.5.1")
    request.SetTimeouts(5000, 5000, 15000, 15000)
    request.Open("GET", url, false)
    request.SetRequestHeader("User-Agent", "NetworkTools-FirmwareDownloader/1.0")
    request.Send()
    if (request.Status < 200 || request.Status >= 300)
        throw Error("AVM antwortet mit HTTP " request.Status ".")
    return request.ResponseText
}

FritzBoxParseIndex(html) {
    entries := []
    sizeByHref := FirmwareParseIndexSizes(html)
    modifiedByHref := FirmwareParseIndexDates(html)
    position := 1
    quote := Chr(34)
    pattern := "is)<a\s+href=" . quote . "([^" . quote . "]+)" . quote . "[^>]*>(.*?)</a>"
    while RegExMatch(html, pattern, &match, position) {
        position := match.Pos + match.Len
        href := StrReplace(match[1], "&amp;", "&")
        name := Trim(RegExReplace(match[2], "<[^>]+>", ""))
        if (href = "" || SubStr(href, 1, 1) = "?" || InStr(href, "://") || InStr(href, "\"))
            continue
        if (href = "../" || href = "./" || name = "Parent Directory")
            continue
        isDirectory := (SubStr(href, StrLen(href), 1) = "/")
        if (name = "")
            name := RegExReplace(href, "/$")
        sizeBytes := sizeByHref.Has(href) ? sizeByHref[href] : 0
        modified := modifiedByHref.Has(href) ? modifiedByHref[href] : ""
        entries.Push({Name: name, Href: href, IsDirectory: isDirectory, SizeBytes: sizeBytes, Modified: modified})
    }
    return entries
}

FritzBoxPSQuote(value) {
    return "'" StrReplace(value, "'", "''") "'"
}

FritzBoxGetDownloadsFolder() {
    try {
        shellApp := ComObject("Shell.Application")
        downloadsNamespace := shellApp.NameSpace("shell:Downloads")
        if (downloadsNamespace && DirExist(downloadsNamespace.Self.Path))
            return downloadsNamespace.Self.Path
    }
    try {
        profilePath := EnvGet("USERPROFILE")
    } catch {
        return A_MyDocuments
    }
    fallbackPath := profilePath "\Downloads"
    if DirExist(fallbackPath)
        return fallbackPath
    return A_MyDocuments
}
