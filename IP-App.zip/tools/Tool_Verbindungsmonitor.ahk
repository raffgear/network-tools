; Netzwerk-Tool: Verbindungsmonitor.

global QuickFilterList := ["established", "listen", "bound", "timewait", "0.0.0.0", "::"]
global ColumnNames := ["Prozess", "PID", "Lokale Adresse", "Port", "Remote Adresse", "Status"]
global networkMonitorisOpen := false
global CurrentCellText := ""
global AllData := []
global RefreshTimerFunc := () => RefreshNetstat()

öffneNetworkMonitorGui(*) {
    global QuickFilterList, ColumnNames, LV, NetworkMonitorGui, MyBtn, ChkAuto, DDLTime, MySubMenu, EditSearch, networkMonitorisOpen
    ; ==============================================================================
    ; --- GUI SETUP ---

    if (!networkMonitorisOpen) {
        networkMonitorisOpen := true
        NetworkMonitorGui := Gui(, "TCP-Verbindungs-Monitor")
        ApplyLightAppTheme(NetworkMonitorGui, 10)

        ; --- ZEILE 1: FILTER & BUTTONS ---
        NetworkMonitorGui.Add("Text", "x10 y15", "Filter:")
        EditSearch := NetworkMonitorGui.Add("Edit", "x50 y12 w150 vSearchBox")
        EditSearch.OnEvent("Change", ApplyFilter)

        BtnClear := NetworkMonitorGui.Add("Button", "x+2 y12 h24", "Filter löschen")
        BtnClear.OnEvent("Click", (*) => (EditSearch.Value := "", ApplyFilter()))

        NetworkMonitorGui.Add("Text", "x+30 y15", "Vorschläge:")

        for index, FilterName in QuickFilterList {
            pos := (index = 1) ? "x+5" : "x+2"
            btn := NetworkMonitorGui.Add("Button", pos . " y12 h24", FilterName)
            btn.OnEvent("Click", ((name, *) => ToggleQuickFilter(name)).Bind(FilterName))
        }

        ; --- ZEILE 2: LISTVIEW ---
        LV := NetworkMonitorGui.Add("ListView", "x10 y45 r25 w750 Grid -Multi", ColumnNames)
        LV.OnEvent("ContextMenu", ShowContextMenu)

        HeaderHwnd := SendMessage(0x101F, 0, 0, LV.Hwnd)
        hFont := CustomFont("s10 w700", "Segoe UI")
        SendMessage(0x0030, hFont, 1, HeaderHwnd)

        ; --- ZEILE 3: STEUERUNG ---
        MyBtn := NetworkMonitorGui.Add("Button", "Default xs y+10 w150 h30", "Jetzt aktualisieren")
        MyBtn.OnEvent("Click", RefreshNetstat)

        ChkAuto := NetworkMonitorGui.Add("CheckBox", "x+50 yp+5 h20", "Auto-Update alle:")
        ChkAuto.OnEvent("Click", ToggleTimer)

        DDLTime := NetworkMonitorGui.Add("DropDownList", "x+5 yp-3 w50 Choose2", ["1", "3", "5", "10", "30", "60"])
        DDLTime.OnEvent("Change", ToggleTimer)
        NetworkMonitorGui.Add("Text", "x+5 yp+3", "Sek.")

        MySubMenu := Menu()
        NetworkMonitorGui.OnEvent("Close", (*) => (networkMonitorisOpen := false))
        NetworkMonitorGui.Show()
        NetworkMonitorGui.Move(setWindowPos(NetworkMonitorGui), getWindowInfo(MeineGui).y)
        RefreshNetstat()
    }
}



ToggleQuickFilter(NewText) {
    global current, EditSearch
    current := " " . Trim(EditSearch.Value) . " "
    if InStr(StrLower(current), " " . StrLower(NewText) . " ") {
        newVal := StrReplace(StrLower(current), " " . StrLower(NewText) . " ", " ")
        EditSearch.Value := Trim(newVal)


    } else {
        current := Trim(current)
        EditSearch.Value := (current == "") ? NewText : current . " " . NewText

    }
    ApplyFilter()
}

ToggleTimer(*) {
    SetTimer(RefreshTimerFunc, 0)
    if (ChkAuto.Value = 1) {
        interval := Number(DDLTime.Text) * 1000
        SetTimer(RefreshTimerFunc, interval)
    }
}

RefreshNetstat(*) {
    global AllData
    MyBtn.Enabled := False
    MyBtn.Text := "Scanne..."
    psCmd := "Get-NetTCPConnection -ErrorAction SilentlyContinue | " .
        "Select-Object @{N='P';E={(Get-Process -Id $_.OwningProcess -EA SilentlyContinue).Name}}, " .
        "OwningProcess, LocalAddress, LocalPort, RemoteAddress, State | " .
        "ConvertTo-Csv -NoTypeInformation"
    try {
        A_Clipboard := ""
        shell := ComObject("WScript.Shell")
        shell.Run('powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "' . psCmd . ' | clip"', 0, true)
        if ClipWait(3) {
            AllData := []
            Loop Parse, A_Clipboard, "`n", "`r" {
                if (A_Index > 1 && Trim(A_LoopField) != "") {
                    RowData := StrSplit(StrReplace(A_LoopField, '"', ''), ",")
                    if (RowData.Length >= 6)
                        AllData.Push(RowData)
                }
            }
            ApplyFilter()
            A_Clipboard := ""
        }
    } catch {
        ; Fehler ignoriert
    }
    MyBtn.Enabled := True
    MyBtn.Text := "Jetzt aktualisieren"
}

ApplyFilter(*) {
    global AllData
    rawInput := StrLower(EditSearch.Value)
    searchTerms := StrSplit(StrReplace(rawInput, ",", " "), " ", "`t")
    cleanTerms := []
    for term in searchTerms {
        if (Trim(term) != "")
            cleanTerms.Push(Trim(term))
    }
    LV.Opt("-Redraw")
    LV.Delete()
    for row in AllData {
        fullStr := StrLower(row[1] . " " . row[2] . " " . row[3] . " " . row[4] . " " . row[5] . " " . row[6])
        matchCount := 0
        for t in cleanTerms {
            if InStr(fullStr, t)
                matchCount++
        }
        if (matchCount = cleanTerms.Length || cleanTerms.Length = 0)
            LV.Add(, row[1], row[2], row[3], row[4], row[5], row[6])
    }
    LV.ModifyCol(1, 180), LV.ModifyCol(2, 70), LV.ModifyCol(3, 160)
    LV.ModifyCol(4, 70), LV.ModifyCol(5, 160), LV.ModifyCol(6, 80)
    LV.Opt("+Redraw")
}

CustomFont(Options, FontName) {
    TempGui := Gui()
    TempGui.SetFont(Options, FontName)
    return SendMessage(0x0031, 0, 0, TempGui.Add("Text").Hwnd)
}

ShowContextMenu(GuiCtrl, ItemIndex, IsRightClick, X, Y) {
    global LV, MySubMenu, ColumnNames, CurrentCellText
    if (ItemIndex = 0)
        return

    ; Rechtsklick-Zeile zugleich auswählen, damit alle Menüaktionen auf diese PID gehen.
    LV.Modify(ItemIndex, "Select Focus")

    CurrentCellText := ""
    CoordMode("Mouse", "Window")
    MouseGetPos(&mX, &mY)
    LV.GetPos(&lvX, &lvY)
    relX := mX - lvX
    w := 0
    clickedCol := 0
    Loop LV.GetCount("Col") {
        w += SendMessage(0x101D, A_Index - 1, 0, LV.Hwnd)
        if (relX < w) {
            clickedCol := A_Index
            break
        }
    }
    if (clickedCol > 0)
        CurrentCellText := LV.GetText(ItemIndex, clickedCol)

    rowRemoteIP := LV.GetText(ItemIndex, 5)
    try MySubMenu.Delete()

    disp := StrLen(CurrentCellText) > 30 ? SubStr(CurrentCellText, 1, 27) . "..." : CurrentCellText

    ; --- FILTER SEKTION ---
    MySubMenu.Add('Als Filter setzen: "' . disp . '"', MenuHandler)
    MySubMenu.Add('Im Filter ergänzen: "' . disp . '"', MenuHandler)
    MySubMenu.Add()

    ; --- INFO SEKTION ---
    MySubMenu.Add('Google Suche: process ' . disp, MenuHandler)
    if (rowRemoteIP != "" && rowRemoteIP != "*" && rowRemoteIP != "0.0.0.0" && rowRemoteIP != "::") {
        MySubMenu.Add('Whois Abfrage für [' . rowRemoteIP . ']', MenuHandler)
        MySubMenu.Add('IP Standort-Info für [' . rowRemoteIP . ']', MenuHandler)
    }

    MySubMenu.Add()
    MySubMenu.Add("Prozess im Explorer zeigen", MenuHandler)
    processId := LV.GetText(ItemIndex, 2)
    if (processId ~= "^\d+$" && Integer(processId) > 0)
        MySubMenu.Add("Prozess beenden (PID " . processId . ")", MenuHandler)
    MySubMenu.Add()

    ; --- DYNAMISCHE KOPIER SEKTION (Spalte 1 bis 6) ---
    Loop 6 {
        colVal := LV.GetText(ItemIndex, A_Index)
        if (colVal != "") {
            menuText := ColumnNames[A_Index] . ': "' . colVal . '" kopieren'
            ; Wir binden den Wert direkt an den Handler
            MySubMenu.Add(menuText, CopyHandler.Bind(colVal))
        }
    }

    MySubMenu.Show(X, Y)
}

; Extra Handler für das Kopieren der verschiedenen Werte
CopyHandler(ValueToCopy, *) {
    A_Clipboard := ValueToCopy
    ToolTip("Kopiert: " . ValueToCopy)
    SetTimer(() => ToolTip(), -1500)
}

MenuHandler(ItemName, ItemPos, MySubMenu) {
    global LV, EditSearch, CurrentCellText, RefreshTimerFunc
    rowID := LV.GetNext()
    if (rowID = 0)
        return

    P_PID := LV.GetText(rowID, 2), P_Remote := LV.GetText(rowID, 5)

    if InStr(ItemName, "Als Filter setzen") {
        EditSearch.Value := CurrentCellText
        ApplyFilter()
    } else if InStr(ItemName, "Im Filter ergänzen") {
        ToggleQuickFilter(CurrentCellText)
    } else if InStr(ItemName, "Google Suche") {
        if (CurrentCellText != "")
            Run("https://www.google.com/search?q=process " . CurrentCellText)
    } else if InStr(ItemName, "Whois") {
        if (P_Remote ~= "^\d" || P_Remote ~= "^[a-fA-F0-9:]+")
            Run("https://www.whois.com/whois/" . P_Remote)
    } else if InStr(ItemName, "Standort-Info") {
        if (P_Remote ~= "^\d" || P_Remote ~= "^[a-fA-F0-9:]+")
            Run("https://ip-api.com/#" . P_Remote)
    } else if (ItemName = "Prozess im Explorer zeigen") {
        try {
            pathCmd := 'powershell.exe -NoProfile -Command "(Get-Process -Id ' . P_PID . ' -EA SilentlyContinue).Path | clip"'
            RunWait(pathCmd, , "Hide")
            if (A_Clipboard != "")
                Run("explorer.exe /select,`"" . A_Clipboard . "`"")
        }
    } else if InStr(ItemName, "Prozess beenden (PID ") {
        if !(P_PID ~= "^\d+$") || Integer(P_PID) < 1
            return
        if (Integer(P_PID) = DllCall("GetCurrentProcessId")) {
            MsgBox("Der Verbindungsmonitor kann seinen eigenen Prozess nicht beenden.", "Prozess beenden", "Icon!")
            return
        }

        processName := LV.GetText(rowID, 1)
        answer := MsgBox("Soll der Prozess " . processName . " (PID " . P_PID . ") beendet werden?`n`nNicht gespeicherte Daten im Prozess können verloren gehen.", "Prozess beenden", "YesNo Icon!")
        if (answer != "Yes")
            return

        targetPid := Integer(P_PID)
        try ProcessClose(targetPid)

        if !ProcessExist(targetPid) {
            SetTimer(RefreshTimerFunc, -250)
            return
        }

        adminAnswer := MsgBox(
            "Windows verweigert das Beenden mit den aktuellen Rechten. Soll taskkill mit Administratorrechten gestartet werden?`n`nWindows fragt danach über die UAC-Abfrage nach deiner Zustimmung.",
            "Administratorrechte erforderlich",
            "YesNo Icon!"
        )
        if (adminAnswer != "Yes")
            return

        try {
            exitCode := RunWait('*RunAs "' A_WinDir '\System32\taskkill.exe" /PID ' targetPid ' /F', , "Hide")
            if (exitCode = 0)
                SetTimer(RefreshTimerFunc, -500)
            else
                MsgBox("taskkill konnte den Prozess nicht beenden. Möglicherweise ist er geschützt oder bereits beendet.", "Prozess beenden", "Icon!")
        } catch as e {
            MsgBox("Das Beenden mit Administratorrechten wurde nicht gestartet:`n" . e.Message, "Prozess beenden", "Icon!")
        }
    }
}

; --- Ende FUNKTIONEN NetworkMonitorGui ---

