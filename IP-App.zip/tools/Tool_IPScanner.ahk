; Netzwerk-Tool: IP-Scanner.

global ipScannerIsOpen := false
global ipAdress := ""
global lv_shown := false
global ipScanIPs := []
global ipScanMacs := []
global ipScanVendors := []
global ipScanHostnames := []
global ipScanProcessId := 0
global ipScanResultPath := ""
global ipScanDonePath := ""
global ipScanScriptPath := ""
global ipScanStartTick := 0
global ipScanLastContent := ""

öffneIPScanner(*) {
    global zeitLabel, chkboxUnify, inputIP, inputFilter, ipScanIPs, ipScanMacs, ipScanVendors, ipScanHostnames, LV, lv_shown, btnOK, ipAdress, ipScannerIsOpen

    if (!ipScannerIsOpen) {
        ipScannerIsOpen := true
        ;4.Oktett abschneiden
        ip_adress := RegExReplace(frmIP.value, "\.\d+$", "")

        IPScannerGui := Gui()
        IPScannerGui.Title := "IP-Scanner"
        ApplyLightAppTheme(IPScannerGui, 10)


        IPScannerGui.SetFont("s19 bold c182230", "Segoe UI")
        IPScannerGui.Add("Text", "x24 y18 w600 h34", "Netzwerkgeräte finden")
        IPScannerGui.SetFont("s10 c65748B", "Segoe UI")
        IPScannerGui.Add("Text", "x26 y54 w700 h22", "Scanne das lokale IPv4-Netz und filtere die gefundenen Geräte.")

        IPScannerGui.SetFont("s10 bold c344054", "Segoe UI")
        IPScannerGui.Add("Text", "x24 y94 w270 h20", "IP-Netzpräfix")
        IPScannerGui.Add("Text", "x324 y94 w250 h20", "Ergebnisse filtern")
        IPScannerGui.SetFont("s11", "Segoe UI")
        inputIP := IPScannerGui.Add("Edit", "x24 y117 w270 h34 Multi -VScroll -Wrap", ip_adress)
        inputFilter := IPScannerGui.Add("Edit", "x324 y117 w250 h34 Multi -VScroll -Wrap", "")
        IPScannerGui.SetFont("s9 c65748B", "Segoe UI")
        IPScannerGui.Add("Text", "x26 y153 w270 h20", "Zum Beispiel: 192.168.178")

        chkboxUnify := IPScannerGui.Add("Checkbox", "x324 y157 w100 h24", "UniFi")
        chkboxLancom := IPScannerGui.Add("Checkbox", "x432 y157 w110 h24", "Lancom")

        IPScannerGui.SetFont("s10 bold c344054", "Segoe UI")
        IPScannerGui.Add("Text", "x24 y194 w300 h22", "Gefundene Geräte")
        zeitLabel := IPScannerGui.Add("Text", "x470 y194 w286 h22 Right c65748B", "Noch kein Scan durchgeführt")


        LV := IPScannerGui.AddListView("x24 y221 w732 h310", ["IP-Adresse", "MAC-Adresse", "Hersteller", "Gerätename"])
        LV.ModifyCol(1, 120)
        LV.ModifyCol(2, 155)
        LV.ModifyCol(3, 250)
        LV.ModifyCol(4, 185)
        LV.OnEvent("ContextMenu", itemS)
        lv_shown := true

        IPScannerGui.SetFont("s9 c65748B", "Segoe UI")
        IPScannerGui.Add("Text", "x24 y542 w500 h20", "Rechtsklick auf ein Gerät öffnet Aktionen und Kopieroptionen.")
        IPScannerGui.SetFont("s10 bold", "Segoe UI")
        btnOK := IPScannerGui.Add("Button", "x604 y112 w152 h42 Default", "Scannen")
        btnOK.SetFont("s10 bold", "Segoe UI")
        btnOK.OnEvent("Click", showLv)

        IPScannerGui.OnEvent("Close", CloseIPScanner)
        inputFilter.OnEvent("Change", aktualisiereListView)
        chkboxUnify.OnEvent("Click", chkboxUnifyClick)
        chkboxLancom.OnEvent("Click", chkboxLancomClick)


        IPScannerGui.Show("w780 h580")
        CenterIPScannerField(inputIP, 20)
        CenterIPScannerField(inputFilter, 20)

        IPScannerGui.Move(setWindowPos(IPScannerGui), getWindowInfo(MeineGui).y)

        chkboxUnifyClick(*) {

            if (chkboxUnify.value = 1) {
                chkboxLancom.value := 0
                inputFilter.value := "00-1a-e8"
            } else {

                inputFilter.value := ""
            }

            if (lv_shown) {
                aktualisiereListView()
            }

        }

        chkboxLancomClick(*) {
            if (chkboxLancom.value = 1) {
                chkboxUnify.value := 0
                inputFilter.value := "00-a0-57"
            } else {

                inputFilter.value := ""
            }

            if (lv_shown) {
                aktualisiereListView()
            }

        }

        CloseIPScanner(*) {
            global ipScanProcessId, ipScanResultPath, ipScanDonePath, ipScanScriptPath
            lv_shown := false
            ipScannerIsOpen := false
            SetTimer(IPScannerPoll, 0)
            if (ipScanProcessId && ProcessExist(ipScanProcessId)) {
                try ProcessClose(ipScanProcessId)
            }
            ipScanProcessId := 0
            for path in [ipScanScriptPath, ipScanResultPath, ipScanDonePath] {
                if (path != "" && FileExist(path)) {
                    try FileDelete(path)
                }
            }
            try {

                LV.Visible := false
            }
            IPScannerGui.Destroy()
        }

        aktualisiereListView(*) {
            Global LV, ipScanIPs, ipScanMacs, ipScanVendors, ipScanHostnames

            ; --- Zeichnen pausieren (kein Flackern) ---
            LV.Opt("-Redraw")
            ; Inhalt löschen
            LV.Delete()
            ;neue Daten hinzufügen
            if (ipScanIPs.Length > 0) {
                LV.Visible := true

                loop ipScanIPs.Length {
                    if (inputFilter.Value = "" || InStr(ipScanIPs[A_Index], inputFilter.Value) || InStr(ipScanMacs[A_Index], inputFilter.Value) || InStr(ipScanVendors[A_Index], inputFilter.Value) || InStr(ipScanHostnames[A_Index], inputFilter.Value))
                        LV.Add(, ipScanIPs[A_Index], ipScanMacs[A_Index], ipScanVendors[A_Index], ipScanHostnames[A_Index])
                }
            }


            ; --- Redraw wieder aktivieren ---
            LV.Opt("+Redraw")
        }


        showLv(*) {
            global lv_shown, LV, ipScanIPs, ipScanMacs, ipScanVendors, ipScanHostnames, inputIP, btnOK
            global ipAdress, inputFilter, zeitLabel
            global ipScanProcessId, ipScanResultPath, ipScanDonePath, ipScanStartTick, ipScanLastContent

            regex := "^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){2}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$"
            ipAdress := Trim(inputIP.Value)
            if !RegExMatch(ipAdress, regex) {
                MsgBox("Bitte ein gültiges Netzpräfix eingeben, z. B. 192.168.178")
                return
            }

            if (ipScanProcessId && ProcessExist(ipScanProcessId))
                return

            ipScanIPs := [], ipScanMacs := [], ipScanVendors := [], ipScanHostnames := []
            ipScanLastContent := ""
            LV.Delete()
            ipScanStartTick := A_TickCount
            zeitLabel.Text := "Suche läuft ... 0 Geräte gefunden"
            btnOK.Text := "Suche läuft ..."
            btnOK.Enabled := false

            suffix := DllCall("GetCurrentProcessId") "_" A_TickCount
            ipScanScriptPath := A_Temp "\ip-app-scan-" suffix ".ps1"
            ipScanResultPath := A_Temp "\ip-app-scan-" suffix ".txt"
            ipScanDonePath := A_Temp "\ip-app-scan-" suffix ".done"
            safeResult := StrReplace(ipScanResultPath, "'", "''")
            safeDone := StrReplace(ipScanDonePath, "'", "''")

            psScript := "`$ErrorActionPreference = 'SilentlyContinue'`n"
                . "`$prefix = '" ipAdress "'`n"
                . "`$resultPath = '" safeResult "'; `$donePath = '" safeDone "'`n"
                . "`$writer = `$null`n"
                . "try {`n"
                . "  `$stream = [System.IO.FileStream]::new(`$resultPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::ReadWrite)`n"
                . "  `$writer = [System.IO.StreamWriter]::new(`$stream, [System.Text.UTF8Encoding]::new(`$false)); `$writer.AutoFlush = `$true`n"
                . "  function Write-ScanResult([string]`$address, [string]`$mac, [string]`$name) {`n"
                . "    `$name = (`$name -replace '[|\r\n]', ' ').Trim()`n"
                . "    `$script:writer.WriteLine((`$address + '|' + `$mac + '|' + `$name))`n"
                . "  }`n"
                . "  `$probes = [System.Collections.Generic.List[object]]::new()`n"
                . "  1..254 | ForEach-Object {`n"
                . "    `$address = `$prefix + '.' + `$_`n"
                . "    try { `$ping = [System.Net.NetworkInformation.Ping]::new(); `$task = `$ping.SendPingAsync(`$address, 400); `$probes.Add([pscustomobject]@{ IP = `$address; Ping = `$ping; Task = `$task }) } catch { }`n"
                . "  }`n"
                . "  `$alive = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)`n"
                . "  `$pending = [System.Collections.Generic.List[object]]::new(); foreach (`$probe in `$probes) { `$pending.Add(`$probe) }`n"
                . "  while (`$pending.Count -gt 0) {`n"
                . "    for (`$i = `$pending.Count - 1; `$i -ge 0; `$i--) {`n"
                . "      `$probe = `$pending[`$i]; if (-not `$probe.Task.IsCompleted) { continue }`n"
                . "      if (-not `$probe.Task.IsFaulted) { try { if (`$probe.Task.Result.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) { [void]`$alive.Add(`$probe.IP); Write-ScanResult `$probe.IP '-' '-' } } catch { } }`n"
                . "      `$probe.Ping.Dispose(); `$pending.RemoveAt(`$i)`n"
                . "    }`n"
                . "    if (`$pending.Count -gt 0) { Start-Sleep -Milliseconds 25 }`n"
                . "  }`n"
                . "  `$devices = @{}; foreach (`$address in `$alive) { `$devices[`$address] = '-' }`n"
                . "  `$localConfigs = @(); try { `$localConfigs = @(Get-NetIPConfiguration | Where-Object { `$_.IPv4Address }) } catch { }`n"
                . "  `$localMacs = @{}; foreach (`$config in `$localConfigs) { `$mac = [string]`$config.NetAdapter.MacAddress; if (`$mac -notmatch '^(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$') { continue }; `$mac = `$mac.Replace(':','-').ToLowerInvariant(); foreach (`$address in `$config.IPv4Address) { `$localIP = [string]`$address.IPAddress; if (`$localIP -like (`$prefix + '.*')) { `$localMacs[`$localIP] = `$mac; `$devices[`$localIP] = `$mac } } }`n"
                . "  `$gatewayIP = `$null; try { `$networkConfig = `$localConfigs | Where-Object { `$_.IPv4Address.IPAddress -like (`$prefix + '.*') -and `$_.IPv4DefaultGateway } | Select-Object -First 1; if (`$networkConfig) { `$gatewayIP = [string]`$networkConfig.IPv4DefaultGateway.NextHop } } catch { }`n"
                . "  `$neighbors = @(); try { `$neighbors = @(Get-NetNeighbor -AddressFamily IPv4) } catch { }`n"
                . "  `$gatewayEntry = `$neighbors | Where-Object { `$_.IPAddress -eq `$gatewayIP } | Select-Object -First 1`n"
                . "  `$gatewayMac = if (`$gatewayEntry) { ([string]`$gatewayEntry.LinkLayerAddress).Replace(':','-').ToLowerInvariant() } else { '' }`n"
                . "  foreach (`$neighbor in `$neighbors) {`n"
                . "    if (`$neighbor.IPAddress -notlike (`$prefix + '.*') -or `$neighbor.State -notin @('Reachable','Delay','Probe') -or `$neighbor.LinkLayerAddress -notmatch '^(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$') { continue }`n"
                . "    `$neighborMac = `$neighbor.LinkLayerAddress.Replace(':','-').ToLowerInvariant()`n"
                . "    if (`$gatewayMac -ne '' -and `$neighbor.IPAddress -ne `$gatewayIP -and `$neighborMac -eq `$gatewayMac -and -not `$alive.Contains(`$neighbor.IPAddress)) { continue }`n"
                . "    `$devices[`$neighbor.IPAddress] = `$neighborMac`n"
                . "  }`n"
                . "  foreach (`$localIP in `$localMacs.Keys) { `$devices[`$localIP] = `$localMacs[`$localIP] }`n"
                . "  foreach (`$address in (`$devices.Keys | Sort-Object { [version]`$_ })) { Write-ScanResult `$address `$devices[`$address] '-' }`n"
                . "  `$resolvedNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)`n"
                . "  `$dnsPool = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspacePool(1, 32); `$dnsPool.Open()`n"
                . "  `$dnsScript = @'`n"
                . "param(`$ipAddress)`n"
                . "`$octets = `$ipAddress.Split('.')`n"
                . "`$reverse = `$octets[3] + '.' + `$octets[2] + '.' + `$octets[1] + '.' + `$octets[0] + '.in-addr.arpa'`n"
                . "try { Import-Module DnsClient -ErrorAction SilentlyContinue } catch { }`n"
                . "try { `$ptr = Resolve-DnsName -Name `$reverse -Type PTR -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Where-Object { `$_.Type -eq 'PTR' } | Select-Object -First 1; if (`$ptr.NameHost) { return ([string]`$ptr.NameHost).TrimEnd('.') } } catch { }`n"
                . "'@`n"
                . "  `$dnsJobs = @(); foreach (`$address in `$devices.Keys) {`n"
                . "    `$runner = [powershell]::Create(); `$runner.RunspacePool = `$dnsPool; [void]`$runner.AddScript(`$dnsScript).AddArgument(`$address)`n"
                . "    `$dnsJobs += [pscustomobject]@{ IP = `$address; Runner = `$runner; Handle = `$runner.BeginInvoke() }`n"
                . "  }`n"
                . "  `$dnsDeadline = [datetime]::UtcNow.AddMilliseconds(2500)`n"
                . "  do { `$pendingDns = @(`$dnsJobs | Where-Object { -not `$_.Handle.IsCompleted }); if (`$pendingDns.Count -eq 0) { break }; Start-Sleep -Milliseconds 50 } while ([datetime]::UtcNow -lt `$dnsDeadline)`n"
                . "  foreach (`$job in `$dnsJobs) {`n"
                . "    if (`$job.Handle.IsCompleted) { try { `$found = @(`$job.Runner.EndInvoke(`$job.Handle)); if (`$found.Count -gt 0 -and -not [string]::IsNullOrWhiteSpace([string]`$found[0])) { `$name = ([string]`$found[0]).Trim(); [void]`$resolvedNames.Add(`$job.IP); Write-ScanResult `$job.IP `$devices[`$job.IP] `$name } } catch { } } else { try { `$job.Runner.Stop() } catch { } }`n"
                . "    `$job.Runner.Dispose()`n"
                . "  }`n"
                . "  `$dnsPool.Close(); `$dnsPool.Dispose()`n"
                . "  `$missingNames = @(`$devices.Keys | Where-Object { -not `$resolvedNames.Contains(`$_) })`n"
                . "  `$pool = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspacePool(1, 24); `$pool.Open()`n"
                . "  `$nbtScript = @'`n"
                . "param(`$ipAddress)`n"
                . "`$nbtLines = & (`$env:SystemRoot + '\System32\nbtstat.exe') -A `$ipAddress 2>`$null`n"
                . "foreach (`$nbtLine in `$nbtLines) { if (`$nbtLine -match '^\s*([^\s<]+)\s+<00>\s+') { return `$matches[1].Trim() } }`n"
                . "'@`n"
                . "  `$jobs = @(); foreach (`$address in `$missingNames) {`n"
                . "    `$runner = [powershell]::Create(); `$runner.RunspacePool = `$pool; [void]`$runner.AddScript(`$nbtScript).AddArgument(`$address)`n"
                . "    `$jobs += [pscustomobject]@{ IP = `$address; Runner = `$runner; Handle = `$runner.BeginInvoke() }`n"
                . "  }`n"
                . "  `$deadline = [datetime]::UtcNow.AddSeconds(2)`n"
                . "  do { `$pendingJobs = @(`$jobs | Where-Object { -not `$_.Handle.IsCompleted }); if (`$pendingJobs.Count -eq 0) { break }; Start-Sleep -Milliseconds 50 } while ([datetime]::UtcNow -lt `$deadline)`n"
                . "  foreach (`$job in `$jobs) {`n"
                . "    if (`$job.Handle.IsCompleted) { try { `$found = @(`$job.Runner.EndInvoke(`$job.Handle)); if (`$found.Count -gt 0 -and -not [string]::IsNullOrWhiteSpace([string]`$found[0])) { Write-ScanResult `$job.IP `$devices[`$job.IP] ([string]`$found[0]) } } catch { } } else { try { `$job.Runner.Stop() } catch { } }`n"
                . "    `$job.Runner.Dispose()`n"
                . "  }`n"
                . "  `$pool.Close(); `$pool.Dispose()`n"
                . "} finally {`n"
                . "  if (`$null -ne `$writer) { `$writer.Dispose() }`n"
                . "  [System.IO.File]::WriteAllText(`$donePath, 'done')`n"
                . "}`n"

            try {
                FileAppend(psScript, ipScanScriptPath, "UTF-8")
                Run('powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' ipScanScriptPath '"', , "Hide", &ipScanProcessId)
                SetTimer(IPScannerPoll, 120)
            } catch Error as e {
                btnOK.Text := "Scannen"
                btnOK.Enabled := true
                zeitLabel.Text := "Scan konnte nicht gestartet werden"
                MsgBox("IP-Scan konnte nicht gestartet werden:`n" e.Message)
                if FileExist(ipScanScriptPath)
                    try FileDelete(ipScanScriptPath)
            }
        }

        ;Context Menu für ListView
        itemS(a, index, c, *) {
            ; Kopfzeile und freie Tabellenfläche liefern keinen gültigen Zeilenindex.
            if (index < 1 || index > LV.GetCount())
                return

            ipAddr := LV.GetText(index, 1)
            if (ipAddr = "")
                return
            macAddr := LV.GetText(index, 2)
            vendorName := LV.GetText(index, 3)
            hostName := LV.GetText(index, 4)

            httpLink := "http://" ipAddr
            httpsLink := "https://" ipAddr
            rdpLink := "mstsc /v:" ipaddr
            menuHttp := Menu()
            menuHttp.Add("Schließen", (*) => menuHttp.Delete())
            menuHttp.Add()
            menuHttp.Add("öffne http", (*) => Run(httpLink))
            menuHttp.Add("öffne https", (*) => Run(httpsLink))
            menuHttp.Add("öffne rdp", (*) => Run(rdpLink))
            menuHttp.Add()
            menuHttp.Add("kopiere IP", (*) => A_Clipboard := ipAddr)
            menuHttp.Add("kopiere MAC", (*) => A_Clipboard := macAddr)
            menuHttp.Add("kopiere Hersteller", (*) => A_Clipboard := vendorName)
            menuHttp.Add("kopiere Name", (*) => A_Clipboard := hostName)
            menuHttp.Show()


        }
    }
}

; Liest die fortlaufend geschriebenen Scan-Ergebnisse ein, ohne die GUI zu blockieren.
CenterIPScannerField(control, lineHeight := 20) {
    clientRect := Buffer(16, 0)
    if !DllCall("GetClientRect", "Ptr", control.Hwnd, "Ptr", clientRect.Ptr)
        return

    clientWidth := NumGet(clientRect, 8, "Int")
    clientHeight := NumGet(clientRect, 12, "Int")
    lineHeight := Min(lineHeight, clientHeight - 2)
    top := Max(0, Floor((clientHeight - lineHeight) / 2))

    NumPut("Int", 3, clientRect, 0)
    NumPut("Int", top, clientRect, 4)
    NumPut("Int", clientWidth - 3, clientRect, 8)
    NumPut("Int", top + lineHeight, clientRect, 12)
    DllCall("SendMessageW", "Ptr", control.Hwnd, "UInt", 0xB3, "Ptr", 0, "Ptr", clientRect.Ptr, "Ptr")
}
IPScannerPoll(*) {
    global ipScannerIsOpen, ipScanProcessId, ipScanResultPath, ipScanDonePath, ipScanScriptPath, ipScanStartTick, ipScanLastContent
    global ipScanIPs, ipScanMacs, ipScanVendors, ipScanHostnames, LV, inputFilter, zeitLabel, btnOK

    if (!ipScannerIsOpen) {
        SetTimer(IPScannerPoll, 0)
        return
    }

    content := ""
    if (ipScanResultPath != "" && FileExist(ipScanResultPath)) {
        try {
            content := FileRead(ipScanResultPath, "UTF-8")
        }
    }

    if (content != ipScanLastContent) {
        ipScanLastContent := content
        rows := Map()
        if (content != "") {
            for line in StrSplit(content, "`n", "`r") {
                if (line = "")
                    continue
                fields := StrSplit(line, "|")
                if (fields.Length >= 3 && fields[1] != "")
                    rows[fields[1]] := fields
            }
        }

        ipScanIPs := [], ipScanMacs := [], ipScanVendors := [], ipScanHostnames := []
        sortedRows := []
        for address, fields in rows {
            octets := StrSplit(address, ".")
            if (octets.Length != 4)
                continue
            lastOctet := Integer(octets[4])
            insertAt := sortedRows.Length + 1
            for position, row in sortedRows {
                if (lastOctet < row.lastOctet) {
                    insertAt := position
                    break
                }
            }
            sortedRows.InsertAt(insertAt, {address: address, fields: fields, lastOctet: lastOctet})
        }
        for row in sortedRows {
            ipScanIPs.Push(row.address)
            ipScanMacs.Push(row.fields[2])
            ipScanVendors.Push(findIPScannerManufacturer(row.fields[2]))
            ipScanHostnames.Push(row.fields[3] != "" ? row.fields[3] : "-")
        }

        LV.Opt("-Redraw")
        LV.Delete()
        for index, address in ipScanIPs {
            if (inputFilter.Value = "" || InStr(address, inputFilter.Value) || InStr(ipScanMacs[index], inputFilter.Value) || InStr(ipScanVendors[index], inputFilter.Value) || InStr(ipScanHostnames[index], inputFilter.Value))
                LV.Add(, address, ipScanMacs[index], ipScanVendors[index], ipScanHostnames[index])
        }
        LV.Opt("+Redraw")
    }

    isDone := (ipScanDonePath != "" && FileExist(ipScanDonePath))
    isRunning := (ipScanProcessId && ProcessExist(ipScanProcessId))
    elapsed := Round((A_TickCount - ipScanStartTick) / 1000, 1)
    if (!isDone && isRunning) {
        zeitLabel.Text := "Suche ... " ipScanIPs.Length " gefunden · " elapsed " s"
        return
    }

    SetTimer(IPScannerPoll, 0)
    btnOK.Text := "Scannen"
    btnOK.Enabled := true
    ipScanProcessId := 0
    if (isDone)
        zeitLabel.Text := "Fertig: " ipScanIPs.Length " Geräte · " elapsed " s"
    else
        zeitLabel.Text := "Abbruch: " ipScanIPs.Length " Geräte gefunden"

    for path in [ipScanScriptPath, ipScanResultPath, ipScanDonePath] {
        if (path != "" && FileExist(path)) {
            try FileDelete(path)
        }
    }
}

;------------------------------------------------------------------------------
; Vergleicht das normalisierte 24-Bit-OUI exakt statt per Teilstringsuche.
findIPScannerManufacturer(macAddress) {
    global macs
    static vendorByOui := Map()

    if (vendorByOui.Count = 0) {
        for rawOui, manufacturer in macs {
            oui := RegExReplace(StrUpper(Trim(rawOui)), "[^0-9A-F]", "")
            if (StrLen(oui) = 6)
                vendorByOui[oui] := Trim(manufacturer)
        }
    }

    normalizedMac := RegExReplace(StrUpper(macAddress), "[^0-9A-F]", "")
    if (StrLen(normalizedMac) < 6)
        return "-"

    oui := SubStr(normalizedMac, 1, 6)
    return vendorByOui.Has(oui) ? vendorByOui[oui] : "-"
}
; ip scanner ende
; DNS Tester
;------------------------------------------------------------------------------



