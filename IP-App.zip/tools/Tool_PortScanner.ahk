; Netzwerk-Tool: Port-Scanner.

global portScannerGuiIsOpen := false
global scanState := 0
global outputEdit
global portScanTimeoutOptions := ["5", "10", "15", "50", "100", "500", "1000"]

IsNumber(str) => (str ~= "^\d+$")
IsIP(ip) {
    if !(ip ~= "^\d{1,3}(\.\d{1,3}){3}$")
        return false
    for octet in StrSplit(ip, ".")
        if Integer(octet) > 255
            return false
    return true
}

OnActionClick(*) {
    global scanState, ip, start, end, timeout, outputEdit, actionBtn, ipEdit, startPortEdit, endPortEdit, timeoutDDL, portScanTimeoutOptions

    if IsObject(scanState) {
        FinishScan("Scan durch Benutzer abgebrochen.")
        return
    }

    ip := ipEdit.Value
    start := startPortEdit.Value
    end := endPortEdit.Value
    timeout := portScanTimeoutOptions[timeoutDDL.Value]

    if !IsNumber(start) || !IsNumber(end) || !IsNumber(timeout) {
        outputEdit.Value := "Eingabefehler: Nur Zahlen erlaubt."
        return
    }
    if !IsIP(ip) {
        outputEdit.Value := "Bitte gültige IP-Adresse eingeben."
        return
    }

    start := Integer(start), end := Integer(end), timeout := Integer(timeout)
    if (start < 1 || end > 65535 || start > end || timeout < 1) {
        outputEdit.Value := "Portbereich: 1–65535, Start-Port höchstens End-Port, Timeout mindestens 1 ms."
        return
    }

    outputEdit.Value := "Scanning " ip "...`n-------------------------------------`noffene Ports:`n-------------------------------------`n"
    actionBtn.Text := "Stop"
    StartPortScan(ip, start, end, timeout)
}

; Asynchroner TCP-Scan mit begrenzter Parallelität. Ergebnisse landen direkt in
; der GUI und werden nach Portnummer sortiert; temporäre Dateien werden nicht erzeugt.
StartPortScan(ip, startPort, endPort, timeout) {
    global scanState
    scanState := {
        ip: ip,
        nextPort: startPort,
        nextDisplayPort: startPort,
        endPort: endPort,
        timeout: timeout,
        pending: Map(),
        completed: Map()
    }
    SetTimer(ScanPortBatch, 10)
    ScanPortBatch()
}

ScanPortBatch() {
    global scanState
    if !IsObject(scanState)
        return

    state := scanState
    started := 0
    while (state.nextPort <= state.endPort && state.pending.Count < 128 && started < 128) {
        port := state.nextPort++
        StartPortProbe(state, port)
        started += 1
    }

    PollPortProbes(state)
    FlushPortResults(state)
    if (state.nextPort > state.endPort && state.pending.Count = 0 && state.completed.Count = 0)
        FinishScan("Scan abgeschlossen.")
}

StartPortProbe(state, port) {
    global Socket
    static AF_INET := 2, SOCK_STREAM := 1, IPPROTO_TCP := 6, FIONBIO := 0x8004667E
    ; Socket-Klasse initialisiert Winsock für den Prozess.
    _ := Socket.TYPE.STREAM
    parts := StrSplit(state.ip, ".")
    address := Buffer(16, 0)
    NumPut("UShort", AF_INET, address, 0)
    NumPut("UShort", ((port & 0xFF) << 8) | (port >> 8), address, 2)
    addressValue := (Integer(parts[4]) << 24) | (Integer(parts[3]) << 16) | (Integer(parts[2]) << 8) | Integer(parts[1])
    NumPut("UInt", addressValue, address, 4)

    sockHandle := DllCall("ws2_32\socket", "Int", AF_INET, "Int", SOCK_STREAM, "Int", IPPROTO_TCP, "Ptr")
    if (sockHandle = -1) {
        MarkPortResult(state, port, false)
        return
    }

    nonBlocking := 1
    if DllCall("ws2_32\ioctlsocket", "Ptr", sockHandle, "UInt", FIONBIO, "UInt*", &nonBlocking) {
        DllCall("ws2_32\closesocket", "Ptr", sockHandle)
        MarkPortResult(state, port, false)
        return
    }

    result := DllCall("ws2_32\connect", "Ptr", sockHandle, "Ptr", address, "Int", 16, "Int")
    if (result = 0) {
        DllCall("ws2_32\closesocket", "Ptr", sockHandle)
        MarkPortResult(state, port, true)
        return
    }

    socketError := DllCall("ws2_32\WSAGetLastError", "Int")
    if (socketError = 10035) { ; WSAEWOULDBLOCK: Verbindung läuft asynchron.
        state.pending[sockHandle] := { port: port, started: A_TickCount }
    } else {
        DllCall("ws2_32\closesocket", "Ptr", sockHandle)
        MarkPortResult(state, port, false)
    }
}

PollPortProbes(state) {
    if (state.pending.Count = 0)
        return

    entrySize := (A_PtrSize = 8) ? 16 : 8 ; WSAPOLLFD alignment
    handles := []
    pollBuffer := Buffer(state.pending.Count * entrySize, 0)
    index := 0
    for sockHandle, probe in state.pending {
        offset := index * entrySize
        NumPut("UPtr", sockHandle, pollBuffer, offset)
        NumPut("Short", 0x0010, pollBuffer, offset + A_PtrSize) ; POLLWRNORM
        handles.Push(sockHandle)
        index += 1
    }

    if (DllCall("ws2_32\WSAPoll", "Ptr", pollBuffer, "UInt", handles.Length, "Int", 0, "Int") > 0) {
        for index, sockHandle in handles {
            offset := (index - 1) * entrySize
            revents := NumGet(pollBuffer, offset + A_PtrSize + 2, "Short")
            if (revents = 0 || !state.pending.Has(sockHandle))
                continue

            probe := state.pending[sockHandle]
            errorBuffer := Buffer(4, 0)
            errorLength := 4
            sockOptResult := DllCall("ws2_32\getsockopt", "Ptr", sockHandle, "Int", 0xFFFF, "Int", 0x1007, "Ptr", errorBuffer, "Int*", &errorLength, "Int")
            isOpen := (sockOptResult = 0 && NumGet(errorBuffer, 0, "Int") = 0)
            DllCall("ws2_32\closesocket", "Ptr", sockHandle)
            state.pending.Delete(sockHandle)
            MarkPortResult(state, probe.port, isOpen)
        }
    }

    now := A_TickCount
    expired := []
    for sockHandle, probe in state.pending
        if (now - probe.started >= state.timeout)
            expired.Push([sockHandle, probe.port])
    for item in expired {
        sockHandle := item[1]
        DllCall("ws2_32\closesocket", "Ptr", sockHandle)
        state.pending.Delete(sockHandle)
        MarkPortResult(state, item[2], false)
    }
}

MarkPortResult(state, port, isOpen) {
    state.completed[port] := isOpen
}

FlushPortResults(state) {
    global outputEdit, TcpPortMap
    updated := false
    while state.completed.Has(state.nextDisplayPort) {
        port := state.nextDisplayPort
        if state.completed[port] {
            service := TcpPortMap.Has(port) ? TcpPortMap[port] : "Unbekannt"
            outputEdit.Value .= port "  " service "`n"
            updated := true
        }
        state.completed.Delete(port)
        state.nextDisplayPort += 1
    }
    if updated
        SendMessage(0x0115, 7, 0, outputEdit.Hwnd, "User32.dll")
}

FinishScan(message) {
    global scanState, outputEdit, actionBtn
    SetTimer(ScanPortBatch, 0)
    if IsObject(scanState)
        for sockHandle, probe in scanState.pending
            DllCall("ws2_32\closesocket", "Ptr", sockHandle)
    scanState := 0
    actionBtn.Text := "Start"
    outputEdit.Value .= "`n-------------------------------------`n" message
    SendMessage(0x0115, 7, 0, outputEdit.Hwnd, "User32.dll")
}
öffnePortScanner(*) {
    ; nur 1 Fenster zulassen
    global portScannerGuiIsOpen
    global frmIP, scanState, ip, start, end, timeout, outputEdit, actionBtn, ipEdit, startPortEdit, endPortEdit, timeoutDDL

    if (!portScannerGuiIsOpen) {
        portScannerGuiIsOpen := true
        PortScannerGui := Gui(, "Port Scanner")
        ApplyLightAppTheme(PortScannerGui, 10)


        PortScannerGui.SetFont("s19 bold c182230", "Segoe UI")
        PortScannerGui.Add("Text", "x24 y18 w700 h34 +0x200", "Offene Ports finden")
        PortScannerGui.SetFont("s10 c65748B", "Segoe UI")
        PortScannerGui.Add("Text", "x26 y54 w700 h22 +0x200", "Prüfe einen Portbereich auf einem Ziel im lokalen oder erreichbaren Netzwerk.")

        PortScannerGui.SetFont("s10 bold c344054", "Segoe UI")
        PortScannerGui.Add("Text", "x24 y100 w320 h20 +0x200", "Ziel-IP-Adresse")
        PortScannerGui.Add("Text", "x366 y100 w96 h20 +0x200", "Start-Port")
        PortScannerGui.Add("Text", "x480 y100 w96 h20 +0x200", "End-Port")
        PortScannerGui.Add("Text", "x594 y100 w142 h20 +0x200", "Timeout (ms)")
        PortScannerGui.SetFont("s11", "Segoe UI")
        ipEdit := PortScannerGui.Add("Edit", "x24 y124 w320 h36 Multi -VScroll -Wrap", frmIP.Value)
        startPortEdit := PortScannerGui.Add("Edit", "x366 y124 w96 h36 Number Multi -VScroll -Wrap", "1")
        endPortEdit := PortScannerGui.Add("Edit", "x480 y124 w96 h36 Number Multi -VScroll -Wrap", "1024")
        timeoutDDL := PortScannerGui.Add("DropDownList", "x594 y124 w140 h32 r7 +0x10 Choose1", portScanTimeoutOptions)
        timeoutDDL.SetFont("s11", "Segoe UI")
        OnMessage(0x002B, DrawTimeoutDropdown, 1) ; WM_DRAWITEM

        PortScannerGui.SetFont("s9 c65748B", "Segoe UI")
        PortScannerGui.Add("Text", "x26 y164 w480 h20 +0x200", "Kleiner Timeout beschleunigt den Scan, kann aber langsame Geräte übersehen.")
        PortScannerGui.SetFont("s10 bold", "Segoe UI")
        actionBtn := PortScannerGui.Add("Button", "x590 y184 w146 h42 Default", "Start")
        actionBtn.SetFont("s12 bold", "Segoe UI")
        actionBtn.OnEvent("Click", OnActionClick)

        PortScannerGui.SetFont("s10 bold c344054", "Segoe UI")
        PortScannerGui.Add("Text", "x24 y226 w300 h22 +0x200", "Scan-Ausgabe")

        outputEdit := PortScannerGui.Add("Edit", "x24 y252 w712 h306 ReadOnly Multi VScroll", "")

        PortScannerGui.SetFont("s9 c65748B", "Segoe UI")
        PortScannerGui.Add("Text", "x24 y574 w712 h20 +0x200", "Gefundene Ports erscheinen laufend. „Stop“ beendet den Scan.")

        PortScannerGui.OnEvent("Close", (*) => (portScannerGuiIsOpen := false, OnMessage(0x002B, DrawTimeoutDropdown, 0), subWindowClosed()))
        PortScannerGui.Show("w760 h612")
        CenterPortScannerField(ipEdit, 20)
        CenterPortScannerField(startPortEdit, 20)
        CenterPortScannerField(endPortEdit, 20)
        ; Auswahlzeile auf die 32-Pixel-Box abstimmen; ihre Mitte entspricht so
        ; genau der Mitte der benachbarten 36-Pixel-Eingabefelder.
        DllCall("SendMessageW", "Ptr", timeoutDDL.Hwnd, "UInt", 0x153, "Ptr", -1, "Ptr", 30, "Ptr")
        PortScannerGui.Move(setWindowPos(PortScannerGui), getWindowInfo(MeineGui).y)
    }
}

DrawTimeoutDropdown(wParam, lParam, msg, hwnd) {
    global timeoutDDL, portScanTimeoutOptions
    if !IsSet(timeoutDDL) || !IsObject(timeoutDDL)
        return

    is64 := (A_PtrSize = 8)
    itemHwndOffset := is64 ? 24 : 20
    hdcOffset := is64 ? 32 : 24
    rectOffset := is64 ? 40 : 28
    if (NumGet(lParam, itemHwndOffset, "Ptr") != timeoutDDL.Hwnd)
        return

    itemId := NumGet(lParam, 8, "UInt")
    itemState := NumGet(lParam, 16, "UInt")
    hdc := NumGet(lParam, hdcOffset, "Ptr")
    rect := Buffer(16, 0)
    for offset in [0, 4, 8, 12]
        NumPut("Int", NumGet(lParam, rectOffset + offset, "Int"), rect, offset)

    selected := (itemState & 0x0001) != 0 ; ODS_SELECTED
    colorIndex := selected ? 14 : 8 ; COLOR_HIGHLIGHTTEXT / COLOR_GRAYTEXT
    brushIndex := selected ? 13 : 5 ; COLOR_HIGHLIGHT / COLOR_WINDOW
    brush := DllCall("user32\GetSysColorBrush", "Int", brushIndex, "Ptr")
    DllCall("user32\FillRect", "Ptr", hdc, "Ptr", rect, "Ptr", brush)
    DllCall("gdi32\SetBkMode", "Ptr", hdc, "Int", 1) ; TRANSPARENT
    textColor := DllCall("user32\GetSysColor", "Int", colorIndex, "UInt")
    DllCall("gdi32\SetTextColor", "Ptr", hdc, "UInt", textColor)

    if (itemId = 0xFFFFFFFF) {
        selectedIndex := timeoutDDL.Value
        label := (selectedIndex >= 1 && selectedIndex <= portScanTimeoutOptions.Length) ? portScanTimeoutOptions[selectedIndex] : portScanTimeoutOptions[1]
    } else {
        label := portScanTimeoutOptions[itemId + 1]
    }

    NumPut("Int", NumGet(rect, 0, "Int") + 8, rect, 0)
    NumPut("Int", NumGet(rect, 8, "Int") - 6, rect, 8)
    DllCall("user32\DrawTextW", "Ptr", hdc, "Str", label, "Int", -1, "Ptr", rect, "UInt", 0x824, "Int") ; DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX
    return 1
}

CenterPortScannerField(control, lineHeight := 30) {
    clientRect := Buffer(16, 0)
    if !DllCall("GetClientRect", "Ptr", control.Hwnd, "Ptr", clientRect.Ptr)
        return

    clientWidth := NumGet(clientRect, 8, "Int")
    clientHeight := NumGet(clientRect, 12, "Int")
    lineHeight := Min(lineHeight, clientHeight - 2)
    top := Max(0, Floor((clientHeight - lineHeight) / 2))

    NumPut("Int", 3, clientRect, 0)
    NumPut("Int", top, clientRect, 4)
    NumPut("Int", clientWidth - 3, clientRect, 8)
    NumPut("Int", top + lineHeight, clientRect, 12)
    DllCall("SendMessageW", "Ptr", control.Hwnd, "UInt", 0xB3, "Ptr", 0, "Ptr", clientRect.Ptr, "Ptr")
}
subWindowClosed() {
    global scanState
    SetTimer(ScanPortBatch, 0)
    if IsObject(scanState)
        for sockHandle, probe in scanState.pending
            DllCall("ws2_32\closesocket", "Ptr", sockHandle)
    scanState := 0
}

; Kompatibilität für den Erreichbarkeit-Reiter, der einzelne Ports prüft.
class PortScanner {
    static Scan(host, ports, timeout := 1000) {
        global Socket
        results := Map()
        for port in ports {
            try {
                client := Socket.Client(host, port, Socket.TYPE.STREAM, Socket.IPPROTO.TCP)
                client.Close()
                results[port] := "Open"
            } catch as e {
                if (e.Number = 10061)
                    results[port] := "Closed"
                else if (e.Number = 10060)
                    results[port] := "Filtered/Timeout"
                else
                    results[port] := "Error: " e.Message
            }
        }
        return results
    }

    static ScanRange(host, startPort, endPort, timeout := 1000) {
        ports := []
        loop endPort - startPort + 1
            ports.Push(startPort + A_Index - 1)
        return this.Scan(host, ports, timeout)
    }

    static QuickScan(host, timeout := 500) {
        global Socket
        return this.Scan(host, [21, 22, 23, 25, 53, 80, 110, 443, 993, 995, 3389], timeout)
    }
}


;--------Ende Port Scanner--------------
