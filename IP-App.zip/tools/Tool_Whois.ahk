; Netzwerk-Tool: WHOIS-Abfrage per TCP/43 ohne Konsolenfenster.

global whoisToolOpen := false
global whoisGui, whoisQueryEdit, whoisStatusText, whoisSummaryList, whoisRawEdit, whoisProgress
global whoisSocket := 0, whoisSocketChunks := [], whoisTimeoutCallback := 0
global whoisQueryValue := "", whoisQueryKind := "", whoisCurrentServer := ""
global whoisQueryStage := 0, whoisQueryGeneration := 0, whoisBusy := false, whoisResponseBytes := 0
global whoisLastDataTick := 0

öffneWhois(*) {
    global MeineGui, whoisToolOpen, whoisGui, whoisQueryEdit, whoisStatusText
    global whoisSummaryList, whoisRawEdit, whoisProgress, pingZiele

    if whoisToolOpen {
        try WinActivate("ahk_id " whoisGui.Hwnd)
        return
    }
    whoisToolOpen := true
    whoisGui := Gui(, "WHOIS-Abfrage")
    ApplyLightAppTheme(whoisGui, 10)

    whoisGui.SetFont("s18 bold c182230", "Segoe UI")
    whoisGui.Add("Text", "x24 y18 w660 h34 +0x200", "WHOIS-Abfrage")
    whoisGui.SetFont("s10 c65748B", "Segoe UI")
    whoisGui.Add("Text", "x26 y54 w660 h22 +0x200", "Registrierungs- und Netzwerkinformationen zu Domains und IP-Adressen abrufen.")

    whoisGui.SetFont("s10 bold c344054", "Segoe UI")
    whoisGui.Add("GroupBox", "x20 y86 w680 h102", "Abfrage")
    whoisGui.Add("Text", "x34 y108 w130 h22 +0x200", "Domain oder IP")
    whoisGui.SetFont("s10", "Segoe UI")
    whoisTargets := []
    seenWhoisTargets := Map()
    for target in pingZiele {
        targetValue := IsObject(target) ? target[1] : target
        targetValue := Trim(targetValue)
        targetKey := StrLower(targetValue)
        if (targetValue != "" && !seenWhoisTargets.Has(targetKey)) {
            whoisTargets.Push(targetValue)
            seenWhoisTargets[targetKey] := true
        }
    }
    whoisQueryEdit := whoisGui.Add("ComboBox", "x34 y132 w420 h30 r8", whoisTargets)
    whoisQueryEdit.SetFont("s12", "Segoe UI")
    clearQueryButton := whoisGui.Add("Button", "x460 y132 w24 h30", "×")
    clearQueryButton.SetFont("s10 bold", "Segoe UI")
    clearQueryButton.OnEvent("Click", WhoisClearInput)
    queryButton := whoisGui.Add("Button", "x490 y132 w126 h30 Default", "Abfragen")
    queryButton.SetFont("s10 bold", "Segoe UI")
    queryButton.OnEvent("Click", WhoisStartQuery)
    cancelButton := whoisGui.Add("Button", "x624 y132 w62 h30", "Stopp")
    cancelButton.OnEvent("Click", WhoisCancelQuery)
    whoisGui.SetFont("s9 c65748B", "Segoe UI")
    whoisStatusText := whoisGui.Add("Text", "x34 y166 w440 h20 +0x200", "Bereit. Direkte Abfrage über WHOIS-Server (TCP-Port 43).")
    whoisProgress := whoisGui.Add("Progress", "x490 y171 w184 h6 Hidden +0x8", 0)

    whoisGui.SetFont("s10 bold c344054", "Segoe UI")
    whoisGui.Add("GroupBox", "x20 y198 w680 h208", "Übersicht")
    whoisSummaryList := whoisGui.AddListView("x32 y220 w656 h174 -Multi +Grid", ["Angabe", "Wert"])
    whoisSummaryList.ModifyCol(1, 170)
    whoisSummaryList.ModifyCol(2, 460)

    whoisGui.SetFont("s10 bold c344054", "Segoe UI")
    whoisGui.Add("GroupBox", "x20 y416 w680 h150", "Vollständige WHOIS-Antwort")
    whoisGui.SetFont("s9", "Segoe UI")
    whoisRawEdit := whoisGui.Add("Edit", "x32 y438 w656 h116 ReadOnly Multi -HScroll +VScroll -Wrap", "")
    whoisRawEdit.SetFont("s9", "Consolas")

    whoisGui.OnEvent("Close", WhoisClose)
    whoisGui.Show("w720 h585")
    whoisGui.Move(setWindowPos(whoisGui), getWindowInfo(MeineGui).y)

}

WhoisClose(*) {
    global whoisToolOpen
    WhoisCancelQuery()
    whoisToolOpen := false
}

WhoisClearInput(*) {
    global whoisQueryEdit
    whoisQueryEdit.Text := ""
    whoisQueryEdit.Focus()
}

WhoisStartQuery(*) {
    global whoisQueryEdit, whoisStatusText, whoisSummaryList, whoisRawEdit
    global whoisQueryValue, whoisQueryKind, whoisQueryStage, whoisQueryGeneration
    global whoisBusy, whoisProgress

    query := Trim(whoisQueryEdit.Text)
    query := RegExReplace(query, "i)^https?://", "")
    query := RegExReplace(query, "[/#?].*$")
    query := Trim(query, " `t`r`n.")
    if (query = "") {
        whoisStatusText.Text := "Bitte eine Domain oder IP-Adresse eingeben."
        whoisQueryEdit.Focus()
        return
    }

    if WhoisIsIPv4(query) || (InStr(query, ":") && RegExMatch(query, "^[0-9A-Fa-f:]+$")) {
        whoisQueryKind := "IP"
        server := "whois.arin.net"
        whoisQueryValue := query
    } else if RegExMatch(query, "i)^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9-]{2,63}$") {
        whoisQueryKind := "Domain"
        server := "whois.iana.org"
        whoisQueryValue := StrLower(query)
    } else {
        whoisStatusText.Text := "Ungültige Eingabe. Bitte eine Domain oder IPv4-/IPv6-Adresse prüfen."
        return
    }

    WhoisCancelQuery()
    whoisQueryGeneration += 1
    whoisQueryStage := 0
    whoisBusy := true
    SetToolWaitAnimation(whoisProgress, true)
    whoisSummaryList.Delete()
    whoisRawEdit.Value := ""
    whoisStatusText.Text := "Verbinde mit " server " …"
    SetTimer(WhoisConnectAndSend.Bind(server, whoisQueryValue, whoisQueryGeneration), -20)
}

WhoisIsIPv4(value) {
    parts := StrSplit(value, ".")
    if (parts.Length != 4)
        return false
    for part in parts {
        if !(part ~= "^\d{1,3}$") || Integer(part) > 255
            return false
    }
    return true
}

WhoisConnectAndSend(server, query, generation) {
    global whoisSocket, whoisSocketChunks, whoisTimeoutCallback, whoisCurrentServer, whoisResponseBytes, whoisLastDataTick
    global whoisStatusText, whoisQueryKind, whoisQueryGeneration

    if (generation != whoisQueryGeneration)
        return

    try {
        whoisSocket := Socket.Client(server, 43, Socket.TYPE.STREAM, Socket.IPPROTO.TCP)
        whoisCurrentServer := server
        whoisSocketChunks := []
        whoisResponseBytes := 0
        whoisLastDataTick := 0
        if (StrLower(server) = "whois.denic.de")
            wireQuery := "-T dn " query
        else if (whoisQueryKind = "IP" && StrLower(server) = "whois.arin.net")
            wireQuery := "n " query
        else
            wireQuery := query
        whoisSocket.SendText(wireQuery "`r`n", "utf-8")
        nonBlocking := 1
        if DllCall("ws2_32\ioctlsocket", "Ptr", whoisSocket.Ptr, "UInt", 0x8004667E, "UInt*", &nonBlocking, "Int")
            throw OSError(DllCall("ws2_32\WSAGetLastError", "Int"))
        whoisStatusText.Text := "Abfrage bei " server " …"
        whoisTimeoutCallback := WhoisTimeout.Bind(generation, server)
        SetTimer(whoisTimeoutCallback, -15000)
        SetTimer(WhoisPollSocket, 40)
    } catch as err {
        if WhoisTryRdapFallback(generation)
            return
        WhoisFinishError("Verbindung zu " server " fehlgeschlagen: " err.Message, generation)
    }
}

WhoisPollSocket() {
    global whoisSocket, whoisSocketChunks, whoisResponseBytes, whoisBusy, whoisQueryGeneration, whoisLastDataTick
    if (!whoisBusy || !IsObject(whoisSocket)) {
        SetTimer(WhoisPollSocket, 0)
        return
    }

    readBuffer := Buffer(8192, 0)
    loop 8 {
        received := DllCall("ws2_32\recv", "Ptr", whoisSocket.Ptr, "Ptr", readBuffer.Ptr, "Int", readBuffer.Size, "Int", 0, "Int")
        if (received > 0) {
            chunk := Buffer(received, 0)
            DllCall("RtlMoveMemory", "Ptr", chunk.Ptr, "Ptr", readBuffer.Ptr, "UPtr", received)
            whoisSocketChunks.Push(chunk)
            whoisResponseBytes += received
            whoisLastDataTick := A_TickCount
            if (whoisResponseBytes > 2097152) {
                SetTimer(WhoisPollSocket, 0)
                WhoisFinishError("Die WHOIS-Antwort überschreitet 2 MB.", whoisQueryGeneration)
                return
            }
            continue
        }
        if (received = 0) {
            SetTimer(WhoisPollSocket, 0)
            WhoisHandleResponse(whoisQueryGeneration)
            return
        }
        socketError := DllCall("ws2_32\WSAGetLastError", "Int")
        if (socketError = 10035 || socketError = 10004) {
            if (whoisResponseBytes && A_TickCount - whoisLastDataTick >= 500) {
                SetTimer(WhoisPollSocket, 0)
                WhoisHandleResponse(whoisQueryGeneration)
            }
            return
        }
        SetTimer(WhoisPollSocket, 0)
        if WhoisTryRdapFallback(whoisQueryGeneration)
            return
        WhoisFinishError("WHOIS-Verbindung fehlgeschlagen (Winsock " socketError ").", whoisQueryGeneration)
        return
    }
}

WhoisHandleResponse(generation) {
    global whoisSocketChunks, whoisTimeoutCallback, whoisQueryValue, whoisQueryStage
    global whoisCurrentServer, whoisSocket, whoisStatusText, whoisQueryGeneration
    if (generation != whoisQueryGeneration)
        return
    if IsObject(whoisTimeoutCallback)
        SetTimer(whoisTimeoutCallback, 0)
    response := WhoisChunksToText(whoisSocketChunks)
    server := whoisCurrentServer
    try whoisSocket.Close()
    whoisSocket := 0
    if (Trim(response) = "") {
        if WhoisTryRdapFallback(generation)
            return
        WhoisFinishError("WHOIS-Port 43 und RDAP haben keine Daten zurückgegeben. Prüfe Internetverbindung oder Firewall.", generation)
        return
    }

    ; DENIC ohne -T dn gibt nur Domain und Status (z. B. "connect") aus.
    ; Das ist kein vollständiger Datensatz; dann RDAP als ergänzende Quelle versuchen.
    if (StrLower(server) = "whois.denic.de" && WhoisIsDenicStatusOnly(response)) {
        if WhoisTryRdapFallback(generation)
            return
    }

    referral := WhoisFindReferral(response)
    if (referral != "" && StrLower(referral) != StrLower(server) && whoisQueryStage < 2) {
        whoisQueryStage += 1
        whoisStatusText.Text := "Weiterleitung zu " referral " …"
        WhoisConnectAndSend(referral, whoisQueryValue, generation)
        return
    }

    WhoisShowResults(response, server, generation)
}

WhoisIsDenicStatusOnly(response) {
    meaningfulLines := 0
    for line in StrSplit(Trim(response), "`n") {
        line := Trim(line, " `t`r`n")
        if (line = "")
            continue
        if RegExMatch(line, "i)^Domain(?:-Ace)?:\s*.+$") || RegExMatch(line, "i)^Status:\s*connect$")
            continue
        meaningfulLines += 1
    }
    return meaningfulLines = 0
}

WhoisChunksToText(chunks) {
    total := 0
    for chunk in chunks
        total += chunk.Size
    if (total = 0)
        return ""
    joined := Buffer(total + 1, 0)
    offset := 0
    for chunk in chunks {
        DllCall("RtlMoveMemory", "Ptr", joined.Ptr + offset, "Ptr", chunk.Ptr, "UPtr", chunk.Size)
        offset += chunk.Size
    }
    return StrGet(joined, "UTF-8")
}

WhoisFindReferral(response) {
    if RegExMatch(response, "im)^\s*(?:refer|whois|registrar whois server|whois server|referralserver)\s*:\s*(?:whois://)?([^\s]+)", &match) {
        host := Trim(match[1], " `t`r`n")
        if InStr(host, "://")
            return ""
        if (host ~= "i)^whois\.[a-z0-9.-]+$" || host ~= "i)^[a-z0-9.-]+\.whois\.[a-z0-9.-]+$")
            return host
        if (host ~= "i)^[a-z0-9.-]+$")
            return host
    }
    return ""
}

WhoisTryRdapFallback(generation) {
    global whoisQueryKind, whoisQueryValue, whoisStatusText, whoisQueryGeneration
    global whoisTimeoutCallback, whoisSocket
    if (generation != whoisQueryGeneration)
        return false

    if IsObject(whoisTimeoutCallback)
        SetTimer(whoisTimeoutCallback, 0)
    SetTimer(WhoisPollSocket, 0)
    try whoisSocket.Close()
    whoisSocket := 0
    whoisStatusText.Text := "WHOIS-Port 43 antwortet nicht — versuche RDAP …"
    try {
        endpoint := whoisQueryKind = "IP" ? "ip/" : "domain/"
        request := ComObject("WinHttp.WinHttpRequest.5.1")
        request.SetTimeouts(5000, 5000, 5000, 12000)
        request.Open("GET", "https://rdap.org/" endpoint whoisQueryValue, false)
        request.SetRequestHeader("Accept", "application/rdap+json, application/json")
        request.Send()
        if (request.Status < 200 || request.Status >= 300 || Trim(request.ResponseText) = "")
            return false

        response := WhoisRdapToText(request.ResponseText)
        if (Trim(response) = "")
            return false
        WhoisShowResults(response, "RDAP", generation)
        return true
    } catch {
        return false
    }
}

WhoisRdapToText(json) {
    fields := Map(
        "ldhName", "Domain Name", "unicodeName", "Domain Name", "handle", "Registry Domain ID",
        "name", "Name", "country", "Country", "startAddress", "NetRange Start", "endAddress", "NetRange End",
        "ipVersion", "IP Version", "port43", "WHOIS Server", "remarks", "Remarks",
        "eventAction", "Event", "eventDate", "Date", "email", "Email", "tel", "Telephone",
        "fn", "Contact", "org", "Organization", "street", "Address", "locality", "City",
        "region", "State/Region", "postalCode", "Postal Code"
    )
    output := ""
    for key, label in fields {
        pattern := 'i)"' key '"\s*:\s*"((?:[^"\\]|\\.)*)"'
        pos := 1
        while RegExMatch(json, pattern, &match, pos) {
            value := StrReplace(match[1], Chr(92) Chr(34), Chr(34))
            value := StrReplace(value, Chr(92) "n", " ")
            value := StrReplace(value, Chr(92) "r", " ")
            if (value != "")
                output .= label ": " value "`r`n"
            pos := match.Pos + match.Len
        }
    }
    return output
}

WhoisShowResults(response, server, generation) {
    global whoisSummaryList, whoisRawEdit, whoisStatusText, whoisQueryValue, whoisQueryKind, whoisBusy, whoisQueryGeneration, whoisProgress
    if (generation != whoisQueryGeneration)
        return
    whoisRawEdit.Value := Trim(response, "`r`n")
    whoisSummaryList.Delete()

    fields := Map(
        "domain name", "Domain", "registry domain id", "Registry-ID", "registrar", "Registrar",
        "registrar whois server", "WHOIS-Server", "registrant organization", "Organisation",
        "name", "Name", "netrange start", "IP-Bereich Start", "netrange end", "IP-Bereich Ende",
        "ip version", "IP-Version", "event", "Ereignis", "date", "Datum", "email", "E-Mail",
        "telephone", "Telefon", "contact", "Kontakt", "state/region", "Region",
        "registrant country", "Land", "netname", "Netzwerk", "orgname", "Organisation",
        "orgid", "Organisation-ID", "netrange", "IP-Bereich", "cidr", "CIDR",
        "country", "Land", "creation date", "Erstellt", "created", "Erstellt",
        "updated date", "Aktualisiert", "last updated", "Aktualisiert",
        "registry expiry date", "Läuft ab", "expiration date", "Läuft ab",
        "name server", "Nameserver", "nserver", "Nameserver", "domain status", "Status",
        "status", "Status", "organization", "Organisation", "address", "Adresse",
        "city", "Ort", "state/province", "Region", "postal code", "PLZ",
        "abuse contact email", "Abuse-Kontakt", "originas", "Ursprungs-AS"
    )
    seen := Map()
    for line in StrSplit(response, "`n") {
        if RegExMatch(line, "^\s*([^:#]+?)\s*:\s*(.*?)\s*$", &match) {
            rawKey := Trim(match[1])
            rawValue := Trim(match[2])
            if (rawValue = "")
                continue
            normalized := StrLower(rawKey)
            if fields.Has(normalized) {
                label := fields[normalized]
                key := label "|" rawValue
                if !seen.Has(key) {
                    whoisSummaryList.Add(, label, rawValue)
                    seen[key] := true
                }
            }
        }
    }
    if (whoisSummaryList.GetCount() = 0)
        whoisSummaryList.Add(, "Abfrage", "Keine bekannten Felder erkannt; vollständige Antwort unten.")
    whoisSummaryList.ModifyCol(1, 170)
    whoisSummaryList.ModifyCol(2, 460)
    whoisBusy := false
    SetToolWaitAnimation(whoisProgress, false)
    whoisStatusText.Text := whoisQueryKind " " whoisQueryValue " — Antwort von " server "."
}

WhoisTimeout(generation, server) {
    if !WhoisTryRdapFallback(generation)
        WhoisFinishError("Zeitüberschreitung bei " server ". WHOIS-Port 43 und RDAP sind nicht erreichbar.", generation)
}

WhoisFinishError(message, generation) {
    global whoisQueryGeneration, whoisBusy, whoisSocket, whoisTimeoutCallback, whoisStatusText, whoisProgress
    if (generation != whoisQueryGeneration)
        return
    whoisBusy := false
    if IsObject(whoisTimeoutCallback)
        SetTimer(whoisTimeoutCallback, 0)
    whoisQueryGeneration += 1
    try whoisSocket.Close()
    whoisSocket := 0
    SetTimer(WhoisPollSocket, 0)
    SetToolWaitAnimation(whoisProgress, false)
    whoisStatusText.Text := message
}

WhoisCancelQuery(*) {
    global whoisQueryGeneration, whoisBusy, whoisSocket, whoisTimeoutCallback, whoisStatusText, whoisProgress
    whoisQueryGeneration += 1
    whoisBusy := false
    if IsObject(whoisTimeoutCallback)
        SetTimer(whoisTimeoutCallback, 0)
    try whoisSocket.Close()
    whoisSocket := 0
    SetTimer(WhoisPollSocket, 0)
    SetToolWaitAnimation(whoisProgress, false)
    if IsSet(whoisStatusText) && IsObject(whoisStatusText)
        whoisStatusText.Text := "Abfrage abgebrochen."
}
