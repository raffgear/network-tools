; Netzwerk-Tool: Speedtest-Auswahl.

global zieleIsOpen := false

öffneInternetSpeedtest(*) {
    ; nur 1 Fenster zulassen
    global zieleIsOpen
    g := Gui(, "Speedtests")
    ApplyLightAppTheme(g, 10)
    if (!zieleIsOpen) {
        ; Mausposition abrufen
        CoordMode "Mouse"
        MouseGetPos(&MouseX, &MouseY)
        ;MsgBox(xpos)

        g.SetFont("s10", "Segoe UI")
        g.Title := "Speedtests"

        g.Add("Button", "w200", "fast.com").OnEvent("Click", (*) => Run("https://fast.com/de/"))
        g.Add("Button", "w200", "Telekom Speedtest").OnEvent("Click", (*) => Run("https://www.telekom.de/shop/tarife/speedtest"))
        g.Add("Button", "w200", "Speedtest.net").OnEvent("Click", (*) => Run("https://www.speedtest.net/de"))
        g.Add("Button", "w200", "Breitbandmessung").OnEvent("Click", (*) => Run("https://www.breitbandmessung.de/test"))
        g.Add("Button", "w200", "Wieistmeineip.de").OnEvent("Click", (*) => Run("https://www.wieistmeineip.de/speedtest/"))
        g.Add("Button", "w200", "ComputerBild").OnEvent("Click", (*) => Run("https://speedtest.computerbild.de"))
        g.Add("Button", "w200", "Google Speedtest").OnEvent("Click", (*) => Run("https://www.google.com/search?q=speedtest"))
        g.Add("Button", "w200", "SpeedOf.Me").OnEvent("Click", (*) => Run("https://speedof.me"))
        g.Add("Button", "w200", "TestMy.net").OnEvent("Click", (*) => Run("https://de2.testmy.net/b/SmarTest/combined"))

        ;g.Show("x" MouseX "y" MouseY)
        g.show()
        g.Move(setWindowPos(g), getWindowInfo(MeineGui).y)
        zieleIsOpen := true
    }
    g.OnEvent("Close", (*) => zieleIsOpen := false)

}


