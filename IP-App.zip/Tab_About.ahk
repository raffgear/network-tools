﻿; Der Reiter „About“ enthält nur statische GUI-Elemente.
; Seine Steuerelemente und die Tab-Wechselanzeige stehen in IP-App.ahk.
