﻿; Logik für den Reiter „Notizen“.
loadNotiz() {
    global notizFeld
    notizFeld.Value := ""
    for inhalt in GetAppDataLines() {
        teile := StrSplit(inhalt, ";")
        if (teile[1] = "Notiz") {
            for index, teil in teile {
                if (index = 1)
                    continue
                if (notizFeld.Value = "")
                    notizFeld.Value := teil
                else
                    notizFeld.Value .= "`n`r" teil
            }
        }
    }
}
saveNotiz(*) {
    global notizFeld, infoSavedNotiz
    tempNotiz := StrReplace(notizFeld.Value, "`n", ";")
    tempNotiz := StrReplace(tempNotiz, "`r", "")
    lines := GetAppDataLines()
    cleaned := []
    notizGespeichert := false

    for line in lines {
        teile := StrSplit(line, ";")
        if (teile[1] = "Notiz") {
            if (!notizGespeichert) {
                cleaned.Push("Notiz;" tempNotiz)
                notizGespeichert := true
            }
        } else {
            cleaned.Push(line)
        }
    }
    if (!notizGespeichert)
        cleaned.Push("Notiz;" tempNotiz)

    SaveAppDataLines(cleaned)
    infoSavedNotiz.Text := "gespeichert"
}
